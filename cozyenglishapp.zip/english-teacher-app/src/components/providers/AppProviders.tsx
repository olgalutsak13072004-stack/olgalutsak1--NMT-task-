"use client";

import { ThemeProvider } from "@/lib/theme";
import { useStore } from "@/lib/store";
import { useAuthStore } from "@/lib/auth";

function LoadingSplash() {
  return (
    <div className="flex h-screen w-full items-center justify-center bg-canvas">
      <div className="flex flex-col items-center gap-3">
        <div className="h-10 w-10 animate-spin rounded-full border-[3px] border-sage-soft border-t-sage" />
        <p className="font-display text-sm text-ink-soft">Warming up your studio…</p>
      </div>
    </div>
  );
}

export function AppProviders({ children }: { children: React.ReactNode }) {
  const dataHydrated = useStore((s) => s.hasHydrated);
  const authHydrated = useAuthStore((s) => s.hasHydrated);

  const ready = dataHydrated && authHydrated;

  return <ThemeProvider>{ready ? children : <LoadingSplash />}</ThemeProvider>;
}

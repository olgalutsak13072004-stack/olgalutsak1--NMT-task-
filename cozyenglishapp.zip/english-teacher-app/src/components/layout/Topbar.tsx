"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { Search, Bell, Sun, Moon, Menu } from "lucide-react";
import { AnimatePresence, motion } from "framer-motion";
import { useTheme } from "@/lib/theme";
import { AppUser } from "@/lib/types";
import { useStore } from "@/lib/store";
import { searchAll } from "@/lib/search";
import { generateNotifications } from "@/lib/notifications";
import { Avatar } from "@/components/ui/Avatar";
import { Badge } from "@/components/ui/Badge";

export function Topbar({ user, onMenuClick }: { user: AppUser; onMenuClick: () => void }) {
  const { theme, toggleTheme } = useTheme();
  const students = useStore((s) => s.students);
  const router = useRouter();
  const [query, setQuery] = useState("");
  const [searchOpen, setSearchOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const searchRef = useRef<HTMLDivElement>(null);
  const notifRef = useRef<HTMLDivElement>(null);

  const results = user.role === "teacher" ? searchAll(students, query) : [];
  const notifications = user.role === "teacher" ? generateNotifications(students) : [];

  useEffect(() => {
    function onClick(e: MouseEvent) {
      if (searchRef.current && !searchRef.current.contains(e.target as Node)) setSearchOpen(false);
      if (notifRef.current && !notifRef.current.contains(e.target as Node)) setNotifOpen(false);
    }
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, []);

  return (
    <header className="sticky top-0 z-30 flex items-center gap-3 border-b border-border bg-canvas/80 px-4 py-3 backdrop-blur-md sm:px-6">
      <button onClick={onMenuClick} className="rounded-lg p-2 text-ink-soft hover:bg-canvas-soft lg:hidden">
        <Menu size={20} />
      </button>

      {user.role === "teacher" && (
        <div className="relative flex-1 max-w-md" ref={searchRef}>
          <Search size={16} className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-ink-faint" />
          <input
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              setSearchOpen(true);
            }}
            onFocus={() => setSearchOpen(true)}
            placeholder="Search students, lessons, vocabulary…"
            className="w-full rounded-full border border-border bg-surface py-2 pl-9 pr-3 text-sm outline-none transition-colors focus:border-sage focus:ring-2 focus:ring-sage-soft"
          />
          <AnimatePresence>
            {searchOpen && query && (
              <motion.div
                initial={{ opacity: 0, y: -6 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -6 }}
                className="absolute left-0 right-0 top-full mt-2 max-h-96 overflow-y-auto rounded-2xl border border-border bg-surface p-2 shadow-[var(--shadow-cozy-lg)]"
              >
                {results.length === 0 ? (
                  <p className="px-3 py-4 text-center text-sm text-ink-soft">No results for &ldquo;{query}&rdquo;</p>
                ) : (
                  results.map((r) => (
                    <button
                      key={r.id}
                      onClick={() => {
                        router.push(r.href);
                        setSearchOpen(false);
                        setQuery("");
                      }}
                      className="flex w-full items-center justify-between gap-2 rounded-xl px-3 py-2.5 text-left hover:bg-canvas-soft"
                    >
                      <span>
                        <span className="block text-sm font-medium text-ink">{r.title}</span>
                        <span className="block text-xs text-ink-soft">{r.subtitle}</span>
                      </span>
                      <Badge tone="beige">{r.category}</Badge>
                    </button>
                  ))
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      )}

      <div className="ml-auto flex items-center gap-2">
        {user.role === "teacher" && (
          <div className="relative" ref={notifRef}>
            <button
              onClick={() => setNotifOpen((v) => !v)}
              className="relative rounded-full p-2.5 text-ink-soft hover:bg-canvas-soft hover:text-ink"
            >
              <Bell size={18} />
              {notifications.length > 0 && (
                <span className="absolute right-1.5 top-1.5 h-2 w-2 rounded-full bg-coral" />
              )}
            </button>
            <AnimatePresence>
              {notifOpen && (
                <motion.div
                  initial={{ opacity: 0, y: -6 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -6 }}
                  className="absolute right-0 top-full mt-2 max-h-96 w-80 overflow-y-auto rounded-2xl border border-border bg-surface p-2 shadow-[var(--shadow-cozy-lg)]"
                >
                  <p className="px-3 py-2 text-xs font-semibold uppercase tracking-wide text-ink-faint">Reminders</p>
                  {notifications.length === 0 ? (
                    <p className="px-3 py-4 text-center text-sm text-ink-soft">You&rsquo;re all caught up 🎉</p>
                  ) : (
                    notifications.map((n) => (
                      <button
                        key={n.id}
                        onClick={() => {
                          router.push(n.href);
                          setNotifOpen(false);
                        }}
                        className="flex w-full items-start gap-2 rounded-xl px-3 py-2.5 text-left text-sm hover:bg-canvas-soft"
                      >
                        <span
                          className={`mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full ${
                            n.tone === "warning" ? "bg-coral" : n.tone === "positive" ? "bg-sage" : "bg-dusty"
                          }`}
                        />
                        <span className="text-ink-soft">{n.text}</span>
                      </button>
                    ))
                  )}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        )}

        <button onClick={toggleTheme} className="rounded-full p-2.5 text-ink-soft hover:bg-canvas-soft hover:text-ink">
          {theme === "light" ? <Moon size={18} /> : <Sun size={18} />}
        </button>

        <div className="hidden items-center gap-2 rounded-full border border-border bg-surface py-1 pl-1 pr-3 sm:flex">
          <Avatar name={user.name} size={30} tone={user.role === "teacher" ? "sage" : "dusty"} />
          <span className="text-sm font-medium text-ink">{user.name.split(" ")[0]}</span>
        </div>
      </div>
    </header>
  );
}

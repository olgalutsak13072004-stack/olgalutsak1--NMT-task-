"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import {
  Home,
  Users,
  Calendar,
  NotebookPen,
  BookOpen,
  ClipboardList,
  FileBarChart2,
  Trophy,
  LineChart,
  Settings,
  Target,
  MessagesSquare,
  LogOut,
  Sparkles,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { AppUser } from "@/lib/types";
import { useAuthStore } from "@/lib/auth";

const teacherNav = [
  { href: "/teacher", label: "Dashboard", icon: Home },
  { href: "/teacher/students", label: "Students", icon: Users },
  { href: "/teacher/calendar", label: "Calendar", icon: Calendar },
  { href: "/teacher/lesson-plans", label: "Lesson Plans", icon: NotebookPen },
  { href: "/teacher/vocabulary", label: "Vocabulary", icon: BookOpen },
  { href: "/teacher/homework", label: "Homework", icon: ClipboardList },
  { href: "/teacher/reports", label: "Reports", icon: FileBarChart2 },
  { href: "/teacher/achievements", label: "Achievements", icon: Trophy },
  { href: "/teacher/statistics", label: "Statistics", icon: LineChart },
  { href: "/teacher/settings", label: "Settings", icon: Settings },
];

const studentNav = [
  { href: "/student", label: "Dashboard", icon: Home },
  { href: "/student/progress", label: "Progress", icon: LineChart },
  { href: "/student/homework", label: "Homework", icon: ClipboardList },
  { href: "/student/notes", label: "Lesson Notes", icon: NotebookPen },
  { href: "/student/vocabulary", label: "Vocabulary", icon: BookOpen },
  { href: "/student/goals", label: "Goals", icon: Target },
  { href: "/student/achievements", label: "Achievements", icon: Trophy },
  { href: "/student/calendar", label: "Calendar", icon: Calendar },
  { href: "/student/feedback", label: "Feedback", icon: MessagesSquare },
  { href: "/student/settings", label: "Settings", icon: Settings },
];

export function Sidebar({ user, mobile, onNavigate }: { user: AppUser; mobile?: boolean; onNavigate?: () => void }) {
  const pathname = usePathname();
  const router = useRouter();
  const logout = useAuthStore((s) => s.logout);
  const items = user.role === "teacher" ? teacherNav : studentNav;

  return (
    <div className={cn("flex h-full flex-col", mobile ? "w-full" : "w-64")}>
      <div className="flex items-center gap-2 px-5 pb-6 pt-6">
        <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-sage text-white">
          <Sparkles size={18} />
        </div>
        <div>
          <p className="font-display text-base font-semibold leading-tight text-ink">Cozy English</p>
          <p className="text-[11px] text-ink-soft">Teaching Studio</p>
        </div>
      </div>

      <nav className="flex-1 space-y-1 overflow-y-auto px-3">
        {items.map((item) => {
          const active = pathname === item.href || (item.href !== "/teacher" && item.href !== "/student" && pathname.startsWith(item.href));
          const Icon = item.icon;
          return (
            <Link
              key={item.href}
              href={item.href}
              onClick={onNavigate}
              className={cn(
                "flex items-center gap-3 rounded-xl px-3.5 py-2.5 text-sm font-medium transition-colors",
                active ? "bg-sage-soft text-sage-deep" : "text-ink-soft hover:bg-canvas-soft hover:text-ink"
              )}
            >
              <Icon size={18} strokeWidth={2} />
              {item.label}
            </Link>
          );
        })}
      </nav>

      <div className="border-t border-border px-3 py-4">
        <button
          onClick={() => {
            logout();
            router.push("/login");
          }}
          className="flex w-full items-center gap-3 rounded-xl px-3.5 py-2.5 text-sm font-medium text-ink-soft transition-colors hover:bg-coral-soft hover:text-coral"
        >
          <LogOut size={18} />
          Log out
        </button>
      </div>
    </div>
  );
}

"use client";

import { useMemo } from "react";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  AreaChart,
  Area,
  BarChart,
  Bar,
  RadarChart,
  Radar,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
} from "recharts";
import { Student } from "@/lib/types";
import { Card } from "@/components/ui/Card";
import { StatTile } from "@/components/ui/StatTile";
import { SKILL_META } from "@/lib/skill-meta";
import { computeScoreTimeline } from "@/lib/scoring";
import { estimateCEFR } from "@/lib/utils";
import { estimatedFinalScore } from "@/lib/insights";
import { Trophy, Target, GraduationCap, ClipboardCheck } from "lucide-react";
import { average, formatDateShort } from "@/lib/utils";

const chartColors = {
  sage: "var(--color-sage)",
  dusty: "var(--color-dusty)",
  coral: "var(--color-coral)",
  beige: "var(--color-beige-deep)",
};

export function StudentStatistics({ student }: { student: Student }) {
  const timeline = useMemo(() => computeScoreTimeline(student), [student]);

  const chartData = timeline.map((t) => ({
    date: formatDateShort(t.date),
    Overall: t.overall,
    Grammar: t.grammar,
    Vocabulary: t.vocabulary,
    Listening: t.listening,
    Speaking: t.speaking,
    Writing: t.writing,
    Reading: t.reading,
  }));

  const vocabGrowth = useMemo(() => {
    const sorted = [...student.vocabulary].sort((a, b) => a.dateLearned.localeCompare(b.dateLearned));
    return sorted.reduce<{ date: string; Words: number; Mastered: number }[]>((acc, v) => {
      const prev = acc[acc.length - 1];
      acc.push({
        date: formatDateShort(v.dateLearned),
        Words: (prev?.Words ?? 0) + 1,
        Mastered: (prev?.Mastered ?? 0) + (v.mastered ? 1 : 0),
      });
      return acc;
    }, []);
  }, [student.vocabulary]);

  const avgLessonScore = useMemo(() => {
    if (!student.lessons.length) return 0;
    return Math.round(
      average(
        student.lessons.map(
          (l) => ((l.assessment.participation + l.assessment.confidence + l.assessment.grammar + l.assessment.vocabulary + l.assessment.listening + l.assessment.speaking) / 6) * 20
        )
      )
    );
  }, [student.lessons]);

  const avgTestScore = useMemo(() => {
    if (!student.tests.length) return 0;
    return Math.round(average(student.tests.map((t) => (t.score / t.maxScore) * 100)));
  }, [student.tests]);

  const cefr = estimateCEFR(student.level, student.scores.overall);
  const finalScore = estimatedFinalScore(student);

  const radarData = SKILL_META.filter((m) => m.key !== "homework" && m.key !== "attendance").map((m) => ({ skill: m.label, value: student.scores[m.key] }));

  const attendanceData = (["present", "late", "absent", "cancelled", "rescheduled"] as const).map((status) => ({
    status,
    count: student.attendance.filter((a) => a.status === status).length,
  }));

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
        <StatTile icon={<ClipboardCheck size={18} />} label="Avg lesson score" value={`${avgLessonScore}%`} tone="sage" />
        <StatTile icon={<Trophy size={18} />} label="Avg test score" value={student.tests.length ? `${avgTestScore}%` : "—"} tone="dusty" />
        <StatTile icon={<Target size={18} />} label="Course completion" value={`${student.scores.overall}%`} tone="coral" />
        <StatTile icon={<GraduationCap size={18} />} label="Estimated CEFR" value={cefr.level} sub={`Final score ~${finalScore}%`} tone="beige" />
      </div>

      <Card className="p-5" hoverLift={false}>
        <h3 className="mb-4 font-display text-base font-semibold text-ink">Progress over time (weekly / monthly growth)</h3>
        {chartData.length < 2 ? (
          <p className="text-sm text-ink-soft">Log a few more lessons to see growth trends.</p>
        ) : (
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                <XAxis dataKey="date" tick={{ fill: "var(--color-ink-soft)", fontSize: 11 }} />
                <YAxis domain={[0, 100]} tick={{ fill: "var(--color-ink-soft)", fontSize: 11 }} />
                <Tooltip contentStyle={{ background: "var(--color-surface)", border: "1px solid var(--color-border)", borderRadius: 12, fontSize: 12 }} />
                <Line type="monotone" dataKey="Overall" stroke={chartColors.sage} strokeWidth={2.5} dot={false} />
                <Line type="monotone" dataKey="Speaking" stroke={chartColors.coral} strokeWidth={1.5} dot={false} />
                <Line type="monotone" dataKey="Listening" stroke={chartColors.dusty} strokeWidth={1.5} dot={false} />
                <Line type="monotone" dataKey="Grammar" stroke="#a78bfa" strokeWidth={1.5} dot={false} />
                <Line type="monotone" dataKey="Vocabulary" stroke="#f4a261" strokeWidth={1.5} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        )}
      </Card>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <Card className="p-5" hoverLift={false}>
          <h3 className="mb-4 font-display text-base font-semibold text-ink">Vocabulary growth</h3>
          {vocabGrowth.length === 0 ? (
            <p className="text-sm text-ink-soft">No vocabulary logged yet.</p>
          ) : (
            <div className="h-56">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={vocabGrowth}>
                  <defs>
                    <linearGradient id="vocabGradient" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor={chartColors.sage} stopOpacity={0.4} />
                      <stop offset="100%" stopColor={chartColors.sage} stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                  <XAxis dataKey="date" tick={{ fill: "var(--color-ink-soft)", fontSize: 10 }} />
                  <YAxis tick={{ fill: "var(--color-ink-soft)", fontSize: 11 }} />
                  <Tooltip contentStyle={{ background: "var(--color-surface)", border: "1px solid var(--color-border)", borderRadius: 12, fontSize: 12 }} />
                  <Area type="monotone" dataKey="Words" stroke={chartColors.sage} fill="url(#vocabGradient)" strokeWidth={2} />
                  <Line type="monotone" dataKey="Mastered" stroke={chartColors.coral} strokeWidth={2} dot={false} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          )}
        </Card>

        <Card className="p-5" hoverLift={false}>
          <h3 className="mb-4 font-display text-base font-semibold text-ink">Current skill snapshot</h3>
          <div className="h-56">
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart data={radarData} outerRadius="75%">
                <PolarGrid stroke="var(--color-border)" />
                <PolarAngleAxis dataKey="skill" tick={{ fill: "var(--color-ink-soft)", fontSize: 11 }} />
                <PolarRadiusAxis domain={[0, 100]} tick={false} axisLine={false} />
                <Radar dataKey="value" stroke={chartColors.dusty} fill={chartColors.dusty} fillOpacity={0.35} />
              </RadarChart>
            </ResponsiveContainer>
          </div>
        </Card>
      </div>

      <Card className="p-5" hoverLift={false}>
        <h3 className="mb-4 font-display text-base font-semibold text-ink">Attendance breakdown</h3>
        <div className="h-48">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={attendanceData}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
              <XAxis dataKey="status" tick={{ fill: "var(--color-ink-soft)", fontSize: 11 }} />
              <YAxis allowDecimals={false} tick={{ fill: "var(--color-ink-soft)", fontSize: 11 }} />
              <Tooltip contentStyle={{ background: "var(--color-surface)", border: "1px solid var(--color-border)", borderRadius: 12, fontSize: 12 }} />
              <Bar dataKey="count" fill={chartColors.sage} radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </Card>
    </div>
  );
}

"use client";

import { useMemo, useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Card } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { CalendarEvent, groupEventsByDay } from "@/lib/calendar";
import { cn, formatDate } from "@/lib/utils";

const WEEKDAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

export function MonthCalendar({ events, showStudent = true }: { events: CalendarEvent[]; showStudent?: boolean }) {
  const [cursor, setCursor] = useState(() => new Date(2026, 6, 1));
  const [selectedDay, setSelectedDay] = useState<string | null>(null);

  const byDay = useMemo(() => groupEventsByDay(events), [events]);

  const { cells, monthLabel } = useMemo(() => {
    const year = cursor.getFullYear();
    const month = cursor.getMonth();
    const first = new Date(year, month, 1);
    const startOffset = first.getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const cells: { date: Date | null; key: string }[] = [];
    for (let i = 0; i < startOffset; i++) cells.push({ date: null, key: `empty-${i}` });
    for (let d = 1; d <= daysInMonth; d++) {
      const date = new Date(year, month, d);
      cells.push({ date, key: date.toISOString().slice(0, 10) });
    }
    return { cells, monthLabel: first.toLocaleDateString("en-US", { month: "long", year: "numeric" }) };
  }, [cursor]);

  const selectedEvents = selectedDay ? byDay.get(selectedDay) ?? [] : [];

  return (
    <div className="grid grid-cols-1 gap-5 lg:grid-cols-[1fr_320px]">
      <Card className="p-5" hoverLift={false}>
        <div className="mb-4 flex items-center justify-between">
          <h2 className="font-display text-lg font-semibold text-ink">{monthLabel}</h2>
          <div className="flex gap-1">
            <button onClick={() => setCursor(new Date(cursor.getFullYear(), cursor.getMonth() - 1, 1))} className="rounded-full p-2 hover:bg-canvas-soft">
              <ChevronLeft size={16} />
            </button>
            <button onClick={() => setCursor(new Date(cursor.getFullYear(), cursor.getMonth() + 1, 1))} className="rounded-full p-2 hover:bg-canvas-soft">
              <ChevronRight size={16} />
            </button>
          </div>
        </div>
        <div className="grid grid-cols-7 gap-1 text-center text-xs font-semibold text-ink-faint">
          {WEEKDAYS.map((w) => (
            <div key={w} className="py-1.5">
              {w}
            </div>
          ))}
        </div>
        <div className="grid grid-cols-7 gap-1">
          {cells.map((c) => {
            if (!c.date) return <div key={c.key} />;
            const key = c.key;
            const dayEvents = byDay.get(key) ?? [];
            const isToday = key === "2026-07-27";
            return (
              <button
                key={key}
                onClick={() => setSelectedDay(key)}
                className={cn(
                  "flex min-h-[64px] flex-col items-start rounded-xl border p-1.5 text-left transition-colors",
                  selectedDay === key ? "border-sage bg-sage-soft/40" : "border-transparent hover:bg-canvas-soft",
                  isToday && "ring-1 ring-sage"
                )}
              >
                <span className={cn("text-xs font-medium", isToday ? "text-sage-deep" : "text-ink-soft")}>{c.date.getDate()}</span>
                <div className="mt-1 flex flex-wrap gap-0.5">
                  {dayEvents.slice(0, 3).map((e) => (
                    <span
                      key={e.id}
                      className={cn(
                        "h-1.5 w-1.5 rounded-full",
                        e.tone === "sage" ? "bg-sage" : e.tone === "coral" ? "bg-coral" : e.tone === "dusty" ? "bg-dusty" : "bg-beige-deep"
                      )}
                    />
                  ))}
                  {dayEvents.length > 3 && <span className="text-[9px] text-ink-faint">+{dayEvents.length - 3}</span>}
                </div>
              </button>
            );
          })}
        </div>
      </Card>

      <Card className="p-5" hoverLift={false}>
        <h3 className="mb-3 font-display text-base font-semibold text-ink">
          {selectedDay ? formatDate(selectedDay) : "Select a day"}
        </h3>
        {selectedEvents.length === 0 ? (
          <p className="text-sm text-ink-soft">{selectedDay ? "No events on this day." : "Click a date to see what's happening."}</p>
        ) : (
          <div className="space-y-2.5">
            {selectedEvents.map((e) => (
              <div key={e.id} className="rounded-xl bg-canvas-soft/60 p-3">
                <div className="mb-1 flex items-center justify-between gap-2">
                  <Badge tone={e.tone}>{e.type}</Badge>
                </div>
                <p className="text-sm font-medium text-ink">{e.title}</p>
                {showStudent && <p className="text-xs text-ink-soft">{e.studentName}</p>}
              </div>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
}

"use client";

import { Star } from "lucide-react";
import { cn } from "@/lib/utils";

export function StarRating({
  value,
  max = 5,
  onChange,
  size = 16,
  readOnly = false,
}: {
  value: number;
  max?: number;
  onChange?: (v: number) => void;
  size?: number;
  readOnly?: boolean;
}) {
  return (
    <div className="inline-flex items-center gap-0.5">
      {Array.from({ length: max }, (_, i) => i + 1).map((i) => (
        <button
          key={i}
          type="button"
          disabled={readOnly}
          onClick={() => onChange?.(i)}
          className={cn("transition-transform", !readOnly && "hover:scale-110 cursor-pointer", readOnly && "cursor-default")}
          aria-label={`${i} star`}
        >
          <Star
            size={size}
            className={i <= value ? "fill-coral text-coral" : "fill-transparent text-ink-faint"}
            strokeWidth={1.5}
          />
        </button>
      ))}
    </div>
  );
}

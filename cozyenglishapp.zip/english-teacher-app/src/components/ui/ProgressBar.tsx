"use client";

import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

type Tone = "sage" | "dusty" | "coral" | "beige";

const toneBar: Record<Tone, string> = {
  sage: "bg-sage",
  dusty: "bg-dusty",
  coral: "bg-coral",
  beige: "bg-beige-deep",
};

export function ProgressBar({
  value,
  label,
  tone = "sage",
  size = "md",
  showValue = true,
}: {
  value: number;
  label?: string;
  tone?: Tone;
  size?: "sm" | "md" | "lg";
  showValue?: boolean;
}) {
  const height = size === "sm" ? "h-1.5" : size === "lg" ? "h-3" : "h-2";
  const clamped = Math.max(0, Math.min(100, value));
  return (
    <div className="w-full">
      {(label || showValue) && (
        <div className="mb-1.5 flex items-center justify-between text-xs">
          {label && <span className="font-medium text-ink-soft">{label}</span>}
          {showValue && <span className="font-semibold text-ink">{Math.round(clamped)}%</span>}
        </div>
      )}
      <div className={cn("w-full overflow-hidden rounded-full bg-canvas-soft", height)}>
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${clamped}%` }}
          transition={{ duration: 1, ease: [0.16, 1, 0.3, 1], delay: 0.1 }}
          className={cn("h-full rounded-full", toneBar[tone])}
        />
      </div>
    </div>
  );
}

export function CircularProgress({
  value,
  size = 120,
  strokeWidth = 10,
  tone = "sage",
  label,
}: {
  value: number;
  size?: number;
  strokeWidth?: number;
  tone?: Tone;
  label?: string;
}) {
  const clamped = Math.max(0, Math.min(100, value));
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const strokeColor: Record<Tone, string> = {
    sage: "var(--color-sage)",
    dusty: "var(--color-dusty)",
    coral: "var(--color-coral)",
    beige: "var(--color-beige-deep)",
  };
  return (
    <div className="relative inline-flex items-center justify-center">
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={radius} stroke="var(--color-canvas-soft)" strokeWidth={strokeWidth} fill="none" />
        <motion.circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke={strokeColor[tone]}
          strokeWidth={strokeWidth}
          fill="none"
          strokeLinecap="round"
          strokeDasharray={circumference}
          initial={{ strokeDashoffset: circumference }}
          animate={{ strokeDashoffset: circumference - (clamped / 100) * circumference }}
          transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
        />
      </svg>
      <div className="absolute flex flex-col items-center justify-center">
        <span className="font-display text-2xl font-semibold text-ink">{Math.round(clamped)}%</span>
        {label && <span className="text-[11px] text-ink-soft">{label}</span>}
      </div>
    </div>
  );
}

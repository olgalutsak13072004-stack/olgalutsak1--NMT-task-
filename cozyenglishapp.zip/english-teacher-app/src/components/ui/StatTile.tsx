import { Card } from "./Card";
import { cn } from "@/lib/utils";

type Tone = "sage" | "dusty" | "coral" | "beige";

const toneClasses: Record<Tone, string> = {
  sage: "bg-sage-soft text-sage-deep",
  dusty: "bg-dusty-soft text-dusty-deep",
  coral: "bg-coral-soft text-coral",
  beige: "bg-beige text-ink-soft",
};

export function StatTile({
  icon,
  label,
  value,
  sub,
  tone = "sage",
}: {
  icon: React.ReactNode;
  label: string;
  value: string | number;
  sub?: string;
  tone?: Tone;
}) {
  return (
    <Card className="flex items-center gap-4 p-5">
      <div className={cn("flex h-11 w-11 shrink-0 items-center justify-center rounded-xl", toneClasses[tone])}>{icon}</div>
      <div>
        <p className="font-display text-xl font-semibold text-ink">{value}</p>
        <p className="text-xs text-ink-soft">{label}</p>
        {sub && <p className="mt-0.5 text-[11px] text-ink-faint">{sub}</p>}
      </div>
    </Card>
  );
}

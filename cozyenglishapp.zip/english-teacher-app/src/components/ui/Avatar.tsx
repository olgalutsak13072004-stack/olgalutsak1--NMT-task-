import { cn, initials } from "@/lib/utils";

type Tone = "sage" | "dusty" | "coral" | "beige";

const toneClasses: Record<Tone, string> = {
  sage: "bg-sage-soft text-sage-deep",
  dusty: "bg-dusty-soft text-dusty-deep",
  coral: "bg-coral-soft text-coral",
  beige: "bg-beige text-ink-soft",
};

export function Avatar({
  name,
  emoji,
  tone = "sage",
  size = 44,
  className,
}: {
  name: string;
  emoji?: string;
  tone?: Tone;
  size?: number;
  className?: string;
}) {
  return (
    <div
      className={cn("flex shrink-0 items-center justify-center rounded-full font-semibold", toneClasses[tone as Tone] ?? toneClasses.sage, className ?? "")}
      style={{ width: size, height: size, fontSize: size * 0.4 }}
    >
      {emoji ?? initials(name)}
    </div>
  );
}

"use client";

import { motion, HTMLMotionProps } from "framer-motion";
import { cn } from "@/lib/utils";

interface CardProps extends HTMLMotionProps<"div"> {
  soft?: boolean;
  hoverLift?: boolean;
}

export function Card({ className, soft, hoverLift = true, children, ...props }: CardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, ease: [0.16, 1, 0.3, 1] }}
      whileHover={hoverLift ? { y: -3, boxShadow: "var(--shadow-cozy-lg)" } : undefined}
      className={cn(
        "rounded-2xl border border-border shadow-[var(--shadow-cozy)]",
        soft ? "bg-surface-soft" : "bg-surface",
        "transition-shadow",
        className ?? ""
      )}
      {...props}
    >
      {children}
    </motion.div>
  );
}

"use client";

import { ButtonHTMLAttributes, forwardRef } from "react";
import { cn } from "@/lib/utils";

type Variant = "primary" | "secondary" | "ghost" | "danger" | "outline";
type Size = "sm" | "md" | "lg" | "icon";

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  size?: Size;
}

const variantClasses: Record<Variant, string> = {
  primary: "bg-sage text-white hover:bg-sage-deep shadow-[var(--shadow-cozy)]",
  secondary: "bg-dusty text-white hover:bg-dusty-deep shadow-[var(--shadow-cozy)]",
  outline: "border border-border bg-surface hover:bg-canvas-soft text-ink",
  ghost: "bg-transparent hover:bg-canvas-soft text-ink-soft hover:text-ink",
  danger: "bg-coral text-white hover:opacity-90 shadow-[var(--shadow-cozy)]",
};

const sizeClasses: Record<Size, string> = {
  sm: "h-8 px-3 text-xs gap-1.5",
  md: "h-10 px-4 text-sm gap-2",
  lg: "h-12 px-6 text-base gap-2",
  icon: "h-9 w-9 p-0",
};

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(function Button(
  { className, variant = "primary", size = "md", children, ...props },
  ref
) {
  return (
    <button
      ref={ref}
      className={cn(
        "inline-flex items-center justify-center rounded-full font-medium transition-all duration-200 active:scale-[0.97] disabled:opacity-50 disabled:pointer-events-none whitespace-nowrap",
        variantClasses[variant],
        sizeClasses[size],
        className ?? ""
      )}
      {...props}
    >
      {children}
    </button>
  );
});

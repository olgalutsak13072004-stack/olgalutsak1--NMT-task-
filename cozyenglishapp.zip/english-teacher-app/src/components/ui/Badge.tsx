import { cn } from "@/lib/utils";

type Tone = "sage" | "dusty" | "coral" | "beige" | "neutral";

const toneClasses: Record<Tone, string> = {
  sage: "bg-sage-soft text-sage-deep",
  dusty: "bg-dusty-soft text-dusty-deep",
  coral: "bg-coral-soft text-coral",
  beige: "bg-beige text-ink-soft",
  neutral: "bg-canvas-soft text-ink-soft border border-border",
};

export function Badge({
  children,
  tone = "neutral",
  className,
}: {
  children: React.ReactNode;
  tone?: Tone;
  className?: string;
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-xs font-medium",
        toneClasses[tone],
        className ?? ""
      )}
    >
      {children}
    </span>
  );
}

"use client";

import Link from "next/link";
import { useState, useRef, useEffect } from "react";
import { MoreVertical, Archive, ArchiveRestore, Copy, Trash2, Eye } from "lucide-react";
import { motion } from "framer-motion";
import { Student } from "@/lib/types";
import { Card } from "@/components/ui/Card";
import { Avatar } from "@/components/ui/Avatar";
import { Badge } from "@/components/ui/Badge";
import { ProgressBar } from "@/components/ui/ProgressBar";
import { useStore } from "@/lib/store";

const levelTone: Record<string, "sage" | "dusty" | "coral" | "beige"> = {
  A1: "beige",
  A2: "beige",
  B1: "dusty",
  B2: "dusty",
  C1: "sage",
  C2: "sage",
};

export function StudentCard({ student, index = 0 }: { student: Student; index?: number }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);
  const archiveStudent = useStore((s) => s.archiveStudent);
  const unarchiveStudent = useStore((s) => s.unarchiveStudent);
  const deleteStudent = useStore((s) => s.deleteStudent);
  const duplicateStudent = useStore((s) => s.duplicateStudent);

  useEffect(() => {
    function onClick(e: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) setMenuOpen(false);
    }
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, []);

  return (
    <Card
      className="group relative flex flex-col gap-4 p-5"
      style={{ animationDelay: `${index * 40}ms` }}
    >
      <div className="flex items-start justify-between">
        <Link href={`/teacher/students/${student.id}`} className="flex items-center gap-3">
          <Avatar name={student.name} emoji={student.avatarEmoji} tone={student.avatarColor as "sage" | "dusty" | "coral" | "beige"} size={48} />
          <div>
            <p className="font-display text-base font-semibold text-ink">{student.name}</p>
            <p className="text-xs text-ink-soft">{student.occupation || "Student"} · Age {student.age}</p>
          </div>
        </Link>

        <div className="relative" ref={menuRef}>
          <button
            onClick={() => setMenuOpen((v) => !v)}
            className="rounded-full p-1.5 text-ink-faint opacity-0 transition-opacity hover:bg-canvas-soft hover:text-ink group-hover:opacity-100"
          >
            <MoreVertical size={16} />
          </button>
          {menuOpen && (
            <motion.div
              initial={{ opacity: 0, y: -4 }}
              animate={{ opacity: 1, y: 0 }}
              className="absolute right-0 top-full z-20 mt-1 w-44 overflow-hidden rounded-xl border border-border bg-surface p-1 shadow-[var(--shadow-cozy-lg)]"
            >
              <Link href={`/teacher/students/${student.id}`} className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm text-ink-soft hover:bg-canvas-soft hover:text-ink">
                <Eye size={14} /> View profile
              </Link>
              <button
                onClick={() => {
                  duplicateStudent(student.id);
                  setMenuOpen(false);
                }}
                className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm text-ink-soft hover:bg-canvas-soft hover:text-ink"
              >
                <Copy size={14} /> Duplicate profile
              </button>
              {student.status === "active" ? (
                <button
                  onClick={() => {
                    archiveStudent(student.id);
                    setMenuOpen(false);
                  }}
                  className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm text-ink-soft hover:bg-canvas-soft hover:text-ink"
                >
                  <Archive size={14} /> Archive
                </button>
              ) : (
                <button
                  onClick={() => {
                    unarchiveStudent(student.id);
                    setMenuOpen(false);
                  }}
                  className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm text-ink-soft hover:bg-canvas-soft hover:text-ink"
                >
                  <ArchiveRestore size={14} /> Unarchive
                </button>
              )}
              <button
                onClick={() => {
                  if (confirm(`Delete ${student.name}? This cannot be undone.`)) deleteStudent(student.id);
                  setMenuOpen(false);
                }}
                className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm text-coral hover:bg-coral-soft"
              >
                <Trash2 size={14} /> Delete
              </button>
            </motion.div>
          )}
        </div>
      </div>

      <div className="flex flex-wrap items-center gap-1.5">
        <Badge tone={levelTone[student.level]}>{student.level}</Badge>
        {student.status === "archived" && <Badge tone="neutral">Archived</Badge>}
        {student.goals.slice(0, 1).map((g) => (
          <Badge key={g} tone="beige">
            🎯 {g}
          </Badge>
        ))}
      </div>

      <ProgressBar value={student.scores.overall} tone="sage" label="Overall progress" />

      <div className="grid grid-cols-3 gap-2 text-center">
        <div className="rounded-xl bg-canvas-soft py-2">
          <p className="text-sm font-semibold text-ink">{student.scores.attendance}%</p>
          <p className="text-[10px] text-ink-soft">Attendance</p>
        </div>
        <div className="rounded-xl bg-canvas-soft py-2">
          <p className="text-sm font-semibold text-ink">{student.scores.homework}%</p>
          <p className="text-[10px] text-ink-soft">Homework</p>
        </div>
        <div className="rounded-xl bg-canvas-soft py-2">
          <p className="text-sm font-semibold text-ink">{student.lessons.length}</p>
          <p className="text-[10px] text-ink-soft">Lessons</p>
        </div>
      </div>

      <Link
        href={`/teacher/students/${student.id}`}
        className="mt-1 text-center text-sm font-medium text-sage-deep hover:underline"
      >
        View full profile →
      </Link>
    </Card>
  );
}

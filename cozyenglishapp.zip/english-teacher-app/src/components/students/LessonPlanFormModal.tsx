"use client";

import { useState } from "react";
import { Modal } from "@/components/ui/Modal";
import { Input, Label, Textarea } from "@/components/ui/Input";
import { Button } from "@/components/ui/Button";
import { useStore } from "@/lib/store";
import { LessonPlan } from "@/lib/types";

const FIELDS: { key: keyof LessonPlan; label: string; placeholder?: string }[] = [
  { key: "objectives", label: "Objectives" },
  { key: "targetVocabulary", label: "Target vocabulary" },
  { key: "grammar", label: "Grammar" },
  { key: "activities", label: "Activities" },
  { key: "games", label: "Games" },
  { key: "homeworkPlan", label: "Homework" },
  { key: "expectedDifficulties", label: "Expected difficulties" },
  { key: "materials", label: "Materials" },
];

export function LessonPlanFormModal({
  open,
  onClose,
  studentId,
  existing,
}: {
  open: boolean;
  onClose: () => void;
  studentId: string;
  existing?: LessonPlan;
}) {
  const addLessonPlan = useStore((s) => s.addLessonPlan);
  const updateLessonPlan = useStore((s) => s.updateLessonPlan);
  const [date, setDate] = useState(existing ? existing.date.slice(0, 10) : new Date().toISOString().slice(0, 10));
  const [values, setValues] = useState<Record<string, string>>(
    Object.fromEntries(FIELDS.map((f) => [f.key, (existing?.[f.key] as string) ?? ""]))
  );

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const payload = {
      date: new Date(date).toISOString(),
      objectives: values.objectives,
      targetVocabulary: values.targetVocabulary,
      grammar: values.grammar,
      activities: values.activities,
      games: values.games,
      homeworkPlan: values.homeworkPlan,
      expectedDifficulties: values.expectedDifficulties,
      materials: values.materials,
      homeworkReview: existing?.homeworkReview ?? "",
      reflectionAfterLesson: existing?.reflectionAfterLesson ?? "",
      thingsToRepeat: existing?.thingsToRepeat ?? "",
      thingsMastered: existing?.thingsMastered ?? "",
      status: (existing?.status ?? "planned") as "planned" | "completed",
    };
    if (existing) {
      updateLessonPlan(studentId, existing.id, payload);
    } else {
      addLessonPlan(studentId, payload);
    }
    onClose();
  }

  return (
    <Modal open={open} onClose={onClose} title={existing ? "Edit lesson plan" : "New lesson plan"} wide>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <Label>Planned date</Label>
          <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="max-w-xs" />
        </div>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          {FIELDS.map((f) => (
            <div key={f.key}>
              <Label>{f.label}</Label>
              <Textarea
                rows={2}
                value={values[f.key]}
                onChange={(e) => setValues((v) => ({ ...v, [f.key]: e.target.value }))}
              />
            </div>
          ))}
        </div>
        <div className="flex justify-end gap-2 pt-2">
          <Button type="button" variant="ghost" onClick={onClose}>
            Cancel
          </Button>
          <Button type="submit">{existing ? "Save changes" : "Create plan"}</Button>
        </div>
      </form>
    </Modal>
  );
}

"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Modal } from "@/components/ui/Modal";
import { Input, Label, Select, Textarea } from "@/components/ui/Input";
import { Button } from "@/components/ui/Button";
import { useStore } from "@/lib/store";
import { CEFRLevel } from "@/lib/types";

const EMOJIS = ["🌿", "🌸", "🍁", "🎨", "⚡", "🧭", "🌱", "☀️", "🌊", "🦋"];
const COLORS = ["sage", "dusty", "coral", "beige"] as const;

export function AddStudentModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const addStudent = useStore((s) => s.addStudent);
  const router = useRouter();
  const [name, setName] = useState("");
  const [age, setAge] = useState(18);
  const [level, setLevel] = useState<CEFRLevel>("A1");
  const [occupation, setOccupation] = useState("");
  const [goals, setGoals] = useState("");
  const [interests, setInterests] = useState("");
  const [courseName, setCourseName] = useState("General English");

  function reset() {
    setName("");
    setAge(18);
    setLevel("A1");
    setOccupation("");
    setGoals("");
    setInterests("");
    setCourseName("General English");
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!name.trim()) return;
    const emoji = EMOJIS[Math.floor(name.length % EMOJIS.length)];
    const color = COLORS[name.length % COLORS.length];
    const id = addStudent({
      name: name.trim(),
      age,
      level,
      occupation,
      avatarEmoji: emoji,
      avatarColor: color,
      goals: goals.split(",").map((g) => g.trim()).filter(Boolean),
      interests: interests.split(",").map((g) => g.trim()).filter(Boolean),
      course: { name: courseName, unit: "Unit 1", lesson: "Lesson 1", teacher: "Ms. Olga" },
    });
    reset();
    onClose();
    router.push(`/teacher/students/${id}`);
  }

  return (
    <Modal open={open} onClose={onClose} title="Add a new student">
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <Label>Full name</Label>
          <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Maria Kovalenko" required />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label>Age</Label>
            <Input type="number" min={5} max={99} value={age} onChange={(e) => setAge(Number(e.target.value))} />
          </div>
          <div>
            <Label>English level</Label>
            <Select value={level} onChange={(e) => setLevel(e.target.value as CEFRLevel)}>
              {["A1", "A2", "B1", "B2", "C1", "C2"].map((l) => (
                <option key={l} value={l}>
                  {l}
                </option>
              ))}
            </Select>
          </div>
        </div>
        <div>
          <Label>Occupation</Label>
          <Input value={occupation} onChange={(e) => setOccupation(e.target.value)} placeholder="e.g. Marketing Manager" />
        </div>
        <div>
          <Label>Course name</Label>
          <Input value={courseName} onChange={(e) => setCourseName(e.target.value)} />
        </div>
        <div>
          <Label>Goals (comma separated)</Label>
          <Textarea value={goals} onChange={(e) => setGoals(e.target.value)} placeholder="Reach B2, Pass IELTS" rows={2} />
        </div>
        <div>
          <Label>Interests (comma separated)</Label>
          <Input value={interests} onChange={(e) => setInterests(e.target.value)} placeholder="Travel, movies, cooking" />
        </div>
        <div className="flex justify-end gap-2 pt-2">
          <Button type="button" variant="ghost" onClick={onClose}>
            Cancel
          </Button>
          <Button type="submit">Add student</Button>
        </div>
      </form>
    </Modal>
  );
}

"use client";

import { Sparkles } from "lucide-react";
import { Student } from "@/lib/types";
import { Card } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { EmptyState } from "@/components/ui/EmptyState";
import { formatDate, moodEmoji } from "@/lib/utils";

const NOTE_FIELDS: { key: keyof Student["studentNotes"]; label: string; emoji: string }[] = [
  { key: "todaysAchievement", label: "Today's achievement", emoji: "🌟" },
  { key: "whatToPractise", label: "What to practise", emoji: "🎯" },
  { key: "positiveFeedback", label: "Positive feedback", emoji: "💚" },
  { key: "weeklyChallenge", label: "Weekly challenge", emoji: "🔥" },
  { key: "monthlyGoal", label: "Monthly goal", emoji: "🗓️" },
];

export function StudentLessonNotesView({ student }: { student: Student }) {
  const lessons = [...student.lessons].sort((a, b) => b.date.localeCompare(a.date));

  return (
    <div className="space-y-6">
      <Card className="p-5" hoverLift={false}>
        <div className="mb-4 flex items-center gap-2">
          <Sparkles size={16} className="text-sage-deep" />
          <h3 className="font-display text-base font-semibold text-ink">From your teacher</h3>
        </div>
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          {NOTE_FIELDS.map((f) => (
            <div key={f.key} className="rounded-xl bg-canvas-soft/60 p-3">
              <p className="text-xs font-semibold text-ink-faint">{f.emoji} {f.label}</p>
              <p className="mt-1 text-sm text-ink-soft">{(student.studentNotes[f.key] as string) || "—"}</p>
            </div>
          ))}
        </div>
      </Card>

      <div>
        <h3 className="mb-3 font-display text-base font-semibold text-ink">Lesson notes</h3>
        {lessons.length === 0 ? (
          <EmptyState icon="📔" title="No lesson notes yet" />
        ) : (
          <div className="space-y-3">
            {lessons.map((l) => (
              <Card key={l.id} className="p-4" hoverLift={false}>
                <div className="mb-2 flex items-start justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-xl">{moodEmoji(l.mood)}</span>
                    <div>
                      <p className="font-medium text-ink">{l.topic}</p>
                      <p className="text-xs text-ink-soft">{formatDate(l.date)}</p>
                    </div>
                  </div>
                  <Badge tone="sage">{l.attendance}</Badge>
                </div>
                <p className="text-sm text-ink-soft">{l.lessonNotes}</p>
                {l.vocabularyLearned.length > 0 && (
                  <p className="mt-2 text-xs text-ink-faint">Vocabulary: {l.vocabularyLearned.join(", ")}</p>
                )}
                {l.grammar && <p className="text-xs text-ink-faint">Grammar: {l.grammar}</p>}
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

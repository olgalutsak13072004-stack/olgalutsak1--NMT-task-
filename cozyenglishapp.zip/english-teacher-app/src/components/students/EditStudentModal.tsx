"use client";

import { useState } from "react";
import { Modal } from "@/components/ui/Modal";
import { Input, Label, Select, Textarea } from "@/components/ui/Input";
import { Button } from "@/components/ui/Button";
import { useStore } from "@/lib/store";
import { CEFRLevel, Student } from "@/lib/types";

export function EditStudentModal({ open, onClose, student }: { open: boolean; onClose: () => void; student: Student }) {
  const updateStudent = useStore((s) => s.updateStudent);
  const [form, setForm] = useState({
    name: student.name,
    age: student.age,
    level: student.level,
    occupation: student.occupation,
    goals: student.goals.join(", "),
    interests: student.interests.join(", "),
    courseName: student.course.name,
    unit: student.course.unit,
    lesson: student.course.lesson,
    speaking: student.confidence.speaking,
    grammar: student.confidence.grammar,
    vocabulary: student.confidence.vocabulary,
    pronunciation: student.confidence.pronunciation,
  });

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    updateStudent(student.id, {
      name: form.name,
      age: form.age,
      level: form.level as CEFRLevel,
      occupation: form.occupation,
      goals: form.goals.split(",").map((g) => g.trim()).filter(Boolean),
      interests: form.interests.split(",").map((g) => g.trim()).filter(Boolean),
      course: { ...student.course, name: form.courseName, unit: form.unit, lesson: form.lesson },
      confidence: {
        speaking: form.speaking,
        grammar: form.grammar,
        vocabulary: form.vocabulary,
        pronunciation: form.pronunciation,
      },
    });
    onClose();
  }

  return (
    <Modal open={open} onClose={onClose} title={`Edit ${student.name}`} wide>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
          <div className="col-span-2 sm:col-span-1">
            <Label>Name</Label>
            <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          </div>
          <div>
            <Label>Age</Label>
            <Input type="number" value={form.age} onChange={(e) => setForm({ ...form, age: Number(e.target.value) })} />
          </div>
          <div>
            <Label>Level</Label>
            <Select value={form.level} onChange={(e) => setForm({ ...form, level: e.target.value as CEFRLevel })}>
              {["A1", "A2", "B1", "B2", "C1", "C2"].map((l) => (
                <option key={l} value={l}>
                  {l}
                </option>
              ))}
            </Select>
          </div>
        </div>
        <div>
          <Label>Occupation</Label>
          <Input value={form.occupation} onChange={(e) => setForm({ ...form, occupation: e.target.value })} />
        </div>
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
          <div>
            <Label>Course name</Label>
            <Input value={form.courseName} onChange={(e) => setForm({ ...form, courseName: e.target.value })} />
          </div>
          <div>
            <Label>Unit</Label>
            <Input value={form.unit} onChange={(e) => setForm({ ...form, unit: e.target.value })} />
          </div>
          <div>
            <Label>Lesson</Label>
            <Input value={form.lesson} onChange={(e) => setForm({ ...form, lesson: e.target.value })} />
          </div>
        </div>
        <div>
          <Label>Goals (comma separated)</Label>
          <Textarea rows={2} value={form.goals} onChange={(e) => setForm({ ...form, goals: e.target.value })} />
        </div>
        <div>
          <Label>Interests (comma separated)</Label>
          <Input value={form.interests} onChange={(e) => setForm({ ...form, interests: e.target.value })} />
        </div>

        <div>
          <Label>Confidence levels</Label>
          <div className="grid grid-cols-2 gap-4 rounded-xl border border-border bg-canvas-soft/50 p-3">
            {(["speaking", "grammar", "vocabulary", "pronunciation"] as const).map((key) => (
              <div key={key}>
                <div className="mb-1 flex justify-between text-xs text-ink-soft">
                  <span className="capitalize">{key}</span>
                  <span>{form[key]}%</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={100}
                  value={form[key]}
                  onChange={(e) => setForm({ ...form, [key]: Number(e.target.value) })}
                  className="w-full accent-[var(--color-sage)]"
                />
              </div>
            ))}
          </div>
        </div>

        <div className="flex justify-end gap-2 pt-2">
          <Button type="button" variant="ghost" onClick={onClose}>
            Cancel
          </Button>
          <Button type="submit">Save changes</Button>
        </div>
      </form>
    </Modal>
  );
}

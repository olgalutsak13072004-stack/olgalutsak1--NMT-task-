"use client";

import { useState } from "react";
import { Plus } from "lucide-react";
import { Student, TestType } from "@/lib/types";
import { Card } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { ProgressBar } from "@/components/ui/ProgressBar";
import { Input, Label, Select, Textarea } from "@/components/ui/Input";
import { Modal } from "@/components/ui/Modal";
import { EmptyState } from "@/components/ui/EmptyState";
import { useStore } from "@/lib/store";
import { formatDate } from "@/lib/utils";

const typeLabel: Record<TestType, string> = {
  "mid-course": "Mid-course test",
  unit: "Unit test",
  final: "Final test",
  revision: "Revision test",
  "mock-exam": "Mock exam",
};

export function TestsTab({ student }: { student: Student }) {
  const addTest = useStore((s) => s.addTest);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({
    title: "",
    type: "unit" as TestType,
    date: new Date().toISOString().slice(0, 10),
    score: 80,
    maxScore: 100,
    notes: "",
  });

  const tests = [...student.tests].sort((a, b) => b.date.localeCompare(a.date));

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    addTest(student.id, { ...form, date: new Date(form.date).toISOString() });
    setForm({ title: "", type: "unit", date: new Date().toISOString().slice(0, 10), score: 80, maxScore: 100, notes: "" });
    setOpen(false);
  }

  return (
    <div>
      <div className="mb-4 flex items-center justify-between">
        <p className="text-sm text-ink-soft">{tests.length} test{tests.length !== 1 ? "s" : ""} on record — each one automatically updates progress stats</p>
        <Button size="sm" onClick={() => setOpen(true)} className="gap-1.5">
          <Plus size={14} /> Create test
        </Button>
      </div>

      {tests.length === 0 ? (
        <EmptyState icon="🧪" title="No tests yet" description="Create mid-course, unit, final, revision tests or mock exams to track results." action={<Button onClick={() => setOpen(true)}>Create test</Button>} />
      ) : (
        <div className="space-y-3">
          {tests.map((t) => (
            <Card key={t.id} className="p-4" hoverLift={false}>
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <p className="font-medium text-ink">{t.title}</p>
                  <p className="text-xs text-ink-soft">{formatDate(t.date)} · {typeLabel[t.type]}</p>
                </div>
                <Badge tone={t.score / t.maxScore >= 0.8 ? "sage" : t.score / t.maxScore >= 0.6 ? "dusty" : "coral"}>
                  {t.score}/{t.maxScore}
                </Badge>
              </div>
              <div className="mt-3">
                <ProgressBar value={(t.score / t.maxScore) * 100} showValue={false} tone="dusty" size="sm" />
              </div>
              {t.notes && <p className="mt-2 text-xs text-ink-soft">{t.notes}</p>}
            </Card>
          ))}
        </div>
      )}

      <Modal open={open} onClose={() => setOpen(false)} title="Create a test">
        <form onSubmit={handleSubmit} className="space-y-3">
          <div>
            <Label>Title</Label>
            <Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} required />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>Type</Label>
              <Select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value as TestType })}>
                {Object.entries(typeLabel).map(([k, v]) => (
                  <option key={k} value={k}>
                    {v}
                  </option>
                ))}
              </Select>
            </div>
            <div>
              <Label>Date</Label>
              <Input type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} />
            </div>
            <div>
              <Label>Score</Label>
              <Input type="number" value={form.score} onChange={(e) => setForm({ ...form, score: Number(e.target.value) })} />
            </div>
            <div>
              <Label>Max score</Label>
              <Input type="number" value={form.maxScore} onChange={(e) => setForm({ ...form, maxScore: Number(e.target.value) })} />
            </div>
          </div>
          <div>
            <Label>Notes</Label>
            <Textarea rows={2} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} />
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <Button type="button" variant="ghost" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button type="submit">Save test</Button>
          </div>
        </form>
      </Modal>
    </div>
  );
}

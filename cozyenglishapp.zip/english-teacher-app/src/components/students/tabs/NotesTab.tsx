"use client";

import { useState } from "react";
import { Lock, Eye, Plus } from "lucide-react";
import { Student } from "@/lib/types";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { Textarea, Label } from "@/components/ui/Input";
import { useStore } from "@/lib/store";
import { formatDate } from "@/lib/utils";

const STUDENT_NOTE_FIELDS: { key: keyof Student["studentNotes"]; label: string }[] = [
  { key: "todaysAchievement", label: "Today's achievement" },
  { key: "whatToPractise", label: "What to practise" },
  { key: "homework", label: "Homework" },
  { key: "vocabulary", label: "Vocabulary" },
  { key: "positiveFeedback", label: "Positive feedback" },
  { key: "weeklyChallenge", label: "Weekly challenge" },
  { key: "monthlyGoal", label: "Monthly goal" },
];

export function NotesTab({ student }: { student: Student }) {
  const addTeacherNote = useStore((s) => s.addTeacherNote);
  const updateStudentNotes = useStore((s) => s.updateStudentNotes);
  const [newNote, setNewNote] = useState("");
  const [studentNotesForm, setStudentNotesForm] = useState(student.studentNotes);

  function saveStudentNotes() {
    updateStudentNotes(student.id, studentNotesForm);
  }

  function handleAddNote(e: React.FormEvent) {
    e.preventDefault();
    if (!newNote.trim()) return;
    addTeacherNote(student.id, newNote.trim());
    setNewNote("");
  }

  return (
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
      <Card className="p-5" hoverLift={false}>
        <div className="mb-4 flex items-center gap-2">
          <Lock size={15} className="text-coral" />
          <h3 className="font-display text-base font-semibold text-ink">Teacher notes</h3>
          <span className="ml-auto text-[11px] font-medium text-ink-faint">Private — only you can see this</span>
        </div>
        <form onSubmit={handleAddNote} className="mb-4 flex gap-2">
          <Textarea value={newNote} onChange={(e) => setNewNote(e.target.value)} rows={2} placeholder="Personal observation, motivation tip, reminder…" />
          <Button type="submit" size="icon" className="shrink-0">
            <Plus size={16} />
          </Button>
        </form>
        <div className="space-y-2.5">
          {student.teacherNotes.map((n) => (
            <div key={n.id} className="rounded-xl bg-canvas-soft/60 p-3">
              <p className="text-sm text-ink-soft">{n.text}</p>
              <p className="mt-1 text-[11px] text-ink-faint">{formatDate(n.date)}</p>
            </div>
          ))}
          {student.teacherNotes.length === 0 && <p className="text-sm text-ink-faint">No private notes yet.</p>}
        </div>
      </Card>

      <Card className="p-5" hoverLift={false}>
        <div className="mb-4 flex items-center gap-2">
          <Eye size={15} className="text-sage-deep" />
          <h3 className="font-display text-base font-semibold text-ink">Student notes</h3>
          <span className="ml-auto text-[11px] font-medium text-ink-faint">Visible to student</span>
        </div>
        <div className="space-y-3">
          {STUDENT_NOTE_FIELDS.map((f) => (
            <div key={f.key}>
              <Label>{f.label}</Label>
              <Textarea
                rows={2}
                value={studentNotesForm[f.key] as string}
                onChange={(e) => setStudentNotesForm((v) => ({ ...v, [f.key]: e.target.value }))}
                onBlur={saveStudentNotes}
              />
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}

"use client";

import { Student } from "@/lib/types";
import { EmptyState } from "@/components/ui/EmptyState";
import { formatDate } from "@/lib/utils";

const TYPE_ICON: Record<string, string> = {
  "first-lesson": "🌱",
  achievement: "🏆",
  "unit-complete": "✅",
  test: "🧪",
  certificate: "📜",
  feedback: "💬",
  goal: "🎯",
  "vocabulary-milestone": "📚",
};

export function TimelineTab({ student }: { student: Student }) {
  const events = [...student.timeline].sort((a, b) => a.date.localeCompare(b.date));

  if (events.length === 0) return <EmptyState icon="🕰️" title="No timeline events yet" />;

  return (
    <div className="relative pl-6">
      <div className="absolute bottom-2 left-[11px] top-2 w-px bg-border" />
      <div className="space-y-6">
        {events.map((e) => (
          <div key={e.id} className="relative">
            <div className="absolute -left-6 flex h-6 w-6 items-center justify-center rounded-full bg-sage-soft text-sm">
              {TYPE_ICON[e.type] ?? "✨"}
            </div>
            <p className="text-xs text-ink-faint">{formatDate(e.date)}</p>
            <p className="font-medium text-ink">{e.title}</p>
            {e.description && <p className="text-sm text-ink-soft">{e.description}</p>}
          </div>
        ))}
      </div>
    </div>
  );
}

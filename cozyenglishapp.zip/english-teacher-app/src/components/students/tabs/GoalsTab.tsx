"use client";

import { useState } from "react";
import { Plus, Check } from "lucide-react";
import { Student } from "@/lib/types";
import { Card } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { ProgressBar } from "@/components/ui/ProgressBar";
import { Input, Label } from "@/components/ui/Input";
import { Modal } from "@/components/ui/Modal";
import { EmptyState } from "@/components/ui/EmptyState";
import { useStore } from "@/lib/store";
import { cn, daysUntil, formatDate } from "@/lib/utils";

export function GoalsTab({ student, readOnly }: { student: Student; readOnly?: boolean }) {
  const addLearningGoal = useStore((s) => s.addLearningGoal);
  const toggleMilestone = useStore((s) => s.toggleMilestone);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ title: "", deadline: "", milestones: "" });

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    addLearningGoal(student.id, {
      title: form.title,
      progress: 0,
      deadline: new Date(form.deadline || Date.now()).toISOString(),
      milestones: form.milestones
        .split(",")
        .map((m) => m.trim())
        .filter(Boolean)
        .map((label, i) => ({ id: `m-${Date.now()}-${i}`, label, done: false })),
    });
    setForm({ title: "", deadline: "", milestones: "" });
    setOpen(false);
  }

  return (
    <div>
      {!readOnly && (
        <div className="mb-4 flex items-center justify-between">
          <p className="text-sm text-ink-soft">{student.learningGoals.length} active goal{student.learningGoals.length !== 1 ? "s" : ""}</p>
          <Button size="sm" onClick={() => setOpen(true)} className="gap-1.5">
            <Plus size={14} /> Set goal
          </Button>
        </div>
      )}

      {student.learningGoals.length === 0 ? (
        <EmptyState icon="🎯" title="No learning goals yet" description="Set goals like reaching B2, passing IELTS, or learning 1000 words." />
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          {student.learningGoals.map((g) => {
            const days = daysUntil(g.deadline);
            return (
              <Card key={g.id} className="p-5" hoverLift={false}>
                <div className="mb-2 flex items-start justify-between">
                  <p className="font-display text-base font-semibold text-ink">🎯 {g.title}</p>
                  <Badge tone={days < 14 ? "coral" : "beige"}>{days >= 0 ? `${days}d left` : "Overdue"}</Badge>
                </div>
                <p className="mb-3 text-xs text-ink-soft">Deadline: {formatDate(g.deadline)}</p>
                <ProgressBar value={g.progress} tone="sage" />
                {g.milestones.length > 0 && (
                  <div className="mt-4 space-y-1.5">
                    {g.milestones.map((m) => (
                      <button
                        key={m.id}
                        disabled={readOnly}
                        onClick={() => toggleMilestone(student.id, g.id, m.id)}
                        className={cn(
                          "flex w-full items-center gap-2 rounded-lg px-2 py-1.5 text-left text-sm transition-colors",
                          !readOnly && "hover:bg-canvas-soft"
                        )}
                      >
                        <span
                          className={cn(
                            "flex h-4 w-4 shrink-0 items-center justify-center rounded-full border",
                            m.done ? "border-sage bg-sage text-white" : "border-border"
                          )}
                        >
                          {m.done && <Check size={11} />}
                        </span>
                        <span className={cn(m.done ? "text-ink-faint line-through" : "text-ink-soft")}>{m.label}</span>
                      </button>
                    ))}
                  </div>
                )}
              </Card>
            );
          })}
        </div>
      )}

      <Modal open={open} onClose={() => setOpen(false)} title="Set a learning goal">
        <form onSubmit={handleSubmit} className="space-y-3">
          <div>
            <Label>Goal</Label>
            <Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} placeholder="e.g. Reach B2" required />
          </div>
          <div>
            <Label>Deadline</Label>
            <Input type="date" value={form.deadline} onChange={(e) => setForm({ ...form, deadline: e.target.value })} />
          </div>
          <div>
            <Label>Milestones (comma separated)</Label>
            <Input value={form.milestones} onChange={(e) => setForm({ ...form, milestones: e.target.value })} placeholder="Complete unit 3, Pass mock test" />
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <Button type="button" variant="ghost" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button type="submit">Set goal</Button>
          </div>
        </form>
      </Modal>
    </div>
  );
}

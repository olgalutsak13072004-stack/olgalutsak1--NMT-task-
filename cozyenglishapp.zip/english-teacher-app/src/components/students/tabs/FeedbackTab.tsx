"use client";

import { useMemo, useState } from "react";
import { Plus, Search } from "lucide-react";
import { Student } from "@/lib/types";
import { Card } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { Input, Textarea } from "@/components/ui/Input";
import { Modal } from "@/components/ui/Modal";
import { EmptyState } from "@/components/ui/EmptyState";
import { useStore } from "@/lib/store";
import { cn, daysBetween, formatDate } from "@/lib/utils";

const NOW = "2026-07-27T09:00:00Z";
type RangeKey = "week" | "month" | "lastMonth" | "all";

export function FeedbackTab({ student, role = "teacher" }: { student: Student; role?: "teacher" | "student" }) {
  const addFeedback = useStore((s) => s.addFeedback);
  const [range, setRange] = useState<RangeKey>("all");
  const [query, setQuery] = useState("");
  const [open, setOpen] = useState(false);
  const [text, setText] = useState("");

  const filtered = useMemo(() => {
    let list = [...student.feedback].sort((a, b) => b.date.localeCompare(a.date));
    if (range === "week") list = list.filter((f) => daysBetween(f.date, NOW) <= 7);
    if (range === "month") list = list.filter((f) => daysBetween(f.date, NOW) <= 30);
    if (range === "lastMonth") list = list.filter((f) => daysBetween(f.date, NOW) > 30 && daysBetween(f.date, NOW) <= 60);
    if (query.trim()) list = list.filter((f) => f.text.toLowerCase().includes(query.toLowerCase()));
    return list;
  }, [student.feedback, range, query]);

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    addFeedback(student.id, { date: new Date().toISOString(), author: role, text });
    setText("");
    setOpen(false);
  }

  return (
    <div>
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <div className="relative">
          <Search size={14} className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-ink-faint" />
          <Input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search feedback…" className="w-56 pl-8" />
        </div>
        <div className="flex items-center gap-2">
          <div className="inline-flex rounded-full border border-border bg-canvas-soft p-1">
            {([
              ["week", "This week"],
              ["month", "This month"],
              ["lastMonth", "Last month"],
              ["all", "All time"],
            ] as [RangeKey, string][]).map(([key, label]) => (
              <button
                key={key}
                onClick={() => setRange(key)}
                className={cn(
                  "rounded-full px-3 py-1.5 text-xs font-medium transition-colors",
                  range === key ? "bg-surface text-ink shadow-[var(--shadow-cozy)]" : "text-ink-soft"
                )}
              >
                {label}
              </button>
            ))}
          </div>
          <Button size="sm" onClick={() => setOpen(true)} className="gap-1.5">
            <Plus size={14} /> Add feedback
          </Button>
        </div>
      </div>

      {filtered.length === 0 ? (
        <EmptyState icon="💬" title="No feedback found" description="Feedback from lessons will be stored here forever." />
      ) : (
        <div className="space-y-3">
          {filtered.map((f) => (
            <Card key={f.id} className="p-4" hoverLift={false}>
              <div className="mb-1.5 flex items-center justify-between">
                <Badge tone={f.author === "teacher" ? "sage" : "dusty"}>{f.author === "teacher" ? "Teacher" : "Student"}</Badge>
                <span className="text-xs text-ink-faint">{formatDate(f.date)}</span>
              </div>
              <p className="text-sm text-ink-soft">{f.text}</p>
            </Card>
          ))}
        </div>
      )}

      <Modal open={open} onClose={() => setOpen(false)} title="Add feedback">
        <form onSubmit={handleSubmit} className="space-y-3">
          <Textarea value={text} onChange={(e) => setText(e.target.value)} rows={4} placeholder="Write feedback…" required />
          <div className="flex justify-end gap-2 pt-2">
            <Button type="button" variant="ghost" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button type="submit">Save feedback</Button>
          </div>
        </form>
      </Modal>
    </div>
  );
}

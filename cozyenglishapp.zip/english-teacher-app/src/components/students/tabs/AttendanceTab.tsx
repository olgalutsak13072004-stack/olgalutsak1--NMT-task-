"use client";

import { useState } from "react";
import { Plus } from "lucide-react";
import { Student, AttendanceStatus } from "@/lib/types";
import { Card } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { CircularProgress } from "@/components/ui/ProgressBar";
import { Input, Label, Select } from "@/components/ui/Input";
import { Modal } from "@/components/ui/Modal";
import { EmptyState } from "@/components/ui/EmptyState";
import { useStore } from "@/lib/store";
import { formatDate } from "@/lib/utils";

const statusTone: Record<AttendanceStatus, "sage" | "coral" | "dusty" | "beige"> = {
  present: "sage",
  late: "dusty",
  absent: "coral",
  cancelled: "beige",
  rescheduled: "beige",
};

export function AttendanceTab({ student }: { student: Student }) {
  const addAttendance = useStore((s) => s.addAttendance);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ date: new Date().toISOString().slice(0, 10), status: "present" as AttendanceStatus });

  const records = [...student.attendance].sort((a, b) => b.date.localeCompare(a.date));
  const counts = records.reduce<Record<string, number>>((acc, r) => {
    acc[r.status] = (acc[r.status] ?? 0) + 1;
    return acc;
  }, {});

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    addAttendance(student.id, { date: new Date(form.date).toISOString(), status: form.status });
    setOpen(false);
  }

  return (
    <div>
      <div className="mb-5 grid grid-cols-1 gap-4 sm:grid-cols-[auto_1fr]">
        <Card className="flex flex-col items-center justify-center p-6" hoverLift={false}>
          <CircularProgress value={student.scores.attendance} size={110} tone="dusty" label="Attendance" />
        </Card>
        <Card className="grid grid-cols-2 gap-3 p-5 sm:grid-cols-5" hoverLift={false}>
          {(["present", "late", "absent", "cancelled", "rescheduled"] as const).map((s) => (
            <div key={s} className="text-center">
              <p className="font-display text-xl font-semibold text-ink">{counts[s] ?? 0}</p>
              <p className="text-[11px] capitalize text-ink-soft">{s}</p>
            </div>
          ))}
        </Card>
      </div>

      <div className="mb-3 flex items-center justify-between">
        <p className="text-sm text-ink-soft">{records.length} record{records.length !== 1 ? "s" : ""}</p>
        <Button size="sm" onClick={() => setOpen(true)} className="gap-1.5">
          <Plus size={14} /> Log attendance
        </Button>
      </div>

      {records.length === 0 ? (
        <EmptyState icon="📅" title="No attendance records yet" />
      ) : (
        <div className="overflow-hidden rounded-2xl border border-border">
          {records.map((r, i) => (
            <div key={r.id} className={`flex items-center justify-between px-4 py-3 text-sm ${i % 2 === 0 ? "bg-surface" : "bg-canvas-soft/50"}`}>
              <span className="text-ink-soft">{formatDate(r.date)}</span>
              <Badge tone={statusTone[r.status]}>{r.status}</Badge>
            </div>
          ))}
        </div>
      )}

      <Modal open={open} onClose={() => setOpen(false)} title="Log attendance">
        <form onSubmit={handleSubmit} className="space-y-3">
          <div>
            <Label>Date</Label>
            <Input type="date" value={form.date} onChange={(e) => setForm({ ...form, date: e.target.value })} />
          </div>
          <div>
            <Label>Status</Label>
            <Select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value as AttendanceStatus })}>
              {["present", "late", "absent", "cancelled", "rescheduled"].map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </Select>
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <Button type="button" variant="ghost" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button type="submit">Save</Button>
          </div>
        </form>
      </Modal>
    </div>
  );
}

"use client";

import { useState } from "react";
import { Plus, CheckCircle2, Pencil, Trash2, Sparkles } from "lucide-react";
import { Student } from "@/lib/types";
import { Card } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { Textarea, Label } from "@/components/ui/Input";
import { EmptyState } from "@/components/ui/EmptyState";
import { LessonPlanFormModal } from "../LessonPlanFormModal";
import { LessonFormModal } from "../LessonFormModal";
import { useStore } from "@/lib/store";
import { formatDate } from "@/lib/utils";

export function PlanningTab({ student }: { student: Student }) {
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<string | null>(null);
  const [converting, setConverting] = useState<string | null>(null);
  const updateLessonPlan = useStore((s) => s.updateLessonPlan);
  const deleteLessonPlan = useStore((s) => s.deleteLessonPlan);

  const plans = [...student.lessonPlans].sort((a, b) => b.date.localeCompare(a.date));
  const editingPlan = plans.find((p) => p.id === editing);
  const convertingPlan = plans.find((p) => p.id === converting);

  return (
    <div>
      <div className="mb-4 flex items-center justify-between">
        <p className="text-sm text-ink-soft">{plans.length} lesson plan{plans.length !== 1 ? "s" : ""}</p>
        <Button onClick={() => setFormOpen(true)} className="gap-1.5">
          <Plus size={16} /> New plan
        </Button>
      </div>

      {plans.length === 0 ? (
        <EmptyState icon="🗂️" title="No lesson plans yet" description="Plan objectives, activities and materials ahead of the next lesson." action={<Button onClick={() => setFormOpen(true)}>New plan</Button>} />
      ) : (
        <div className="space-y-4">
          {plans.map((p) => (
            <Card key={p.id} className="p-5" hoverLift={false}>
              <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <p className="font-display text-base font-semibold text-ink">{formatDate(p.date)}</p>
                  <Badge tone={p.status === "completed" ? "sage" : "dusty"}>{p.status}</Badge>
                </div>
                <div className="flex items-center gap-1">
                  {p.status === "planned" && (
                    <Button size="sm" variant="outline" onClick={() => setConverting(p.id)} className="gap-1">
                      <CheckCircle2 size={13} /> Mark taught
                    </Button>
                  )}
                  <Button size="sm" variant="ghost" onClick={() => setEditing(p.id)} className="gap-1">
                    <Pencil size={13} />
                  </Button>
                  <Button size="sm" variant="ghost" onClick={() => deleteLessonPlan(student.id, p.id)} className="gap-1 text-coral">
                    <Trash2 size={13} />
                  </Button>
                </div>
              </div>
              <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                <PlanField label="Objectives" value={p.objectives} />
                <PlanField label="Target vocabulary" value={p.targetVocabulary} />
                <PlanField label="Grammar" value={p.grammar} />
                <PlanField label="Activities" value={p.activities} />
                <PlanField label="Games" value={p.games} />
                <PlanField label="Homework" value={p.homeworkPlan} />
                <PlanField label="Expected difficulties" value={p.expectedDifficulties} />
                <PlanField label="Materials" value={p.materials} />
              </div>

              {p.status === "completed" && (
                <div className="mt-4 border-t border-border pt-4">
                  <ReflectionEditor studentId={student.id} plan={p} />
                </div>
              )}
            </Card>
          ))}
        </div>
      )}

      <LessonPlanFormModal open={formOpen} onClose={() => setFormOpen(false)} studentId={student.id} />
      {editingPlan && (
        <LessonPlanFormModal open={!!editingPlan} onClose={() => setEditing(null)} studentId={student.id} existing={editingPlan} />
      )}
      {convertingPlan && (
        <LessonFormModal
          open={!!convertingPlan}
          onClose={() => {
            updateLessonPlan(student.id, convertingPlan.id, { status: "completed" });
            setConverting(null);
          }}
          studentId={student.id}
          prefill={{
            topic: convertingPlan.objectives,
            grammar: convertingPlan.grammar,
            homework: convertingPlan.homeworkPlan,
            vocabularyLearned: convertingPlan.targetVocabulary.split(",").map((v) => v.trim()).filter(Boolean),
          }}
        />
      )}
    </div>
  );
}

function PlanField({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <p className="text-xs font-semibold text-ink-faint">{label}</p>
      <p className="mt-0.5 text-sm text-ink-soft">{value || "—"}</p>
    </div>
  );
}

function ReflectionEditor({ studentId, plan }: { studentId: string; plan: Student["lessonPlans"][number] }) {
  const updateLessonPlan = useStore((s) => s.updateLessonPlan);
  const [values, setValues] = useState({
    homeworkReview: plan.homeworkReview,
    reflectionAfterLesson: plan.reflectionAfterLesson,
    thingsToRepeat: plan.thingsToRepeat,
    thingsMastered: plan.thingsMastered,
  });

  function save() {
    updateLessonPlan(studentId, plan.id, values);
  }

  return (
    <div>
      <div className="mb-2 flex items-center gap-1.5 text-sm font-semibold text-ink">
        <Sparkles size={14} className="text-sage-deep" /> Post-lesson reflection
      </div>
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
        <div>
          <Label>Homework review</Label>
          <Textarea rows={2} value={values.homeworkReview} onChange={(e) => setValues((v) => ({ ...v, homeworkReview: e.target.value }))} onBlur={save} />
        </div>
        <div>
          <Label>Reflection after lesson</Label>
          <Textarea rows={2} value={values.reflectionAfterLesson} onChange={(e) => setValues((v) => ({ ...v, reflectionAfterLesson: e.target.value }))} onBlur={save} />
        </div>
        <div>
          <Label>Things to repeat next lesson</Label>
          <Textarea rows={2} value={values.thingsToRepeat} onChange={(e) => setValues((v) => ({ ...v, thingsToRepeat: e.target.value }))} onBlur={save} />
        </div>
        <div>
          <Label>Things student mastered</Label>
          <Textarea rows={2} value={values.thingsMastered} onChange={(e) => setValues((v) => ({ ...v, thingsMastered: e.target.value }))} onBlur={save} />
        </div>
      </div>
    </div>
  );
}

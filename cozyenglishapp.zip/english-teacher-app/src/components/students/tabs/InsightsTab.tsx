"use client";

import { Sparkles, TrendingUp, TrendingDown, Target } from "lucide-react";
import { Student } from "@/lib/types";
import { Card } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { generateInsights, recommendedRevisionTopics, estimatedCompletionMonths } from "@/lib/insights";
import { weakestSkills, strongestSkills } from "@/lib/scoring";
import { estimateCEFR } from "@/lib/utils";
import { SKILL_META } from "@/lib/skill-meta";

export function InsightsTab({ student }: { student: Student }) {
  const insights = generateInsights(student);
  const topics = recommendedRevisionTopics(student);
  const months = estimatedCompletionMonths(student);
  const cefr = estimateCEFR(student.level, student.scores.overall);
  const weak = weakestSkills(student.scores, 2);
  const strong = strongestSkills(student.scores, 2);
  const skillLabel = (k: string) => SKILL_META.find((m) => m.key === k)?.label ?? k;

  return (
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
      <div className="space-y-4 lg:col-span-2">
        <Card className="p-5" hoverLift={false}>
          <div className="mb-4 flex items-center gap-2">
            <Sparkles size={17} className="text-sage-deep" />
            <h3 className="font-display text-lg font-semibold text-ink">AI Insights</h3>
          </div>
          <div className="space-y-3">
            {insights.map((i) => (
              <div
                key={i.id}
                className={`rounded-xl border p-3 text-sm ${
                  i.tone === "positive" ? "border-sage-soft bg-sage-soft/40 text-sage-deep" : i.tone === "warning" ? "border-coral-soft bg-coral-soft/40 text-coral" : "border-border bg-canvas-soft/60 text-ink-soft"
                }`}
              >
                {i.text}
              </div>
            ))}
            {insights.length === 0 && <p className="text-sm text-ink-soft">Insights will appear as more lessons are logged.</p>}
          </div>
        </Card>

        <Card className="p-5" hoverLift={false}>
          <h3 className="mb-3 font-display text-base font-semibold text-ink">Recommended revision topics</h3>
          {topics.length ? (
            <div className="flex flex-wrap gap-2">
              {topics.map((t) => (
                <Badge key={t} tone="dusty">
                  {t}
                </Badge>
              ))}
            </div>
          ) : (
            <p className="text-sm text-ink-soft">No specific revision topics flagged right now — great consistency!</p>
          )}
        </Card>
      </div>

      <div className="space-y-4">
        <Card className="p-5" hoverLift={false}>
          <div className="mb-3 flex items-center gap-2">
            <TrendingUp size={15} className="text-sage-deep" />
            <p className="text-sm font-semibold text-ink">Strongest skills</p>
          </div>
          <div className="space-y-1.5">
            {strong.map((k) => (
              <div key={k} className="flex items-center justify-between text-sm">
                <span className="text-ink-soft">{skillLabel(k)}</span>
                <span className="font-medium text-sage-deep">{student.scores[k as keyof typeof student.scores]}%</span>
              </div>
            ))}
          </div>
        </Card>

        <Card className="p-5" hoverLift={false}>
          <div className="mb-3 flex items-center gap-2">
            <TrendingDown size={15} className="text-coral" />
            <p className="text-sm font-semibold text-ink">Weakest skills</p>
          </div>
          <div className="space-y-1.5">
            {weak.map((k) => (
              <div key={k} className="flex items-center justify-between text-sm">
                <span className="text-ink-soft">{skillLabel(k)}</span>
                <span className="font-medium text-coral">{student.scores[k as keyof typeof student.scores]}%</span>
              </div>
            ))}
          </div>
        </Card>

        <Card className="p-5" hoverLift={false}>
          <div className="mb-3 flex items-center gap-2">
            <Target size={15} className="text-dusty-deep" />
            <p className="text-sm font-semibold text-ink">Estimates</p>
          </div>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-ink-soft">Estimated CEFR level</span>
              <span className="font-medium text-ink">{cefr.level}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-ink-soft">Est. time to next level</span>
              <span className="font-medium text-ink">~{months} mo</span>
            </div>
            <div className="flex justify-between">
              <span className="text-ink-soft">Course completion</span>
              <span className="font-medium text-ink">{student.scores.overall}%</span>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}

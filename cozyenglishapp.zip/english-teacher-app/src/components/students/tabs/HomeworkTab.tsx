"use client";

import { useState } from "react";
import { Plus } from "lucide-react";
import { Student, HomeworkStatus } from "@/lib/types";
import { Card } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { ProgressBar } from "@/components/ui/ProgressBar";
import { Input, Label, Select, Textarea } from "@/components/ui/Input";
import { Modal } from "@/components/ui/Modal";
import { EmptyState } from "@/components/ui/EmptyState";
import { useStore } from "@/lib/store";
import { formatDate } from "@/lib/utils";

const statusTone: Record<HomeworkStatus, "sage" | "coral" | "dusty" | "beige"> = {
  submitted: "sage",
  late: "dusty",
  missing: "coral",
  pending: "beige",
};

export function HomeworkTab({ student }: { student: Student }) {
  const addHomework = useStore((s) => s.addHomework);
  const updateHomework = useStore((s) => s.updateHomework);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ assignment: "", dueDate: new Date().toISOString().slice(0, 10) });

  const items = [...student.homework].sort((a, b) => b.dueDate.localeCompare(a.dueDate));

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    addHomework(student.id, {
      assignment: form.assignment,
      dueDate: new Date(form.dueDate).toISOString(),
      submittedDate: null,
      status: "pending",
      score: null,
      teacherCorrection: "",
      comments: "",
    });
    setForm({ assignment: "", dueDate: new Date().toISOString().slice(0, 10) });
    setOpen(false);
  }

  return (
    <div>
      <Card className="mb-4 p-4" hoverLift={false}>
        <ProgressBar value={student.scores.homework} label="Automatic homework completion" tone="sage" />
      </Card>

      <div className="mb-4 flex items-center justify-between">
        <p className="text-sm text-ink-soft">{items.length} assignment{items.length !== 1 ? "s" : ""}</p>
        <Button size="sm" onClick={() => setOpen(true)} className="gap-1.5">
          <Plus size={14} /> Assign homework
        </Button>
      </div>

      {items.length === 0 ? (
        <EmptyState icon="📝" title="No homework yet" description="Assignments are added automatically from lessons, or you can add one manually." />
      ) : (
        <div className="space-y-3">
          {items.map((h) => (
            <Card key={h.id} className="p-4" hoverLift={false}>
              <div className="flex flex-wrap items-start justify-between gap-2">
                <div>
                  <p className="font-medium text-ink">{h.assignment}</p>
                  <p className="text-xs text-ink-soft">Due {formatDate(h.dueDate)}{h.submittedDate ? ` · Submitted ${formatDate(h.submittedDate)}` : ""}</p>
                </div>
                <div className="flex items-center gap-2">
                  {h.score !== null && <Badge tone="beige">Score {h.score}%</Badge>}
                  <Select
                    value={h.status}
                    onChange={(e) =>
                      updateHomework(student.id, h.id, {
                        status: e.target.value as HomeworkStatus,
                        submittedDate: e.target.value === "submitted" || e.target.value === "late" ? new Date().toISOString() : h.submittedDate,
                      })
                    }
                    className="h-8 w-32 py-1 text-xs"
                  >
                    <option value="pending">Pending</option>
                    <option value="submitted">Submitted</option>
                    <option value="late">Late</option>
                    <option value="missing">Missing</option>
                  </Select>
                  <Badge tone={statusTone[h.status]}>{h.status}</Badge>
                </div>
              </div>
              {(h.teacherCorrection || h.comments) && (
                <div className="mt-2 grid grid-cols-1 gap-2 border-t border-border pt-2 text-xs text-ink-soft sm:grid-cols-2">
                  {h.teacherCorrection && <p><span className="font-semibold text-ink-faint">Correction: </span>{h.teacherCorrection}</p>}
                  {h.comments && <p><span className="font-semibold text-ink-faint">Comments: </span>{h.comments}</p>}
                </div>
              )}
              <HomeworkInlineEdit studentId={student.id} homeworkId={h.id} score={h.score} comments={h.comments} />
            </Card>
          ))}
        </div>
      )}

      <Modal open={open} onClose={() => setOpen(false)} title="Assign homework">
        <form onSubmit={handleSubmit} className="space-y-3">
          <div>
            <Label>Assignment</Label>
            <Input value={form.assignment} onChange={(e) => setForm({ ...form, assignment: e.target.value })} required />
          </div>
          <div>
            <Label>Due date</Label>
            <Input type="date" value={form.dueDate} onChange={(e) => setForm({ ...form, dueDate: e.target.value })} />
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <Button type="button" variant="ghost" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button type="submit">Assign</Button>
          </div>
        </form>
      </Modal>
    </div>
  );
}

function HomeworkInlineEdit({
  studentId,
  homeworkId,
  score,
  comments,
}: {
  studentId: string;
  homeworkId: string;
  score: number | null;
  comments: string;
}) {
  const updateHomework = useStore((s) => s.updateHomework);
  const [localScore, setLocalScore] = useState(score ?? 0);
  const [localComment, setLocalComment] = useState(comments);

  return (
    <div className="mt-3 grid grid-cols-1 gap-2 border-t border-border pt-3 sm:grid-cols-[100px_1fr_auto]">
      <Input
        type="number"
        min={0}
        max={100}
        value={localScore}
        onChange={(e) => setLocalScore(Number(e.target.value))}
        placeholder="Score"
        className="h-8 py-1 text-xs"
      />
      <Textarea
        value={localComment}
        onChange={(e) => setLocalComment(e.target.value)}
        placeholder="Correction / comments"
        rows={1}
        className="min-h-0 py-1.5 text-xs"
      />
      <Button
        size="sm"
        variant="outline"
        onClick={() => updateHomework(studentId, homeworkId, { score: localScore, comments: localComment, teacherCorrection: localComment })}
      >
        Save
      </Button>
    </div>
  );
}

"use client";

import { useState } from "react";
import { Student } from "@/lib/types";
import { Card } from "@/components/ui/Card";
import { ProgressBar, CircularProgress } from "@/components/ui/ProgressBar";
import { Badge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { SKILL_META } from "@/lib/skill-meta";
import { formatDate } from "@/lib/utils";
import { EditStudentModal } from "../EditStudentModal";
import { Pencil } from "lucide-react";

export function OverviewTab({ student }: { student: Student }) {
  const [editOpen, setEditOpen] = useState(false);

  return (
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
      <div className="space-y-6 lg:col-span-2">
        <Card className="p-5">
          <div className="mb-4 flex items-center justify-between">
            <h3 className="font-display text-lg font-semibold text-ink">Personal information</h3>
            <Button variant="ghost" size="sm" onClick={() => setEditOpen(true)} className="gap-1">
              <Pencil size={13} /> Edit
            </Button>
          </div>
          <dl className="grid grid-cols-2 gap-x-4 gap-y-4 sm:grid-cols-3">
            <Field label="Age" value={`${student.age}`} />
            <Field label="English level" value={student.level} />
            <Field label="Occupation" value={student.occupation || "—"} />
            <Field label="Start date" value={formatDate(student.startDate)} />
            <Field label="Birthday" value={formatDate(student.birthday, { month: "long", day: "numeric" })} />
            <Field label="Status" value={student.status} />
          </dl>
          <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div>
              <p className="mb-1.5 text-xs font-semibold text-ink-soft">Goals</p>
              <div className="flex flex-wrap gap-1.5">
                {student.goals.length ? student.goals.map((g) => <Badge key={g} tone="sage">🎯 {g}</Badge>) : <span className="text-sm text-ink-faint">No goals set</span>}
              </div>
            </div>
            <div>
              <p className="mb-1.5 text-xs font-semibold text-ink-soft">Interests</p>
              <div className="flex flex-wrap gap-1.5">
                {student.interests.length ? student.interests.map((g) => <Badge key={g} tone="dusty">{g}</Badge>) : <span className="text-sm text-ink-faint">No interests set</span>}
              </div>
            </div>
          </div>
        </Card>

        <Card className="p-5">
          <h3 className="mb-4 font-display text-lg font-semibold text-ink">Current course</h3>
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
            <Field label="Course" value={student.course.name} />
            <Field label="Unit" value={student.course.unit} />
            <Field label="Lesson" value={student.course.lesson} />
            <Field label="Teacher" value={student.course.teacher} />
          </div>
        </Card>

        <Card className="p-5">
          <h3 className="mb-4 font-display text-lg font-semibold text-ink">Self-reported confidence</h3>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <ProgressBar value={student.confidence.speaking} label="Speaking confidence" tone="coral" />
            <ProgressBar value={student.confidence.grammar} label="Grammar confidence" tone="sage" />
            <ProgressBar value={student.confidence.vocabulary} label="Vocabulary confidence" tone="dusty" />
            <ProgressBar value={student.confidence.pronunciation} label="Pronunciation confidence" tone="coral" />
          </div>
        </Card>
      </div>

      <div className="space-y-6">
        <Card className="flex flex-col items-center p-6">
          <p className="mb-3 text-sm font-semibold text-ink-soft">Overall Progress</p>
          <CircularProgress value={student.scores.overall} size={140} tone="sage" />
          <p className="mt-3 text-center text-xs text-ink-faint">Calculated automatically from attendance, homework, assessments &amp; tests</p>
        </Card>

        <Card className="p-5">
          <h3 className="mb-4 font-display text-base font-semibold text-ink">Skill breakdown</h3>
          <div className="space-y-3.5">
            {SKILL_META.map((m) => (
              <ProgressBar key={m.key} value={student.scores[m.key]} label={`${m.icon} ${m.label}`} tone={m.tone} size="sm" />
            ))}
          </div>
        </Card>
      </div>

      <EditStudentModal open={editOpen} onClose={() => setEditOpen(false)} student={student} />
    </div>
  );
}

function Field({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <dt className="text-xs text-ink-faint">{label}</dt>
      <dd className="text-sm font-medium capitalize text-ink">{value}</dd>
    </div>
  );
}

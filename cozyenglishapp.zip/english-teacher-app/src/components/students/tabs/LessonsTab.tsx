"use client";

import { useState } from "react";
import { Plus, ChevronDown } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { Student } from "@/lib/types";
import { Card } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { StarRating } from "@/components/ui/StarRating";
import { EmptyState } from "@/components/ui/EmptyState";
import { LessonFormModal } from "../LessonFormModal";
import { formatDate, moodEmoji, cn } from "@/lib/utils";

const attendanceTone: Record<string, "sage" | "coral" | "dusty" | "beige"> = {
  present: "sage",
  late: "dusty",
  absent: "coral",
  cancelled: "beige",
  rescheduled: "beige",
};

export function LessonsTab({ student }: { student: Student }) {
  const [open, setOpen] = useState(false);
  const [expanded, setExpanded] = useState<string | null>(null);
  const lessons = [...student.lessons].sort((a, b) => b.date.localeCompare(a.date));

  return (
    <div>
      <div className="mb-4 flex items-center justify-between">
        <p className="text-sm text-ink-soft">{lessons.length} lesson{lessons.length !== 1 ? "s" : ""} logged</p>
        <Button onClick={() => setOpen(true)} className="gap-1.5">
          <Plus size={16} /> Log lesson
        </Button>
      </div>

      {lessons.length === 0 ? (
        <EmptyState icon="📔" title="No lessons yet" description="Log the first lesson to start building this student's history." action={<Button onClick={() => setOpen(true)}>Log lesson</Button>} />
      ) : (
        <div className="space-y-3">
          {lessons.map((l) => {
            const isOpen = expanded === l.id;
            return (
              <Card key={l.id} className="p-5" hoverLift={false}>
                <button className="flex w-full items-start justify-between gap-3 text-left" onClick={() => setExpanded(isOpen ? null : l.id)}>
                  <div className="flex items-start gap-3">
                    <span className="text-2xl">{moodEmoji(l.mood)}</span>
                    <div>
                      <p className="font-display text-base font-semibold text-ink">{l.topic}</p>
                      <p className="text-xs text-ink-soft">{formatDate(l.date)} · {l.durationMinutes} min</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge tone={attendanceTone[l.attendance]}>{l.attendance}</Badge>
                    <ChevronDown size={18} className={cn("text-ink-faint transition-transform", isOpen && "rotate-180")} />
                  </div>
                </button>

                <AnimatePresence>
                  {isOpen && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.3, ease: [0.16, 1, 0.3, 1] }}
                      className="overflow-hidden"
                    >
                      <div className="mt-4 grid grid-cols-1 gap-4 border-t border-border pt-4 sm:grid-cols-2">
                        <DetailBlock label="Grammar" value={l.grammar} />
                        <DetailBlock label="Vocabulary learned" value={l.vocabularyLearned.join(", ") || "—"} />
                        <DetailBlock label="Speaking topic" value={l.speakingTopic} />
                        <DetailBlock label="Listening topic" value={l.listeningTopic} />
                        <DetailBlock label="Reading topic" value={l.readingTopic} />
                        <DetailBlock label="Writing practice" value={l.writingPractice} />
                        <DetailBlock label="Homework" value={l.homework} />
                        <DetailBlock label="Homework completion" value={`${l.homeworkCompletion}%`} />
                        <DetailBlock label="Lesson notes" value={l.lessonNotes} full />
                        <DetailBlock label="Teacher observations" value={l.teacherObservations} full />
                        <DetailBlock label="Student questions" value={l.studentQuestions} full />
                        <DetailBlock label="Mistakes to revise" value={l.mistakesToRevise.join(", ") || "None noted"} full />
                      </div>
                      <div className="mt-4 grid grid-cols-2 gap-3 rounded-xl bg-canvas-soft/60 p-4 sm:grid-cols-3">
                        <MiniRating label="Participation" value={l.assessment.participation} />
                        <MiniRating label="Confidence" value={l.assessment.confidence} />
                        <MiniRating label="Grammar" value={l.assessment.grammar} />
                        <MiniRating label="Vocabulary" value={l.assessment.vocabulary} />
                        <MiniRating label="Listening" value={l.assessment.listening} />
                        <MiniRating label="Speaking" value={l.assessment.speaking} />
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </Card>
            );
          })}
        </div>
      )}

      <LessonFormModal open={open} onClose={() => setOpen(false)} studentId={student.id} />
    </div>
  );
}

function DetailBlock({ label, value, full }: { label: string; value: string; full?: boolean }) {
  return (
    <div className={full ? "sm:col-span-2" : ""}>
      <p className="text-xs font-semibold text-ink-faint">{label}</p>
      <p className="mt-0.5 text-sm text-ink-soft">{value || "—"}</p>
    </div>
  );
}

function MiniRating({ label, value }: { label: string; value: number }) {
  return (
    <div>
      <p className="mb-1 text-[11px] text-ink-soft">{label}</p>
      <StarRating value={value} readOnly size={13} />
    </div>
  );
}

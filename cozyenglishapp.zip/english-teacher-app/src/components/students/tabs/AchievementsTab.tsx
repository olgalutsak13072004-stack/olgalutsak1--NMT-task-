"use client";

import { Student } from "@/lib/types";
import { Card } from "@/components/ui/Card";
import { Button } from "@/components/ui/Button";
import { ACHIEVEMENT_CATALOG } from "@/lib/achievements";
import { useStore } from "@/lib/store";
import { formatDate, cn } from "@/lib/utils";

export function AchievementsTab({ student, readOnly }: { student: Student; readOnly?: boolean }) {
  const addAchievement = useStore((s) => s.addAchievement);
  const earnedKeys = new Set(student.achievements.map((a) => a.key));

  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
      {ACHIEVEMENT_CATALOG.map((a) => {
        const earnedEntry = student.achievements.find((e) => e.key === a.key);
        const isEarned = earnedKeys.has(a.key);
        return (
          <Card key={a.key} className={cn("flex flex-col items-center gap-2 p-5 text-center", !isEarned && "opacity-50")} hoverLift={false}>
            <span className="text-4xl">{a.emoji}</span>
            <p className="font-display text-sm font-semibold text-ink">{a.label}</p>
            <p className="text-xs text-ink-soft">{a.description}</p>
            {isEarned ? (
              <p className="mt-1 text-[11px] font-medium text-sage-deep">Earned {formatDate(earnedEntry!.dateEarned)}</p>
            ) : !readOnly ? (
              <Button
                size="sm"
                variant="outline"
                className="mt-1"
                onClick={() => addAchievement(student.id, { key: a.key, label: a.label, emoji: a.emoji, description: a.description, dateEarned: new Date().toISOString() })}
              >
                Award badge
              </Button>
            ) : (
              <p className="mt-1 text-[11px] text-ink-faint">Not earned yet</p>
            )}
          </Card>
        );
      })}
    </div>
  );
}

"use client";

import { useMemo, useState } from "react";
import { Plus, CheckCircle2, RotateCcw } from "lucide-react";
import { Student } from "@/lib/types";
import { Card } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { Input, Label } from "@/components/ui/Input";
import { Modal } from "@/components/ui/Modal";
import { EmptyState } from "@/components/ui/EmptyState";
import { useStore } from "@/lib/store";
import { formatDateShort, cn } from "@/lib/utils";

export function VocabularyTab({ student, readOnly }: { student: Student; readOnly?: boolean }) {
  const addVocabulary = useStore((s) => s.addVocabulary);
  const updateVocabulary = useStore((s) => s.updateVocabulary);
  const [filter, setFilter] = useState<"all" | "mastered" | "revision">("all");
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ word: "", translation: "", exampleSentence: "", pronunciation: "" });

  const items = useMemo(() => {
    let list = [...student.vocabulary].sort((a, b) => b.dateLearned.localeCompare(a.dateLearned));
    if (filter === "mastered") list = list.filter((v) => v.mastered);
    if (filter === "revision") list = list.filter((v) => v.needsRevision);
    return list;
  }, [student.vocabulary, filter]);

  const masteredCount = student.vocabulary.filter((v) => v.mastered).length;

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    addVocabulary(student.id, {
      word: form.word,
      translation: form.translation,
      dateLearned: new Date().toISOString(),
      revisionDates: [],
      mastered: false,
      needsRevision: true,
      quizScore: null,
      exampleSentence: form.exampleSentence,
      pronunciation: form.pronunciation,
    });
    setForm({ word: "", translation: "", exampleSentence: "", pronunciation: "" });
    setOpen(false);
  }

  return (
    <div>
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <p className="text-sm text-ink-soft">
            {student.vocabulary.length} words · {masteredCount} mastered
          </p>
        </div>
        <div className="flex items-center gap-2">
          <div className="inline-flex rounded-full border border-border bg-canvas-soft p-1">
            {(["all", "mastered", "revision"] as const).map((f) => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={cn(
                  "rounded-full px-3 py-1.5 text-xs font-medium capitalize transition-colors",
                  filter === f ? "bg-surface text-ink shadow-[var(--shadow-cozy)]" : "text-ink-soft"
                )}
              >
                {f === "revision" ? "Needs revision" : f}
              </button>
            ))}
          </div>
          {!readOnly && (
            <Button size="sm" onClick={() => setOpen(true)} className="gap-1.5">
              <Plus size={14} /> Add word
            </Button>
          )}
        </div>
      </div>

      {items.length === 0 ? (
        <EmptyState icon="📚" title="No vocabulary yet" description="New words are usually added automatically after each lesson." />
      ) : (
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-3">
          {items.map((v) => (
            <Card key={v.id} className="p-4" hoverLift={false}>
              <div className="mb-1.5 flex items-start justify-between">
                <div>
                  <p className="font-display text-base font-semibold text-ink">{v.word}</p>
                  <p className="text-xs text-ink-faint">{v.pronunciation}</p>
                </div>
                {v.mastered ? <Badge tone="sage">Mastered</Badge> : <Badge tone="coral">Revise</Badge>}
              </div>
              <p className="text-sm text-ink-soft">{v.translation}</p>
              <p className="mt-2 text-xs italic text-ink-faint">&ldquo;{v.exampleSentence}&rdquo;</p>
              <div className="mt-3 flex items-center justify-between text-xs text-ink-faint">
                <span>Learned {formatDateShort(v.dateLearned)}</span>
                {v.quizScore !== null && <span>Quiz: {v.quizScore}%</span>}
              </div>
              {!readOnly && (
                <div className="mt-3 flex gap-2">
                  <button
                    onClick={() => updateVocabulary(student.id, v.id, { mastered: !v.mastered, needsRevision: v.mastered })}
                    className="flex items-center gap-1 rounded-full bg-canvas-soft px-2.5 py-1 text-xs font-medium text-ink-soft hover:bg-sage-soft hover:text-sage-deep"
                  >
                    <CheckCircle2 size={12} /> {v.mastered ? "Unmark" : "Mark mastered"}
                  </button>
                  <button
                    onClick={() => updateVocabulary(student.id, v.id, { revisionDates: [...v.revisionDates, new Date().toISOString()] })}
                    className="flex items-center gap-1 rounded-full bg-canvas-soft px-2.5 py-1 text-xs font-medium text-ink-soft hover:bg-dusty-soft hover:text-dusty-deep"
                  >
                    <RotateCcw size={12} /> Log revision
                  </button>
                </div>
              )}
            </Card>
          ))}
        </div>
      )}

      <Modal open={open} onClose={() => setOpen(false)} title="Add vocabulary word">
        <form onSubmit={handleSubmit} className="space-y-3">
          <div>
            <Label>Word</Label>
            <Input value={form.word} onChange={(e) => setForm({ ...form, word: e.target.value })} required />
          </div>
          <div>
            <Label>Translation</Label>
            <Input value={form.translation} onChange={(e) => setForm({ ...form, translation: e.target.value })} required />
          </div>
          <div>
            <Label>Example sentence</Label>
            <Input value={form.exampleSentence} onChange={(e) => setForm({ ...form, exampleSentence: e.target.value })} />
          </div>
          <div>
            <Label>Pronunciation</Label>
            <Input value={form.pronunciation} onChange={(e) => setForm({ ...form, pronunciation: e.target.value })} placeholder="/wɜːd/" />
          </div>
          <div className="flex justify-end gap-2 pt-2">
            <Button type="button" variant="ghost" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button type="submit">Add word</Button>
          </div>
        </form>
      </Modal>
    </div>
  );
}

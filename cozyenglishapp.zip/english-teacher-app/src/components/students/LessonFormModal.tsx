"use client";

import { useState } from "react";
import { Modal } from "@/components/ui/Modal";
import { Input, Label, Select, Textarea } from "@/components/ui/Input";
import { Button } from "@/components/ui/Button";
import { StarRating } from "@/components/ui/StarRating";
import { useStore } from "@/lib/store";
import { AttendanceStatus, HomeworkStatus, LessonRecord, Mood } from "@/lib/types";

export function LessonFormModal({
  open,
  onClose,
  studentId,
  prefill,
}: {
  open: boolean;
  onClose: () => void;
  studentId: string;
  prefill?: Partial<LessonRecord>;
}) {
  const addLesson = useStore((s) => s.addLesson);
  const [form, setForm] = useState({
    date: new Date().toISOString().slice(0, 10),
    topic: prefill?.topic ?? "",
    homework: prefill?.homework ?? "",
    vocabularyLearned: prefill?.vocabularyLearned?.join(", ") ?? "",
    grammar: prefill?.grammar ?? "",
    speakingTopic: prefill?.speakingTopic ?? "",
    listeningTopic: prefill?.listeningTopic ?? "",
    readingTopic: prefill?.readingTopic ?? "",
    writingPractice: prefill?.writingPractice ?? "",
    lessonNotes: "",
    teacherObservations: "",
    studentQuestions: "",
    mistakesToRevise: "",
    homeworkCompletion: 0,
    attendance: "present" as AttendanceStatus,
    durationMinutes: 60,
    mood: "happy" as Mood,
    participation: 4,
    confidence: 4,
    starGrammar: 4,
    starVocabulary: 4,
    listening: 4,
    speaking: 4,
    homeworkStatus: "pending" as HomeworkStatus,
  });

  function set<K extends keyof typeof form>(key: K, value: (typeof form)[K]) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    addLesson(studentId, {
      date: new Date(form.date).toISOString(),
      topic: form.topic,
      homework: form.homework,
      vocabularyLearned: form.vocabularyLearned.split(",").map((v) => v.trim()).filter(Boolean),
      grammar: form.grammar,
      speakingTopic: form.speakingTopic,
      listeningTopic: form.listeningTopic,
      readingTopic: form.readingTopic,
      writingPractice: form.writingPractice,
      lessonNotes: form.lessonNotes,
      teacherObservations: form.teacherObservations,
      studentQuestions: form.studentQuestions,
      mistakesToRevise: form.mistakesToRevise.split(",").map((v) => v.trim()).filter(Boolean),
      homeworkCompletion: form.homeworkCompletion,
      attendance: form.attendance,
      durationMinutes: form.durationMinutes,
      mood: form.mood,
      assessment: {
        participation: form.participation,
        confidence: form.confidence,
        grammar: form.starGrammar,
        vocabulary: form.starVocabulary,
        listening: form.listening,
        speaking: form.speaking,
        homework: form.homeworkStatus,
      },
    });
    onClose();
  }

  return (
    <Modal open={open} onClose={onClose} title="Log a lesson" wide>
      <form onSubmit={handleSubmit} className="space-y-5">
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          <div>
            <Label>Date</Label>
            <Input type="date" value={form.date} onChange={(e) => set("date", e.target.value)} />
          </div>
          <div>
            <Label>Duration (min)</Label>
            <Input type="number" value={form.durationMinutes} onChange={(e) => set("durationMinutes", Number(e.target.value))} />
          </div>
          <div>
            <Label>Attendance</Label>
            <Select value={form.attendance} onChange={(e) => set("attendance", e.target.value as AttendanceStatus)}>
              {["present", "late", "absent", "cancelled", "rescheduled"].map((v) => (
                <option key={v} value={v}>
                  {v}
                </option>
              ))}
            </Select>
          </div>
          <div>
            <Label>Mood after lesson</Label>
            <Select value={form.mood} onChange={(e) => set("mood", e.target.value as Mood)}>
              <option value="happy">😊 Happy</option>
              <option value="neutral">😐 Neutral</option>
              <option value="sad">😔 Struggled</option>
            </Select>
          </div>
        </div>

        <div>
          <Label>Lesson topic</Label>
          <Input value={form.topic} onChange={(e) => set("topic", e.target.value)} required />
        </div>

        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <div>
            <Label>Grammar</Label>
            <Input value={form.grammar} onChange={(e) => set("grammar", e.target.value)} />
          </div>
          <div>
            <Label>Vocabulary learned (comma separated)</Label>
            <Input value={form.vocabularyLearned} onChange={(e) => set("vocabularyLearned", e.target.value)} />
          </div>
          <div>
            <Label>Speaking topic</Label>
            <Input value={form.speakingTopic} onChange={(e) => set("speakingTopic", e.target.value)} />
          </div>
          <div>
            <Label>Listening topic</Label>
            <Input value={form.listeningTopic} onChange={(e) => set("listeningTopic", e.target.value)} />
          </div>
          <div>
            <Label>Reading topic</Label>
            <Input value={form.readingTopic} onChange={(e) => set("readingTopic", e.target.value)} />
          </div>
          <div>
            <Label>Writing practice</Label>
            <Input value={form.writingPractice} onChange={(e) => set("writingPractice", e.target.value)} />
          </div>
        </div>

        <div>
          <Label>Homework assigned</Label>
          <Input value={form.homework} onChange={(e) => set("homework", e.target.value)} />
        </div>

        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <div>
            <Label>Lesson notes</Label>
            <Textarea value={form.lessonNotes} onChange={(e) => set("lessonNotes", e.target.value)} />
          </div>
          <div>
            <Label>Teacher observations</Label>
            <Textarea value={form.teacherObservations} onChange={(e) => set("teacherObservations", e.target.value)} />
          </div>
          <div>
            <Label>Student questions</Label>
            <Textarea value={form.studentQuestions} onChange={(e) => set("studentQuestions", e.target.value)} />
          </div>
          <div>
            <Label>Mistakes to revise later (comma separated)</Label>
            <Textarea value={form.mistakesToRevise} onChange={(e) => set("mistakesToRevise", e.target.value)} />
          </div>
        </div>

        <div>
          <Label>Homework completion (%)</Label>
          <Input type="number" min={0} max={100} value={form.homeworkCompletion} onChange={(e) => set("homeworkCompletion", Number(e.target.value))} />
        </div>

        <div className="rounded-xl border border-border bg-canvas-soft/50 p-4">
          <p className="mb-3 text-sm font-semibold text-ink">Automatic assessment</p>
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3">
            <RatingField label="Participation" value={form.participation} onChange={(v) => set("participation", v)} />
            <RatingField label="Confidence" value={form.confidence} onChange={(v) => set("confidence", v)} />
            <RatingField label="Grammar" value={form.starGrammar} onChange={(v) => set("starGrammar", v)} />
            <RatingField label="Vocabulary" value={form.starVocabulary} onChange={(v) => set("starVocabulary", v)} />
            <RatingField label="Listening" value={form.listening} onChange={(v) => set("listening", v)} />
            <RatingField label="Speaking" value={form.speaking} onChange={(v) => set("speaking", v)} />
          </div>
          <div className="mt-3">
            <Label>Homework status</Label>
            <Select value={form.homeworkStatus} onChange={(e) => set("homeworkStatus", e.target.value as HomeworkStatus)} className="max-w-xs">
              <option value="submitted">Completed</option>
              <option value="late">Late</option>
              <option value="missing">Missing</option>
              <option value="pending">Pending</option>
            </Select>
          </div>
        </div>

        <div className="flex justify-end gap-2 pt-2">
          <Button type="button" variant="ghost" onClick={onClose}>
            Cancel
          </Button>
          <Button type="submit">Save lesson</Button>
        </div>
      </form>
    </Modal>
  );
}

function RatingField({ label, value, onChange }: { label: string; value: number; onChange: (v: number) => void }) {
  return (
    <div>
      <p className="mb-1 text-xs text-ink-soft">{label}</p>
      <StarRating value={value} onChange={onChange} />
    </div>
  );
}

"use client";

import { Student, HomeworkStatus } from "@/lib/types";
import { Card } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { ProgressBar } from "@/components/ui/ProgressBar";
import { EmptyState } from "@/components/ui/EmptyState";
import { formatDate } from "@/lib/utils";

const statusTone: Record<HomeworkStatus, "sage" | "coral" | "dusty" | "beige"> = {
  submitted: "sage",
  late: "dusty",
  missing: "coral",
  pending: "beige",
};

export function StudentHomeworkList({ student }: { student: Student }) {
  const items = [...student.homework].sort((a, b) => b.dueDate.localeCompare(a.dueDate));

  return (
    <div>
      <Card className="mb-4 p-4" hoverLift={false}>
        <ProgressBar value={student.scores.homework} label="Your homework completion" tone="sage" />
      </Card>

      {items.length === 0 ? (
        <EmptyState icon="📝" title="No homework yet" />
      ) : (
        <div className="space-y-3">
          {items.map((h) => (
            <Card key={h.id} className="p-4" hoverLift={false}>
              <div className="flex flex-wrap items-start justify-between gap-2">
                <div>
                  <p className="font-medium text-ink">{h.assignment}</p>
                  <p className="text-xs text-ink-soft">
                    Due {formatDate(h.dueDate)}
                    {h.submittedDate ? ` · Submitted ${formatDate(h.submittedDate)}` : ""}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  {h.score !== null && <Badge tone="beige">Score {h.score}%</Badge>}
                  <Badge tone={statusTone[h.status]}>{h.status}</Badge>
                </div>
              </div>
              {(h.teacherCorrection || h.comments) && (
                <div className="mt-2 border-t border-border pt-2 text-xs text-ink-soft">
                  {h.teacherCorrection && (
                    <p>
                      <span className="font-semibold text-ink-faint">Teacher correction: </span>
                      {h.teacherCorrection}
                    </p>
                  )}
                  {h.comments && (
                    <p className="mt-1">
                      <span className="font-semibold text-ink-faint">Comments: </span>
                      {h.comments}
                    </p>
                  )}
                </div>
              )}
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

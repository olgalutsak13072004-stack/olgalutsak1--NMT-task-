"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import { Sparkles, GraduationCap, User } from "lucide-react";
import { useAllUsers, useAuthStore } from "@/lib/auth";
import { Avatar } from "@/components/ui/Avatar";
import { Button } from "@/components/ui/Button";
import { cn } from "@/lib/utils";

export default function LoginPage() {
  const router = useRouter();
  const users = useAllUsers();
  const login = useAuthStore((s) => s.login);
  const [role, setRole] = useState<"teacher" | "student">("teacher");
  const [selectedStudentUser, setSelectedStudentUser] = useState<string>(users.find((u) => u.role === "student")?.id ?? "");

  const teacher = users.find((u) => u.role === "teacher")!;
  const studentUsers = users.filter((u) => u.role === "student");

  function handleContinue() {
    if (role === "teacher") {
      login(teacher.id);
      router.push("/teacher");
    } else if (selectedStudentUser) {
      login(selectedStudentUser);
      router.push("/student");
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-canvas px-4 py-10">
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="absolute -left-24 -top-24 h-72 w-72 rounded-full bg-sage-soft blur-3xl opacity-60" />
        <div className="absolute -bottom-24 -right-24 h-72 w-72 rounded-full bg-dusty-soft blur-3xl opacity-60" />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
        className="relative w-full max-w-md rounded-3xl border border-border bg-surface p-8 shadow-[var(--shadow-cozy-lg)]"
      >
        <div className="mb-6 flex flex-col items-center text-center">
          <div className="mb-3 flex h-12 w-12 items-center justify-center rounded-2xl bg-sage text-white">
            <Sparkles size={22} />
          </div>
          <h1 className="font-display text-2xl font-semibold text-ink">Cozy English</h1>
          <p className="mt-1 text-sm text-ink-soft">A warm space to teach, learn and grow.</p>
        </div>

        <div className="mb-5 grid grid-cols-2 gap-2 rounded-2xl bg-canvas-soft p-1.5">
          <button
            onClick={() => setRole("teacher")}
            className={cn(
              "flex items-center justify-center gap-1.5 rounded-xl py-2.5 text-sm font-medium transition-colors",
              role === "teacher" ? "bg-surface text-ink shadow-[var(--shadow-cozy)]" : "text-ink-soft"
            )}
          >
            <GraduationCap size={16} /> Teacher
          </button>
          <button
            onClick={() => setRole("student")}
            className={cn(
              "flex items-center justify-center gap-1.5 rounded-xl py-2.5 text-sm font-medium transition-colors",
              role === "student" ? "bg-surface text-ink shadow-[var(--shadow-cozy)]" : "text-ink-soft"
            )}
          >
            <User size={16} /> Student
          </button>
        </div>

        {role === "teacher" ? (
          <div className="mb-5 flex items-center gap-3 rounded-2xl border border-border bg-canvas-soft/60 p-3">
            <Avatar name={teacher.name} tone="sage" size={40} />
            <div>
              <p className="text-sm font-medium text-ink">{teacher.name}</p>
              <p className="text-xs text-ink-soft">{teacher.email}</p>
            </div>
          </div>
        ) : (
          <div className="mb-5 max-h-56 space-y-1.5 overflow-y-auto rounded-2xl border border-border bg-canvas-soft/60 p-2">
            {studentUsers.map((u) => (
              <button
                key={u.id}
                onClick={() => setSelectedStudentUser(u.id)}
                className={cn(
                  "flex w-full items-center gap-3 rounded-xl p-2 text-left transition-colors",
                  selectedStudentUser === u.id ? "bg-surface shadow-[var(--shadow-cozy)]" : "hover:bg-surface/70"
                )}
              >
                <Avatar name={u.name} tone="dusty" size={36} />
                <div>
                  <p className="text-sm font-medium text-ink">{u.name}</p>
                  <p className="text-xs text-ink-soft">{u.email}</p>
                </div>
              </button>
            ))}
          </div>
        )}

        <Button onClick={handleContinue} size="lg" className="w-full">
          Continue to {role === "teacher" ? "Teacher" : "Student"} Dashboard
        </Button>

        <p className="mt-4 text-center text-xs text-ink-faint">
          Demo mode — pick any profile above, no password needed.
        </p>
      </motion.div>
    </div>
  );
}

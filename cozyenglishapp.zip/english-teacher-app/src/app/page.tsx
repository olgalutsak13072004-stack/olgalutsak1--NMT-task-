"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { useCurrentUser } from "@/lib/auth";

export default function Home() {
  const router = useRouter();
  const user = useCurrentUser();

  useEffect(() => {
    if (user?.role === "teacher") router.replace("/teacher");
    else if (user?.role === "student") router.replace("/student");
    else router.replace("/login");
  }, [user, router]);

  return null;
}

"use client";

import { useMemo, useState } from "react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from "recharts";
import { useStore } from "@/lib/store";
import { Card } from "@/components/ui/Card";
import { StatTile } from "@/components/ui/StatTile";
import { Select } from "@/components/ui/Input";
import { StudentStatistics } from "@/components/statistics/StudentStatistics";
import { Users, TrendingUp, ClipboardCheck, CalendarCheck } from "lucide-react";
import { average } from "@/lib/utils";

const PIE_COLORS = ["var(--color-sage)", "var(--color-dusty)", "var(--color-coral)", "var(--color-beige-deep)", "#a78bfa", "#f4a261"];

export default function StatisticsPage() {
  const allStudents = useStore((s) => s.students);
  const students = useMemo(() => allStudents.filter((st) => st.status === "active"), [allStudents]);
  const [selected, setSelected] = useState("all");
  const student = students.find((s) => s.id === selected);

  const progressByStudent = useMemo(
    () => students.map((s) => ({ name: s.name.split(" ")[0], progress: s.scores.overall })),
    [students]
  );

  const levelDistribution = useMemo(() => {
    const counts = new Map<string, number>();
    students.forEach((s) => counts.set(s.level, (counts.get(s.level) ?? 0) + 1));
    return Array.from(counts.entries()).map(([level, count]) => ({ level, count }));
  }, [students]);

  return (
    <div className="mx-auto max-w-6xl">
      <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="font-display text-2xl font-semibold text-ink">Statistics</h1>
          <p className="mt-1 text-sm text-ink-soft">Elegant, automatic analytics across your studio.</p>
        </div>
        <Select value={selected} onChange={(e) => setSelected(e.target.value)} className="sm:w-56">
          <option value="all">All students (overview)</option>
          {students.map((s) => (
            <option key={s.id} value={s.id}>
              {s.name}
            </option>
          ))}
        </Select>
      </div>

      {student ? (
        <StudentStatistics student={student} />
      ) : (
        <div className="space-y-6">
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
            <StatTile icon={<Users size={18} />} label="Active students" value={students.length} tone="sage" />
            <StatTile icon={<TrendingUp size={18} />} label="Avg progress" value={`${average(students.map((s) => s.scores.overall))}%`} tone="dusty" />
            <StatTile icon={<ClipboardCheck size={18} />} label="Avg homework" value={`${average(students.map((s) => s.scores.homework))}%`} tone="coral" />
            <StatTile icon={<CalendarCheck size={18} />} label="Avg attendance" value={`${average(students.map((s) => s.scores.attendance))}%`} tone="beige" />
          </div>

          <Card className="p-5" hoverLift={false}>
            <h3 className="mb-4 font-display text-base font-semibold text-ink">Overall progress by student</h3>
            <div className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={progressByStudent}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                  <XAxis dataKey="name" tick={{ fill: "var(--color-ink-soft)", fontSize: 11 }} />
                  <YAxis domain={[0, 100]} tick={{ fill: "var(--color-ink-soft)", fontSize: 11 }} />
                  <Tooltip contentStyle={{ background: "var(--color-surface)", border: "1px solid var(--color-border)", borderRadius: 12, fontSize: 12 }} />
                  <Bar dataKey="progress" fill="var(--color-sage)" radius={[6, 6, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </Card>

          <Card className="p-5" hoverLift={false}>
            <h3 className="mb-4 font-display text-base font-semibold text-ink">Level distribution</h3>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={levelDistribution} dataKey="count" nameKey="level" innerRadius={50} outerRadius={85} paddingAngle={3}>
                    {levelDistribution.map((entry, i) => (
                      <Cell key={entry.level} fill={PIE_COLORS[i % PIE_COLORS.length]} />
                    ))}
                  </Pie>
                  <Legend />
                  <Tooltip contentStyle={{ background: "var(--color-surface)", border: "1px solid var(--color-border)", borderRadius: 12, fontSize: 12 }} />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </Card>
        </div>
      )}
    </div>
  );
}

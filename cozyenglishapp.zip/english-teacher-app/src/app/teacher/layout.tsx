"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { useCurrentUser } from "@/lib/auth";
import { AppShell } from "@/components/layout/AppShell";

export default function TeacherLayout({ children }: { children: React.ReactNode }) {
  const user = useCurrentUser();
  const router = useRouter();

  useEffect(() => {
    if (!user) {
      router.replace("/login");
    } else if (user.role !== "teacher") {
      router.replace("/student");
    }
  }, [user, router]);

  if (!user || user.role !== "teacher") return null;

  return <AppShell user={user}>{children}</AppShell>;
}

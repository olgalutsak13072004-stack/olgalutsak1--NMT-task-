"use client";

import { useMemo, useState } from "react";
import { Plus, Search, SlidersHorizontal } from "lucide-react";
import { useStore } from "@/lib/store";
import { StudentCard } from "@/components/students/StudentCard";
import { AddStudentModal } from "@/components/students/AddStudentModal";
import { Button } from "@/components/ui/Button";
import { Input, Select } from "@/components/ui/Input";
import { EmptyState } from "@/components/ui/EmptyState";
import { cn } from "@/lib/utils";

type SortKey = "name" | "progress" | "attendance" | "recent" | "level";

export default function StudentsPage() {
  const students = useStore((s) => s.students);
  const [query, setQuery] = useState("");
  const [status, setStatus] = useState<"active" | "archived">("active");
  const [levelFilter, setLevelFilter] = useState("all");
  const [progressFilter, setProgressFilter] = useState("all");
  const [attendanceFilter, setAttendanceFilter] = useState("all");
  const [goalFilter, setGoalFilter] = useState("all");
  const [sortKey, setSortKey] = useState<SortKey>("recent");
  const [addOpen, setAddOpen] = useState(false);
  const [filtersOpen, setFiltersOpen] = useState(false);

  const allGoals = useMemo(() => {
    const set = new Set<string>();
    students.forEach((s) => s.goals.forEach((g) => set.add(g)));
    return Array.from(set);
  }, [students]);

  const filtered = useMemo(() => {
    let list = students.filter((s) => s.status === status);

    if (query.trim()) {
      const q = query.toLowerCase();
      list = list.filter((s) => s.name.toLowerCase().includes(q) || s.occupation.toLowerCase().includes(q) || s.level.toLowerCase().includes(q));
    }
    if (levelFilter !== "all") list = list.filter((s) => s.level === levelFilter);
    if (progressFilter !== "all") {
      const [min, max] = progressFilter.split("-").map(Number);
      list = list.filter((s) => s.scores.overall >= min && s.scores.overall <= max);
    }
    if (attendanceFilter !== "all") {
      const [min, max] = attendanceFilter.split("-").map(Number);
      list = list.filter((s) => s.scores.attendance >= min && s.scores.attendance <= max);
    }
    if (goalFilter !== "all") list = list.filter((s) => s.goals.includes(goalFilter));

    const sorted = [...list].sort((a, b) => {
      switch (sortKey) {
        case "name":
          return a.name.localeCompare(b.name);
        case "progress":
          return b.scores.overall - a.scores.overall;
        case "attendance":
          return b.scores.attendance - a.scores.attendance;
        case "level":
          return a.level.localeCompare(b.level);
        case "recent": {
          const aLast = [...a.lessons].sort((x, y) => y.date.localeCompare(x.date))[0]?.date ?? "";
          const bLast = [...b.lessons].sort((x, y) => y.date.localeCompare(x.date))[0]?.date ?? "";
          return bLast.localeCompare(aLast);
        }
        default:
          return 0;
      }
    });
    return sorted;
  }, [students, status, query, levelFilter, progressFilter, attendanceFilter, goalFilter, sortKey]);

  return (
    <div className="mx-auto max-w-7xl">
      <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="font-display text-2xl font-semibold text-ink">Students</h1>
          <p className="mt-1 text-sm text-ink-soft">{filtered.length} {status} student{filtered.length !== 1 ? "s" : ""}</p>
        </div>
        <Button onClick={() => setAddOpen(true)} className="gap-1.5">
          <Plus size={16} /> Add student
        </Button>
      </div>

      <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center">
        <div className="relative flex-1">
          <Search size={16} className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-ink-faint" />
          <Input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search students…" className="pl-9" />
        </div>
        <Select value={sortKey} onChange={(e) => setSortKey(e.target.value as SortKey)} className="sm:w-48">
          <option value="recent">Sort: Recently active</option>
          <option value="name">Sort: Name (A–Z)</option>
          <option value="progress">Sort: Progress (high–low)</option>
          <option value="attendance">Sort: Attendance</option>
          <option value="level">Sort: Level</option>
        </Select>
        <Button variant="outline" onClick={() => setFiltersOpen((v) => !v)} className="gap-1.5">
          <SlidersHorizontal size={15} /> Filters
        </Button>
      </div>

      {filtersOpen && (
        <div className="mb-5 grid grid-cols-2 gap-3 rounded-2xl border border-border bg-canvas-soft/60 p-4 sm:grid-cols-4">
          <div>
            <p className="mb-1.5 text-xs font-semibold text-ink-soft">Level</p>
            <Select value={levelFilter} onChange={(e) => setLevelFilter(e.target.value)}>
              <option value="all">All levels</option>
              {["A1", "A2", "B1", "B2", "C1", "C2"].map((l) => (
                <option key={l} value={l}>
                  {l}
                </option>
              ))}
            </Select>
          </div>
          <div>
            <p className="mb-1.5 text-xs font-semibold text-ink-soft">Progress</p>
            <Select value={progressFilter} onChange={(e) => setProgressFilter(e.target.value)}>
              <option value="all">Any progress</option>
              <option value="0-50">Below 50%</option>
              <option value="50-75">50–75%</option>
              <option value="75-100">75–100%</option>
            </Select>
          </div>
          <div>
            <p className="mb-1.5 text-xs font-semibold text-ink-soft">Attendance</p>
            <Select value={attendanceFilter} onChange={(e) => setAttendanceFilter(e.target.value)}>
              <option value="all">Any attendance</option>
              <option value="90-100">90–100%</option>
              <option value="70-89">70–89%</option>
              <option value="0-69">Below 70%</option>
            </Select>
          </div>
          <div>
            <p className="mb-1.5 text-xs font-semibold text-ink-soft">Goal</p>
            <Select value={goalFilter} onChange={(e) => setGoalFilter(e.target.value)}>
              <option value="all">Any goal</option>
              {allGoals.map((g) => (
                <option key={g} value={g}>
                  {g}
                </option>
              ))}
            </Select>
          </div>
        </div>
      )}

      <div className="mb-5 inline-flex rounded-full border border-border bg-canvas-soft p-1">
        {(["active", "archived"] as const).map((s) => (
          <button
            key={s}
            onClick={() => setStatus(s)}
            className={cn(
              "rounded-full px-4 py-1.5 text-sm font-medium capitalize transition-colors",
              status === s ? "bg-surface text-ink shadow-[var(--shadow-cozy)]" : "text-ink-soft"
            )}
          >
            {s}
          </button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <EmptyState
          icon="🌱"
          title={status === "active" ? "No students match your filters" : "No archived students"}
          description="Try adjusting your search or filters, or add a new student to get started."
          action={
            status === "active" && (
              <Button onClick={() => setAddOpen(true)} className="gap-1.5">
                <Plus size={16} /> Add student
              </Button>
            )
          }
        />
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {filtered.map((s, i) => (
            <StudentCard key={s.id} student={s} index={i} />
          ))}
        </div>
      )}

      <AddStudentModal open={addOpen} onClose={() => setAddOpen(false)} />
    </div>
  );
}

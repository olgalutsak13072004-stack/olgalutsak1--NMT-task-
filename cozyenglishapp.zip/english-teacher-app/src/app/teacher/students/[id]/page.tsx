"use client";

import { use, Suspense } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { ArrowLeft, Copy, Archive, ArchiveRestore, Trash2 } from "lucide-react";
import { useStudent, useStore } from "@/lib/store";
import { Avatar } from "@/components/ui/Avatar";
import { Badge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { Tabs } from "@/components/ui/Tabs";
import { EmptyState } from "@/components/ui/EmptyState";
import { OverviewTab } from "@/components/students/tabs/OverviewTab";
import { LessonsTab } from "@/components/students/tabs/LessonsTab";
import { PlanningTab } from "@/components/students/tabs/PlanningTab";
import { VocabularyTab } from "@/components/students/tabs/VocabularyTab";
import { HomeworkTab } from "@/components/students/tabs/HomeworkTab";
import { AttendanceTab } from "@/components/students/tabs/AttendanceTab";
import { TestsTab } from "@/components/students/tabs/TestsTab";
import { GoalsTab } from "@/components/students/tabs/GoalsTab";
import { FeedbackTab } from "@/components/students/tabs/FeedbackTab";
import { NotesTab } from "@/components/students/tabs/NotesTab";
import { AchievementsTab } from "@/components/students/tabs/AchievementsTab";
import { TimelineTab } from "@/components/students/tabs/TimelineTab";
import { InsightsTab } from "@/components/students/tabs/InsightsTab";

function StudentProfileInner({ id }: { id: string }) {
  const student = useStudent(id);
  const router = useRouter();
  const searchParams = useSearchParams();
  const archiveStudent = useStore((s) => s.archiveStudent);
  const unarchiveStudent = useStore((s) => s.unarchiveStudent);
  const deleteStudent = useStore((s) => s.deleteStudent);
  const duplicateStudent = useStore((s) => s.duplicateStudent);

  if (!student) {
    return (
      <EmptyState
        icon="🔍"
        title="Student not found"
        description="This profile may have been deleted."
        action={
          <Link href="/teacher/students">
            <Button>Back to students</Button>
          </Link>
        }
      />
    );
  }

  const initialTab = searchParams.get("tab") ?? "overview";

  return (
    <div className="mx-auto max-w-6xl">
      <Link href="/teacher/students" className="mb-4 inline-flex items-center gap-1.5 text-sm font-medium text-ink-soft hover:text-ink">
        <ArrowLeft size={15} /> Back to students
      </Link>

      <div className="mb-6 flex flex-col gap-4 rounded-2xl border border-border bg-surface p-5 shadow-[var(--shadow-cozy)] sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-4">
          <Avatar name={student.name} emoji={student.avatarEmoji} tone={student.avatarColor as "sage" | "dusty" | "coral" | "beige"} size={60} />
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <h1 className="font-display text-xl font-semibold text-ink sm:text-2xl">{student.name}</h1>
              <Badge tone="sage">{student.level}</Badge>
              {student.status === "archived" && <Badge tone="neutral">Archived</Badge>}
            </div>
            <p className="text-sm text-ink-soft">{student.course.name} · {student.course.unit}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" className="gap-1.5" onClick={() => duplicateStudent(student.id)}>
            <Copy size={14} /> Duplicate
          </Button>
          {student.status === "active" ? (
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => archiveStudent(student.id)}>
              <Archive size={14} /> Archive
            </Button>
          ) : (
            <Button variant="outline" size="sm" className="gap-1.5" onClick={() => unarchiveStudent(student.id)}>
              <ArchiveRestore size={14} /> Unarchive
            </Button>
          )}
          <Button
            variant="danger"
            size="sm"
            className="gap-1.5"
            onClick={() => {
              if (confirm(`Delete ${student.name}? This cannot be undone.`)) {
                deleteStudent(student.id);
                router.push("/teacher/students");
              }
            }}
          >
            <Trash2 size={14} /> Delete
          </Button>
        </div>
      </div>

      <Tabs
        defaultTab={initialTab}
        tabs={[
          { id: "overview", label: "Overview", content: <OverviewTab student={student} /> },
          { id: "lessons", label: "Lessons", content: <LessonsTab student={student} /> },
          { id: "planning", label: "Planning", content: <PlanningTab student={student} /> },
          { id: "vocabulary", label: "Vocabulary", content: <VocabularyTab student={student} /> },
          { id: "homework", label: "Homework", content: <HomeworkTab student={student} /> },
          { id: "attendance", label: "Attendance", content: <AttendanceTab student={student} /> },
          { id: "tests", label: "Tests", content: <TestsTab student={student} /> },
          { id: "goals", label: "Goals", content: <GoalsTab student={student} /> },
          { id: "feedback", label: "Feedback", content: <FeedbackTab student={student} /> },
          { id: "notes", label: "Notes", content: <NotesTab student={student} /> },
          { id: "achievements", label: "Achievements", content: <AchievementsTab student={student} /> },
          { id: "timeline", label: "Timeline", content: <TimelineTab student={student} /> },
          { id: "insights", label: "AI Insights", content: <InsightsTab student={student} /> },
        ]}
      />
    </div>
  );
}

export default function StudentProfilePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  return (
    <Suspense fallback={null}>
      <StudentProfileInner id={id} />
    </Suspense>
  );
}

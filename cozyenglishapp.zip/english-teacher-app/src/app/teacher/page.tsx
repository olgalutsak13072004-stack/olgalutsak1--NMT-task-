"use client";

import Link from "next/link";
import { useMemo } from "react";
import { Users, TrendingUp, CalendarClock, ClipboardCheck, Sparkles, ArrowRight } from "lucide-react";
import { useStore } from "@/lib/store";
import { useCurrentUser } from "@/lib/auth";
import { StatTile } from "@/components/ui/StatTile";
import { Card } from "@/components/ui/Card";
import { Avatar } from "@/components/ui/Avatar";
import { Badge } from "@/components/ui/Badge";
import { generateInsights } from "@/lib/insights";
import { generateNotifications } from "@/lib/notifications";
import { average, formatDateShort, daysUntil, daysBetween } from "@/lib/utils";

const NOW = "2026-07-27T09:00:00Z";

export default function TeacherDashboard() {
  const students = useStore((s) => s.students);
  const user = useCurrentUser();
  const active = useMemo(() => students.filter((s) => s.status === "active"), [students]);

  const avgProgress = useMemo(() => average(active.map((s) => s.scores.overall)), [active]);

  const lessonsThisWeek = useMemo(
    () => active.reduce((sum, s) => sum + s.lessons.filter((l) => daysBetween(l.date, NOW) <= 7).length, 0),
    [active]
  );

  const homeworkToReview = useMemo(
    () => active.reduce((sum, s) => sum + s.homework.filter((h) => h.status === "submitted" && !h.teacherCorrection).length, 0),
    [active]
  );

  const upcomingPlans = useMemo(
    () =>
      active
        .flatMap((s) => s.lessonPlans.filter((p) => p.status === "planned").map((p) => ({ ...p, studentName: s.name, studentId: s.id })))
        .filter((p) => daysUntil(p.date) >= -1)
        .sort((a, b) => a.date.localeCompare(b.date))
        .slice(0, 5),
    [active]
  );

  const notifications = useMemo(() => generateNotifications(students).slice(0, 5), [students]);

  const recentStudents = useMemo(
    () =>
      [...active]
        .sort((a, b) => {
          const aLast = [...a.lessons].sort((x, y) => y.date.localeCompare(x.date))[0]?.date ?? "";
          const bLast = [...b.lessons].sort((x, y) => y.date.localeCompare(x.date))[0]?.date ?? "";
          return bLast.localeCompare(aLast);
        })
        .slice(0, 4),
    [active]
  );

  const insightHighlights = useMemo(() => {
    const items: { studentName: string; studentId: string; text: string; tone: string }[] = [];
    for (const s of active) {
      const insights = generateInsights(s);
      if (insights[0]) items.push({ studentName: s.name, studentId: s.id, text: insights[0].text, tone: insights[0].tone });
      if (items.length >= 3) break;
    }
    return items;
  }, [active]);

  return (
    <div className="mx-auto max-w-7xl">
      <div className="mb-7">
        <h1 className="font-display text-2xl font-semibold text-ink sm:text-3xl">
          Good to see you, {user?.name.split(" ")[0]} 🌿
        </h1>
        <p className="mt-1 text-sm text-ink-soft">Here&rsquo;s what&rsquo;s happening across your studio today.</p>
      </div>

      <div className="mb-6 grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatTile icon={<Users size={20} />} label="Active students" value={active.length} tone="sage" />
        <StatTile icon={<TrendingUp size={20} />} label="Average progress" value={`${avgProgress}%`} tone="dusty" />
        <StatTile icon={<CalendarClock size={20} />} label="Lessons this week" value={lessonsThisWeek} tone="beige" />
        <StatTile icon={<ClipboardCheck size={20} />} label="Homework to review" value={homeworkToReview} tone="coral" />
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <div className="space-y-6 lg:col-span-2">
          <Card className="p-5">
            <div className="mb-4 flex items-center justify-between">
              <h2 className="font-display text-lg font-semibold text-ink">Recently active students</h2>
              <Link href="/teacher/students" className="flex items-center gap-1 text-sm font-medium text-sage-deep hover:underline">
                View all <ArrowRight size={14} />
              </Link>
            </div>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              {recentStudents.map((s) => (
                <Link
                  key={s.id}
                  href={`/teacher/students/${s.id}`}
                  className="flex items-center gap-3 rounded-xl border border-border bg-canvas-soft/50 p-3 transition-colors hover:bg-canvas-soft"
                >
                  <Avatar name={s.name} emoji={s.avatarEmoji} tone={s.avatarColor as "sage" | "dusty" | "coral" | "beige"} size={40} />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium text-ink">{s.name}</p>
                    <p className="text-xs text-ink-soft">{s.course.unit}</p>
                  </div>
                  <Badge tone="sage">{s.scores.overall}%</Badge>
                </Link>
              ))}
            </div>
          </Card>

          <Card className="p-5">
            <div className="mb-4 flex items-center gap-2">
              <Sparkles size={18} className="text-sage-deep" />
              <h2 className="font-display text-lg font-semibold text-ink">AI insight highlights</h2>
            </div>
            <div className="space-y-3">
              {insightHighlights.map((h) => (
                <Link
                  key={h.studentId}
                  href={`/teacher/students/${h.studentId}?tab=insights`}
                  className="block rounded-xl border border-border bg-canvas-soft/50 p-3 text-sm transition-colors hover:bg-canvas-soft"
                >
                  <span className="font-medium text-ink">{h.studentName}: </span>
                  <span className="text-ink-soft">{h.text}</span>
                </Link>
              ))}
              {insightHighlights.length === 0 && <p className="text-sm text-ink-soft">Insights will appear as lesson history grows.</p>}
            </div>
          </Card>
        </div>

        <div className="space-y-6">
          <Card className="p-5">
            <h2 className="mb-4 font-display text-lg font-semibold text-ink">Upcoming lessons</h2>
            <div className="space-y-3">
              {upcomingPlans.map((p) => (
                <div key={p.id} className="flex items-start gap-3 rounded-xl border border-border bg-canvas-soft/50 p-3">
                  <div className="flex h-10 w-10 shrink-0 flex-col items-center justify-center rounded-lg bg-dusty-soft text-dusty-deep">
                    <span className="text-[10px] font-semibold uppercase leading-none">{formatDateShort(p.date).split(" ")[0]}</span>
                    <span className="text-sm font-bold leading-none">{formatDateShort(p.date).split(" ")[1]}</span>
                  </div>
                  <div className="min-w-0">
                    <p className="truncate text-sm font-medium text-ink">{p.studentName}</p>
                    <p className="truncate text-xs text-ink-soft">{p.objectives || "Lesson planned"}</p>
                  </div>
                </div>
              ))}
              {upcomingPlans.length === 0 && <p className="text-sm text-ink-soft">No upcoming lessons planned yet.</p>}
            </div>
          </Card>

          <Card className="p-5">
            <h2 className="mb-4 font-display text-lg font-semibold text-ink">Needs attention</h2>
            <div className="space-y-2.5">
              {notifications.map((n) => (
                <Link key={n.id} href={n.href} className="flex items-start gap-2.5 rounded-xl p-2 text-sm hover:bg-canvas-soft">
                  <span
                    className={`mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full ${
                      n.tone === "warning" ? "bg-coral" : n.tone === "positive" ? "bg-sage" : "bg-dusty"
                    }`}
                  />
                  <span className="text-ink-soft">{n.text}</span>
                </Link>
              ))}
              {notifications.length === 0 && <p className="text-sm text-ink-soft">Nothing needs attention right now 🎉</p>}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}

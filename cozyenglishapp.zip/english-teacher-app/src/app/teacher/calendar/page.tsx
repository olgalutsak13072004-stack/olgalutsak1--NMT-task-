"use client";

import { useMemo } from "react";
import { useStore } from "@/lib/store";
import { buildCalendarEvents } from "@/lib/calendar";
import { MonthCalendar } from "@/components/calendar/MonthCalendar";

export default function TeacherCalendarPage() {
  const allStudents = useStore((s) => s.students);
  const students = useMemo(() => allStudents.filter((st) => st.status === "active"), [allStudents]);
  const events = useMemo(() => buildCalendarEvents(students, new Date(2026, 6, 27)), [students]);

  return (
    <div className="mx-auto max-w-6xl">
      <div className="mb-6">
        <h1 className="font-display text-2xl font-semibold text-ink">Calendar</h1>
        <p className="mt-1 text-sm text-ink-soft">Lessons, homework deadlines, tests, revisions and birthdays — all in one place.</p>
      </div>
      <MonthCalendar events={events} />
    </div>
  );
}

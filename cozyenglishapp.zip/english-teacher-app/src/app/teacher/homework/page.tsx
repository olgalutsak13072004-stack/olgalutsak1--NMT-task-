"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { useStore } from "@/lib/store";
import { Card } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { Select } from "@/components/ui/Input";
import { ProgressBar } from "@/components/ui/ProgressBar";
import { EmptyState } from "@/components/ui/EmptyState";
import { HomeworkStatus } from "@/lib/types";
import { average, formatDate } from "@/lib/utils";

const statusTone: Record<HomeworkStatus, "sage" | "coral" | "dusty" | "beige"> = {
  submitted: "sage",
  late: "dusty",
  missing: "coral",
  pending: "beige",
};

export default function TeacherHomeworkPage() {
  const allStudents = useStore((s) => s.students);
  const students = useMemo(() => allStudents.filter((st) => st.status === "active"), [allStudents]);
  const [statusFilter, setStatusFilter] = useState<"all" | HomeworkStatus>("all");
  const [studentFilter, setStudentFilter] = useState("all");

  const allHomework = useMemo(
    () => students.flatMap((s) => s.homework.map((h) => ({ ...h, studentName: s.name, studentId: s.id }))),
    [students]
  );

  const overallCompletion = useMemo(() => average(students.map((s) => s.scores.homework)), [students]);

  const filtered = useMemo(() => {
    let list = [...allHomework].sort((a, b) => b.dueDate.localeCompare(a.dueDate));
    if (statusFilter !== "all") list = list.filter((h) => h.status === statusFilter);
    if (studentFilter !== "all") list = list.filter((h) => h.studentId === studentFilter);
    return list;
  }, [allHomework, statusFilter, studentFilter]);

  return (
    <div className="mx-auto max-w-7xl">
      <div className="mb-6">
        <h1 className="font-display text-2xl font-semibold text-ink">Homework Tracker</h1>
        <p className="mt-1 text-sm text-ink-soft">{allHomework.length} assignments across all students</p>
      </div>

      <Card className="mb-5 p-4" hoverLift={false}>
        <ProgressBar value={overallCompletion} label="Average completion rate (all students)" tone="sage" />
      </Card>

      <div className="mb-5 flex flex-col gap-3 sm:flex-row">
        <Select value={studentFilter} onChange={(e) => setStudentFilter(e.target.value)} className="sm:w-56">
          <option value="all">All students</option>
          {students.map((s) => (
            <option key={s.id} value={s.id}>
              {s.name}
            </option>
          ))}
        </Select>
        <Select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value as typeof statusFilter)} className="sm:w-48">
          <option value="all">All statuses</option>
          <option value="submitted">Submitted</option>
          <option value="late">Late</option>
          <option value="missing">Missing</option>
          <option value="pending">Pending</option>
        </Select>
      </div>

      {filtered.length === 0 ? (
        <EmptyState icon="📝" title="No homework found" />
      ) : (
        <div className="space-y-3">
          {filtered.map((h) => (
            <Card key={h.id} className="flex flex-wrap items-center justify-between gap-3 p-4" hoverLift={false}>
              <div>
                <Link href={`/teacher/students/${h.studentId}?tab=homework`} className="font-medium text-ink hover:text-sage-deep">
                  {h.assignment}
                </Link>
                <p className="text-xs text-ink-soft">{h.studentName} · Due {formatDate(h.dueDate)}</p>
              </div>
              <div className="flex items-center gap-2">
                {h.score !== null && <Badge tone="beige">{h.score}%</Badge>}
                <Badge tone={statusTone[h.status]}>{h.status}</Badge>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

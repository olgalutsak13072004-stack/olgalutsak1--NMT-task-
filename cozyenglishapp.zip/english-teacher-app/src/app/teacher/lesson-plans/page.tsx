"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { Plus } from "lucide-react";
import { useStore } from "@/lib/store";
import { Card } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { Select } from "@/components/ui/Input";
import { Modal } from "@/components/ui/Modal";
import { EmptyState } from "@/components/ui/EmptyState";
import { LessonPlanFormModal } from "@/components/students/LessonPlanFormModal";
import { formatDate } from "@/lib/utils";

interface PlanRow {
  id: string;
  date: string;
  objectives: string;
  grammar: string;
  status: "planned" | "completed";
  studentId: string;
  studentName: string;
}

export default function LessonPlansPage() {
  const allStudents = useStore((s) => s.students);
  const students = useMemo(() => allStudents.filter((st) => st.status === "active"), [allStudents]);
  const updateLessonPlan = useStore((s) => s.updateLessonPlan);
  const [pickerOpen, setPickerOpen] = useState(false);
  const [pickedStudent, setPickedStudent] = useState(students[0]?.id ?? "");
  const [createOpen, setCreateOpen] = useState(false);
  const [dragging, setDragging] = useState<PlanRow | null>(null);

  const allPlans: PlanRow[] = useMemo(
    () =>
      students.flatMap((s) =>
        s.lessonPlans.map((p) => ({
          id: p.id,
          date: p.date,
          objectives: p.objectives,
          grammar: p.grammar,
          status: p.status,
          studentId: s.id,
          studentName: s.name,
        }))
      ),
    [students]
  );

  const planned = allPlans.filter((p) => p.status === "planned").sort((a, b) => a.date.localeCompare(b.date));
  const completed = allPlans.filter((p) => p.status === "completed").sort((a, b) => b.date.localeCompare(a.date));

  function handleDrop(status: "planned" | "completed") {
    if (dragging && dragging.status !== status) {
      updateLessonPlan(dragging.studentId, dragging.id, { status });
    }
    setDragging(null);
  }

  return (
    <div className="mx-auto max-w-6xl">
      <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="font-display text-2xl font-semibold text-ink">Lesson Plans</h1>
          <p className="mt-1 text-sm text-ink-soft">Drag a card between columns to mark it taught.</p>
        </div>
        <Button
          onClick={() => {
            setPickedStudent(students[0]?.id ?? "");
            setPickerOpen(true);
          }}
          className="gap-1.5"
        >
          <Plus size={16} /> New plan
        </Button>
      </div>

      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2">
        <div onDragOver={(e) => e.preventDefault()} onDrop={() => handleDrop("planned")}>
          <p className="mb-3 text-sm font-semibold text-ink-soft">📋 Planned ({planned.length})</p>
          <div className="min-h-[200px] space-y-3 rounded-2xl border border-dashed border-border p-3">
            {planned.length === 0 && <EmptyState title="No planned lessons" description="Drop a completed lesson here or create a new plan." />}
            {planned.map((p) => (
              <PlanCard key={p.id} plan={p} onDragStart={() => setDragging(p)} />
            ))}
          </div>
        </div>
        <div onDragOver={(e) => e.preventDefault()} onDrop={() => handleDrop("completed")}>
          <p className="mb-3 text-sm font-semibold text-ink-soft">✅ Taught ({completed.length})</p>
          <div className="min-h-[200px] space-y-3 rounded-2xl border border-dashed border-border p-3">
            {completed.length === 0 && <EmptyState title="Nothing taught yet" description="Drag a planned lesson here once it's delivered." />}
            {completed.map((p) => (
              <PlanCard key={p.id} plan={p} onDragStart={() => setDragging(p)} />
            ))}
          </div>
        </div>
      </div>

      <Modal open={pickerOpen} onClose={() => setPickerOpen(false)} title="Choose a student">
        <div className="space-y-4">
          <Select value={pickedStudent} onChange={(e) => setPickedStudent(e.target.value)}>
            {students.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
          </Select>
          <div className="flex justify-end gap-2">
            <Button variant="ghost" onClick={() => setPickerOpen(false)}>
              Cancel
            </Button>
            <Button
              onClick={() => {
                setPickerOpen(false);
                setCreateOpen(true);
              }}
            >
              Continue
            </Button>
          </div>
        </div>
      </Modal>

      {pickedStudent && <LessonPlanFormModal open={createOpen} onClose={() => setCreateOpen(false)} studentId={pickedStudent} />}
    </div>
  );
}

function PlanCard({ plan, onDragStart }: { plan: PlanRow; onDragStart: () => void }) {
  return (
    <Card draggable onDragStart={onDragStart} className="cursor-grab p-4 active:cursor-grabbing" hoverLift={false}>
      <div className="mb-1.5 flex items-center justify-between">
        <Badge tone="dusty">{formatDate(plan.date)}</Badge>
      </div>
      <p className="text-sm font-medium text-ink">{plan.objectives || "Lesson plan"}</p>
      {plan.grammar && <p className="text-xs text-ink-soft">Grammar: {plan.grammar}</p>}
      <Link href={`/teacher/students/${plan.studentId}?tab=planning`} className="mt-2 inline-block text-xs font-medium text-sage-deep hover:underline">
        {plan.studentName} →
      </Link>
    </Card>
  );
}

"use client";

import Link from "next/link";
import { useMemo } from "react";
import { useStore } from "@/lib/store";
import { Card } from "@/components/ui/Card";
import { Avatar } from "@/components/ui/Avatar";
import { Badge } from "@/components/ui/Badge";
import { ACHIEVEMENT_CATALOG } from "@/lib/achievements";

export default function TeacherAchievementsPage() {
  const allStudents = useStore((s) => s.students);
  const students = useMemo(() => allStudents.filter((st) => st.status === "active"), [allStudents]);

  return (
    <div className="mx-auto max-w-7xl">
      <div className="mb-6">
        <h1 className="font-display text-2xl font-semibold text-ink">Achievements</h1>
        <p className="mt-1 text-sm text-ink-soft">Celebrate milestones across your studio.</p>
      </div>

      <div className="mb-8 grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {ACHIEVEMENT_CATALOG.map((a) => {
          const earners = students.filter((s) => s.achievements.some((e) => e.key === a.key));
          return (
            <Card key={a.key} className="p-5" hoverLift={false}>
              <div className="mb-3 flex items-center gap-2">
                <span className="text-3xl">{a.emoji}</span>
                <div>
                  <p className="font-display text-sm font-semibold text-ink">{a.label}</p>
                  <p className="text-xs text-ink-soft">{a.description}</p>
                </div>
              </div>
              <p className="mb-2 text-xs font-semibold text-ink-faint">{earners.length} earned</p>
              <div className="flex flex-wrap gap-1.5">
                {earners.length === 0 && <span className="text-xs text-ink-faint">No one yet</span>}
                {earners.map((s) => (
                  <Link key={s.id} href={`/teacher/students/${s.id}?tab=achievements`} title={s.name}>
                    <Avatar name={s.name} emoji={s.avatarEmoji} tone={s.avatarColor as "sage" | "dusty" | "coral" | "beige"} size={30} />
                  </Link>
                ))}
              </div>
            </Card>
          );
        })}
      </div>

      <h2 className="mb-4 font-display text-lg font-semibold text-ink">By student</h2>
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-3">
        {students.map((s) => (
          <Card key={s.id} className="p-5" hoverLift={false}>
            <div className="mb-3 flex items-center gap-3">
              <Avatar name={s.name} emoji={s.avatarEmoji} tone={s.avatarColor as "sage" | "dusty" | "coral" | "beige"} size={40} />
              <div>
                <p className="font-medium text-ink">{s.name}</p>
                <p className="text-xs text-ink-soft">{s.achievements.length} badge{s.achievements.length !== 1 ? "s" : ""}</p>
              </div>
            </div>
            <div className="flex flex-wrap gap-1.5">
              {s.achievements.length === 0 && <Badge tone="neutral">No badges yet</Badge>}
              {s.achievements.map((a) => (
                <span key={a.key} title={a.label} className="text-xl">
                  {a.emoji}
                </span>
              ))}
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}

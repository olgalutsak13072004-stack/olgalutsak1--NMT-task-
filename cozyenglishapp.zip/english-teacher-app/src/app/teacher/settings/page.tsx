"use client";

import { useState } from "react";
import { Moon, Sun, Download, RotateCcw, Bell } from "lucide-react";
import { useTheme } from "@/lib/theme";
import { useCurrentUser } from "@/lib/auth";
import { useStore } from "@/lib/store";
import { Card } from "@/components/ui/Card";
import { Avatar } from "@/components/ui/Avatar";
import { Button } from "@/components/ui/Button";
import { downloadFile, cn } from "@/lib/utils";

export default function SettingsPage() {
  const { theme, toggleTheme } = useTheme();
  const user = useCurrentUser();
  const students = useStore((s) => s.students);
  const [notifPrefs, setNotifPrefs] = useState({
    homeworkUnchecked: true,
    studentAbsent: true,
    upcomingLesson: true,
    revisionDue: false,
    inactiveStudent: true,
  });

  function exportAllData() {
    downloadFile("cozy-english-data.json", JSON.stringify(students, null, 2), "application/json");
  }

  function resetDemoData() {
    if (confirm("This will clear all local changes and reload the original demo data. Continue?")) {
      localStorage.removeItem("cozy-english-store");
      window.location.reload();
    }
  }

  if (!user) return null;

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <div>
        <h1 className="font-display text-2xl font-semibold text-ink">Settings</h1>
        <p className="mt-1 text-sm text-ink-soft">Manage your studio preferences.</p>
      </div>

      <Card className="p-5" hoverLift={false}>
        <h2 className="mb-4 font-display text-base font-semibold text-ink">Profile</h2>
        <div className="flex items-center gap-4">
          <Avatar name={user.name} size={56} tone="sage" />
          <div>
            <p className="font-medium text-ink">{user.name}</p>
            <p className="text-sm text-ink-soft">{user.email}</p>
          </div>
        </div>
      </Card>

      <Card className="p-5" hoverLift={false}>
        <h2 className="mb-4 font-display text-base font-semibold text-ink">Appearance</h2>
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-ink">Theme</p>
            <p className="text-xs text-ink-soft">Switch between light and dark mode</p>
          </div>
          <button
            onClick={toggleTheme}
            className="flex items-center gap-2 rounded-full border border-border bg-canvas-soft px-4 py-2 text-sm font-medium text-ink"
          >
            {theme === "light" ? <Sun size={15} /> : <Moon size={15} />}
            {theme === "light" ? "Light" : "Dark"}
          </button>
        </div>
      </Card>

      <Card className="p-5" hoverLift={false}>
        <div className="mb-4 flex items-center gap-2">
          <Bell size={16} className="text-ink-soft" />
          <h2 className="font-display text-base font-semibold text-ink">Notification preferences</h2>
        </div>
        <div className="space-y-3">
          {(
            [
              ["homeworkUnchecked", "Homework not checked"],
              ["studentAbsent", "Student absent"],
              ["upcomingLesson", "Upcoming lesson reminders"],
              ["revisionDue", "Revision due"],
              ["inactiveStudent", "Student inactive"],
            ] as [keyof typeof notifPrefs, string][]
          ).map(([key, label]) => (
            <label key={key} className="flex cursor-pointer items-center justify-between text-sm">
              <span className="text-ink-soft">{label}</span>
              <button
                type="button"
                onClick={() => setNotifPrefs((p) => ({ ...p, [key]: !p[key] }))}
                className={cn("relative h-6 w-11 rounded-full transition-colors", notifPrefs[key] ? "bg-sage" : "bg-canvas-soft")}
              >
                <span className={cn("absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-transform", notifPrefs[key] ? "translate-x-5" : "translate-x-0.5")} />
              </button>
            </label>
          ))}
        </div>
      </Card>

      <Card className="p-5" hoverLift={false}>
        <h2 className="mb-4 font-display text-base font-semibold text-ink">Data</h2>
        <div className="flex flex-wrap gap-3">
          <Button variant="outline" onClick={exportAllData} className="gap-1.5">
            <Download size={15} /> Export all data (JSON)
          </Button>
          <Button variant="outline" onClick={resetDemoData} className="gap-1.5 text-coral">
            <RotateCcw size={15} /> Reset demo data
          </Button>
        </div>
        <p className="mt-3 text-xs text-ink-faint">
          This demo stores data locally in your browser. Connect Supabase (see README) to persist data in PostgreSQL with real authentication.
        </p>
      </Card>
    </div>
  );
}

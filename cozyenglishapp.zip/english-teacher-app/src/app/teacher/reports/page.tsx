"use client";

import { useMemo, useState } from "react";
import { Download, Printer, FileSpreadsheet } from "lucide-react";
import { Radar, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, ResponsiveContainer } from "recharts";
import { useStore } from "@/lib/store";
import { Button } from "@/components/ui/Button";
import { Select } from "@/components/ui/Input";
import { Badge } from "@/components/ui/Badge";
import { SKILL_META } from "@/lib/skill-meta";
import { generateInsights, recommendedRevisionTopics } from "@/lib/insights";
import { weakestSkills, strongestSkills } from "@/lib/scoring";
import { formatDate, toCSV, downloadFile } from "@/lib/utils";

export default function ReportsPage() {
  const allStudents = useStore((s) => s.students);
  const students = useMemo(() => allStudents.filter((st) => st.status === "active"), [allStudents]);
  const [studentId, setStudentId] = useState(students[0]?.id ?? "");
  const student = students.find((s) => s.id === studentId) ?? students[0];

  const insights = useMemo(() => (student ? generateInsights(student) : []), [student]);
  const revisionTopics = useMemo(() => (student ? recommendedRevisionTopics(student) : []), [student]);
  const weak = student ? weakestSkills(student.scores, 3) : [];
  const strong = student ? strongestSkills(student.scores, 3) : [];

  const radarData = student
    ? SKILL_META.filter((m) => m.key !== "homework" && m.key !== "attendance").map((m) => ({ skill: m.label, value: student.scores[m.key] }))
    : [];

  function exportCSV() {
    if (!student) return;
    const rows = student.lessons.map((l) => ({
      Date: formatDate(l.date),
      Topic: l.topic,
      Attendance: l.attendance,
      "Homework completion": `${l.homeworkCompletion}%`,
      Grammar: l.assessment.grammar,
      Vocabulary: l.assessment.vocabulary,
      Listening: l.assessment.listening,
      Speaking: l.assessment.speaking,
    }));
    downloadFile(`${student.name.replace(/\s+/g, "_")}_lesson_summary.csv`, toCSV(rows));
  }

  function exportProgressCSV() {
    if (!student) return;
    const rows = SKILL_META.map((m) => ({ Skill: m.label, Score: student.scores[m.key] }));
    downloadFile(`${student.name.replace(/\s+/g, "_")}_progress.csv`, toCSV(rows));
  }

  if (!student) {
    return <p className="text-sm text-ink-soft">Add a student to generate reports.</p>;
  }

  return (
    <div className="mx-auto max-w-5xl">
      <div className="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between no-print">
        <div>
          <h1 className="font-display text-2xl font-semibold text-ink">Reports</h1>
          <p className="mt-1 text-sm text-ink-soft">Automatic progress reports, ready to export.</p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Select value={studentId} onChange={(e) => setStudentId(e.target.value)} className="w-56">
            {students.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
          </Select>
          <Button variant="outline" size="sm" onClick={exportProgressCSV} className="gap-1.5">
            <FileSpreadsheet size={14} /> Progress CSV
          </Button>
          <Button variant="outline" size="sm" onClick={exportCSV} className="gap-1.5">
            <Download size={14} /> Lessons CSV
          </Button>
          <Button size="sm" onClick={() => window.print()} className="gap-1.5">
            <Printer size={14} /> Print / PDF
          </Button>
        </div>
      </div>

      <div id="report-content" className="space-y-6 rounded-2xl border border-border bg-surface p-6 shadow-[var(--shadow-cozy)] print:border-0 print:shadow-none">
        <div className="flex items-center justify-between border-b border-border pb-4">
          <div>
            <h2 className="font-display text-xl font-semibold text-ink">Progress Report — {student.name}</h2>
            <p className="text-sm text-ink-soft">{student.course.name} · {student.level} · Generated {formatDate(new Date().toISOString())}</p>
          </div>
          <Badge tone="sage">Overall {student.scores.overall}%</Badge>
        </div>

        <section>
          <h3 className="mb-2 font-display text-base font-semibold text-ink">Progress summary</h3>
          <p className="text-sm text-ink-soft">
            {student.name} is currently at level {student.level} with an overall progress score of {student.scores.overall}%.
            Attendance stands at {student.scores.attendance}% and homework completion at {student.scores.homework}%,
            based on {student.lessons.length} logged lessons and {student.tests.length} tests.
          </p>
        </section>

        <section className="grid grid-cols-1 gap-6 sm:grid-cols-2">
          <div>
            <h3 className="mb-2 font-display text-base font-semibold text-ink">Skill radar</h3>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <RadarChart data={radarData} outerRadius="75%">
                  <PolarGrid stroke="var(--color-border)" />
                  <PolarAngleAxis dataKey="skill" tick={{ fill: "var(--color-ink-soft)", fontSize: 11 }} />
                  <PolarRadiusAxis domain={[0, 100]} tick={false} axisLine={false} />
                  <Radar dataKey="value" stroke="var(--color-sage)" fill="var(--color-sage)" fillOpacity={0.35} />
                </RadarChart>
              </ResponsiveContainer>
            </div>
          </div>
          <div className="space-y-4">
            <div>
              <h3 className="mb-1.5 font-display text-base font-semibold text-ink">Strengths</h3>
              <ul className="list-inside list-disc text-sm text-ink-soft">
                {strong.map((k) => (
                  <li key={k}>{SKILL_META.find((m) => m.key === k)?.label} — {student.scores[k as keyof typeof student.scores]}%</li>
                ))}
              </ul>
            </div>
            <div>
              <h3 className="mb-1.5 font-display text-base font-semibold text-ink">Weaknesses</h3>
              <ul className="list-inside list-disc text-sm text-ink-soft">
                {weak.map((k) => (
                  <li key={k}>{SKILL_META.find((m) => m.key === k)?.label} — {student.scores[k as keyof typeof student.scores]}%</li>
                ))}
              </ul>
            </div>
          </div>
        </section>

        <section>
          <h3 className="mb-2 font-display text-base font-semibold text-ink">Teacher recommendations</h3>
          <ul className="list-inside list-disc space-y-1 text-sm text-ink-soft">
            {insights.filter((i) => i.tone !== "positive").map((i) => (
              <li key={i.id}>{i.text}</li>
            ))}
            {revisionTopics.map((t) => (
              <li key={t}>Revise: {t}</li>
            ))}
          </ul>
        </section>

        <section className="grid grid-cols-2 gap-4 sm:grid-cols-4">
          <ReportStat label="Homework" value={`${student.scores.homework}%`} />
          <ReportStat label="Attendance" value={`${student.scores.attendance}%`} />
          <ReportStat label="Avg test score" value={student.tests.length ? `${Math.round(student.tests.reduce((a, t) => a + (t.score / t.maxScore) * 100, 0) / student.tests.length)}%` : "—"} />
          <ReportStat label="Lessons logged" value={student.lessons.length} />
        </section>

        <section>
          <h3 className="mb-2 font-display text-base font-semibold text-ink">Unit test results</h3>
          {student.tests.length === 0 ? (
            <p className="text-sm text-ink-soft">No tests recorded yet.</p>
          ) : (
            <table className="w-full text-left text-sm">
              <thead>
                <tr className="border-b border-border text-xs text-ink-faint">
                  <th className="py-1.5 font-medium">Test</th>
                  <th className="py-1.5 font-medium">Date</th>
                  <th className="py-1.5 font-medium">Score</th>
                </tr>
              </thead>
              <tbody>
                {student.tests.map((t) => (
                  <tr key={t.id} className="border-b border-border/60">
                    <td className="py-1.5 text-ink-soft">{t.title}</td>
                    <td className="py-1.5 text-ink-soft">{formatDate(t.date)}</td>
                    <td className="py-1.5 text-ink-soft">{t.score}/{t.maxScore}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </section>

        <section>
          <h3 className="mb-2 font-display text-base font-semibold text-ink">Future learning plan</h3>
          <p className="text-sm text-ink-soft">
            Focus the next month on {weak.map((k) => SKILL_META.find((m) => m.key === k)?.label).join(" and ")}, while maintaining
            momentum in {strong.map((k) => SKILL_META.find((m) => m.key === k)?.label).join(" and ")}.
            {student.learningGoals[0] ? ` Primary goal: ${student.learningGoals[0].title} (${student.learningGoals[0].progress}% complete).` : ""}
          </p>
        </section>
      </div>
    </div>
  );
}

function ReportStat({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="rounded-xl bg-canvas-soft/60 p-3 text-center">
      <p className="font-display text-lg font-semibold text-ink">{value}</p>
      <p className="text-[11px] text-ink-soft">{label}</p>
    </div>
  );
}

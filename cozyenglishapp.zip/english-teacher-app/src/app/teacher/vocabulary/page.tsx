"use client";

import { useMemo, useState } from "react";
import { Search } from "lucide-react";
import Link from "next/link";
import { useStore } from "@/lib/store";
import { Card } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { Input, Select } from "@/components/ui/Input";
import { EmptyState } from "@/components/ui/EmptyState";
import { formatDateShort } from "@/lib/utils";

export default function TeacherVocabularyPage() {
  const allStudents = useStore((s) => s.students);
  const students = useMemo(() => allStudents.filter((st) => st.status === "active"), [allStudents]);
  const [query, setQuery] = useState("");
  const [studentFilter, setStudentFilter] = useState("all");
  const [statusFilter, setStatusFilter] = useState<"all" | "mastered" | "revision">("all");

  const allWords = useMemo(
    () =>
      students.flatMap((s) =>
        s.vocabulary.map((v) => ({ ...v, studentName: s.name, studentId: s.id, studentEmoji: s.avatarEmoji }))
      ),
    [students]
  );

  const filtered = useMemo(() => {
    let list = [...allWords].sort((a, b) => b.dateLearned.localeCompare(a.dateLearned));
    if (query.trim()) {
      const q = query.toLowerCase();
      list = list.filter((v) => v.word.toLowerCase().includes(q) || v.translation.toLowerCase().includes(q));
    }
    if (studentFilter !== "all") list = list.filter((v) => v.studentId === studentFilter);
    if (statusFilter === "mastered") list = list.filter((v) => v.mastered);
    if (statusFilter === "revision") list = list.filter((v) => v.needsRevision);
    return list;
  }, [allWords, query, studentFilter, statusFilter]);

  return (
    <div className="mx-auto max-w-7xl">
      <div className="mb-6">
        <h1 className="font-display text-2xl font-semibold text-ink">Vocabulary Tracker</h1>
        <p className="mt-1 text-sm text-ink-soft">{allWords.length} words logged across all students</p>
      </div>

      <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-center">
        <div className="relative flex-1">
          <Search size={16} className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-ink-faint" />
          <Input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search words or translations…" className="pl-9" />
        </div>
        <Select value={studentFilter} onChange={(e) => setStudentFilter(e.target.value)} className="sm:w-56">
          <option value="all">All students</option>
          {students.map((s) => (
            <option key={s.id} value={s.id}>
              {s.name}
            </option>
          ))}
        </Select>
        <Select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value as typeof statusFilter)} className="sm:w-48">
          <option value="all">All words</option>
          <option value="mastered">Mastered</option>
          <option value="revision">Needs revision</option>
        </Select>
      </div>

      {filtered.length === 0 ? (
        <EmptyState icon="📚" title="No vocabulary found" description="Try a different search or filter." />
      ) : (
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 xl:grid-cols-3">
          {filtered.map((v) => (
            <Card key={v.id} className="p-4" hoverLift={false}>
              <div className="mb-1.5 flex items-start justify-between">
                <p className="font-display text-base font-semibold text-ink">{v.word}</p>
                {v.mastered ? <Badge tone="sage">Mastered</Badge> : <Badge tone="coral">Revise</Badge>}
              </div>
              <p className="text-sm text-ink-soft">{v.translation}</p>
              <Link href={`/teacher/students/${v.studentId}?tab=vocabulary`} className="mt-2 flex items-center gap-1.5 text-xs text-ink-faint hover:text-sage-deep">
                {v.studentEmoji} {v.studentName} · {formatDateShort(v.dateLearned)}
              </Link>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

"use client";

import { useLoggedInStudent } from "@/lib/auth";
import { EmptyState } from "@/components/ui/EmptyState";
import { FeedbackTab } from "@/components/students/tabs/FeedbackTab";

export default function StudentFeedbackPage() {
  const student = useLoggedInStudent();
  if (!student) return <EmptyState icon="🌱" title="No profile linked" />;

  return (
    <div className="mx-auto max-w-4xl">
      <div className="mb-6">
        <h1 className="font-display text-2xl font-semibold text-ink">Feedback</h1>
        <p className="mt-1 text-sm text-ink-soft">Feedback from your teacher, and a place to share your own.</p>
      </div>
      <FeedbackTab student={student} role="student" />
    </div>
  );
}

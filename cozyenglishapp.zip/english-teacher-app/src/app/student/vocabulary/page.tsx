"use client";

import { useLoggedInStudent } from "@/lib/auth";
import { EmptyState } from "@/components/ui/EmptyState";
import { VocabularyTab } from "@/components/students/tabs/VocabularyTab";

export default function StudentVocabularyPage() {
  const student = useLoggedInStudent();
  if (!student) return <EmptyState icon="🌱" title="No profile linked" />;

  return (
    <div className="mx-auto max-w-6xl">
      <div className="mb-6">
        <h1 className="font-display text-2xl font-semibold text-ink">Your Vocabulary</h1>
        <p className="mt-1 text-sm text-ink-soft">Every word you&rsquo;ve learned, tracked automatically after each lesson.</p>
      </div>
      <VocabularyTab student={student} readOnly />
    </div>
  );
}

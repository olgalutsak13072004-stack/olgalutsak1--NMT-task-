"use client";

import { Moon, Sun } from "lucide-react";
import { useTheme } from "@/lib/theme";
import { useCurrentUser, useLoggedInStudent } from "@/lib/auth";
import { Card } from "@/components/ui/Card";
import { Avatar } from "@/components/ui/Avatar";
import { formatDate } from "@/lib/utils";

export default function StudentSettingsPage() {
  const { theme, toggleTheme } = useTheme();
  const user = useCurrentUser();
  const student = useLoggedInStudent();

  if (!user) return null;

  return (
    <div className="mx-auto max-w-3xl space-y-6">
      <div>
        <h1 className="font-display text-2xl font-semibold text-ink">Settings</h1>
        <p className="mt-1 text-sm text-ink-soft">Your account preferences.</p>
      </div>

      <Card className="p-5" hoverLift={false}>
        <h2 className="mb-4 font-display text-base font-semibold text-ink">Profile</h2>
        <div className="flex items-center gap-4">
          <Avatar name={user.name} emoji={student?.avatarEmoji} tone={(student?.avatarColor as "sage" | "dusty" | "coral" | "beige") ?? "sage"} size={56} />
          <div>
            <p className="font-medium text-ink">{user.name}</p>
            <p className="text-sm text-ink-soft">{user.email}</p>
            {student && <p className="mt-1 text-xs text-ink-faint">Learning with you since {formatDate(student.startDate)}</p>}
          </div>
        </div>
      </Card>

      <Card className="p-5" hoverLift={false}>
        <h2 className="mb-4 font-display text-base font-semibold text-ink">Appearance</h2>
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-medium text-ink">Theme</p>
            <p className="text-xs text-ink-soft">Switch between light and dark mode</p>
          </div>
          <button
            onClick={toggleTheme}
            className="flex items-center gap-2 rounded-full border border-border bg-canvas-soft px-4 py-2 text-sm font-medium text-ink"
          >
            {theme === "light" ? <Sun size={15} /> : <Moon size={15} />}
            {theme === "light" ? "Light" : "Dark"}
          </button>
        </div>
      </Card>
    </div>
  );
}

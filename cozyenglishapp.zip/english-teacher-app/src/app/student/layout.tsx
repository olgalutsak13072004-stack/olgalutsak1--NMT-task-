"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { useCurrentUser } from "@/lib/auth";
import { AppShell } from "@/components/layout/AppShell";

export default function StudentLayout({ children }: { children: React.ReactNode }) {
  const user = useCurrentUser();
  const router = useRouter();

  useEffect(() => {
    if (!user) {
      router.replace("/login");
    } else if (user.role !== "student") {
      router.replace("/teacher");
    }
  }, [user, router]);

  if (!user || user.role !== "student") return null;

  return <AppShell user={user}>{children}</AppShell>;
}

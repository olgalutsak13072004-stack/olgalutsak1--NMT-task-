"use client";

import { useMemo } from "react";
import { useLoggedInStudent } from "@/lib/auth";
import { EmptyState } from "@/components/ui/EmptyState";
import { buildCalendarEvents } from "@/lib/calendar";
import { MonthCalendar } from "@/components/calendar/MonthCalendar";

export default function StudentCalendarPage() {
  const student = useLoggedInStudent();
  const events = useMemo(() => (student ? buildCalendarEvents([student], new Date(2026, 6, 27)) : []), [student]);

  if (!student) return <EmptyState icon="🌱" title="No profile linked" />;

  return (
    <div className="mx-auto max-w-6xl">
      <div className="mb-6">
        <h1 className="font-display text-2xl font-semibold text-ink">Your Calendar</h1>
        <p className="mt-1 text-sm text-ink-soft">Lessons, homework deadlines, tests and revision sessions.</p>
      </div>
      <MonthCalendar events={events} showStudent={false} />
    </div>
  );
}

"use client";

import Link from "next/link";
import { useMemo } from "react";
import { CalendarClock, ClipboardList, Target } from "lucide-react";
import { useLoggedInStudent } from "@/lib/auth";
import { Card } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { CircularProgress, ProgressBar } from "@/components/ui/ProgressBar";
import { EmptyState } from "@/components/ui/EmptyState";
import { SKILL_META } from "@/lib/skill-meta";
import { generateInsights } from "@/lib/insights";
import { formatDate, daysUntil } from "@/lib/utils";

export default function StudentDashboard() {
  const student = useLoggedInStudent();

  const upcomingPlan = useMemo(
    () => student?.lessonPlans.filter((p) => p.status === "planned").sort((a, b) => a.date.localeCompare(b.date))[0],
    [student]
  );

  const homeworkDue = useMemo(
    () => student?.homework.filter((h) => h.status === "pending").sort((a, b) => a.dueDate.localeCompare(b.dueDate)).slice(0, 3) ?? [],
    [student]
  );

  const positiveInsight = useMemo(() => (student ? generateInsights(student).find((i) => i.tone === "positive") : undefined), [student]);

  if (!student) {
    return <EmptyState icon="🌱" title="No profile linked" description="Ask your teacher to link this account to a student profile." />;
  }

  return (
    <div className="mx-auto max-w-6xl">
      <div className="mb-7">
        <h1 className="font-display text-2xl font-semibold text-ink sm:text-3xl">Hi {student.name.split(" ")[0]}, welcome back 🌿</h1>
        <p className="mt-1 text-sm text-ink-soft">Here&rsquo;s a snapshot of your English learning journey.</p>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        <Card className="flex flex-col items-center p-6 lg:col-span-1">
          <p className="mb-3 text-sm font-semibold text-ink-soft">Overall Progress</p>
          <CircularProgress value={student.scores.overall} size={150} tone="sage" />
          <Badge tone="sage" className="mt-4">
            Level {student.level}
          </Badge>
        </Card>

        <div className="space-y-4 lg:col-span-2">
          <Card className="p-5" hoverLift={false}>
            <h3 className="mb-3 font-display text-base font-semibold text-ink">Skill breakdown</h3>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              {SKILL_META.filter((m) => m.key !== "homework" && m.key !== "attendance").map((m) => (
                <ProgressBar key={m.key} value={student.scores[m.key]} label={`${m.icon} ${m.label}`} tone={m.tone} size="sm" />
              ))}
            </div>
          </Card>
          {positiveInsight && (
            <Card className="p-4" hoverLift={false}>
              <p className="text-sm text-sage-deep">✨ {positiveInsight.text}</p>
            </Card>
          )}
        </div>
      </div>

      <div className="mt-6 grid grid-cols-1 gap-6 lg:grid-cols-3">
        <Card className="p-5" hoverLift={false}>
          <div className="mb-3 flex items-center gap-2">
            <CalendarClock size={16} className="text-dusty-deep" />
            <h3 className="font-display text-base font-semibold text-ink">Next lesson</h3>
          </div>
          {upcomingPlan ? (
            <div>
              <p className="text-sm font-medium text-ink">{formatDate(upcomingPlan.date)}</p>
              <p className="text-xs text-ink-soft">{upcomingPlan.objectives || "Lesson planned"}</p>
              <p className="mt-2 text-xs text-ink-faint">{Math.max(0, daysUntil(upcomingPlan.date))} day(s) away</p>
            </div>
          ) : (
            <p className="text-sm text-ink-soft">No upcoming lesson scheduled yet.</p>
          )}
        </Card>

        <Card className="p-5" hoverLift={false}>
          <div className="mb-3 flex items-center gap-2">
            <ClipboardList size={16} className="text-coral" />
            <h3 className="font-display text-base font-semibold text-ink">Homework due</h3>
          </div>
          {homeworkDue.length === 0 ? (
            <p className="text-sm text-ink-soft">You&rsquo;re all caught up! 🎉</p>
          ) : (
            <ul className="space-y-2 text-sm">
              {homeworkDue.map((h) => (
                <li key={h.id} className="flex items-center justify-between">
                  <span className="truncate text-ink-soft">{h.assignment}</span>
                  <span className="ml-2 shrink-0 text-xs text-ink-faint">{formatDate(h.dueDate)}</span>
                </li>
              ))}
            </ul>
          )}
          <Link href="/student/homework" className="mt-3 inline-block text-xs font-medium text-sage-deep hover:underline">
            View all homework →
          </Link>
        </Card>

        <Card className="p-5" hoverLift={false}>
          <div className="mb-3 flex items-center gap-2">
            <Target size={16} className="text-sage-deep" />
            <h3 className="font-display text-base font-semibold text-ink">Learning goal</h3>
          </div>
          {student.learningGoals[0] ? (
            <div>
              <p className="text-sm font-medium text-ink">🎯 {student.learningGoals[0].title}</p>
              <div className="mt-2">
                <ProgressBar value={student.learningGoals[0].progress} showValue size="sm" tone="sage" />
              </div>
            </div>
          ) : (
            <p className="text-sm text-ink-soft">No goals set yet.</p>
          )}
          <Link href="/student/goals" className="mt-3 inline-block text-xs font-medium text-sage-deep hover:underline">
            View all goals →
          </Link>
        </Card>
      </div>
    </div>
  );
}

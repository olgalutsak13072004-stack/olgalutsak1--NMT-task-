"use client";

import { useLoggedInStudent } from "@/lib/auth";
import { EmptyState } from "@/components/ui/EmptyState";
import { StudentHomeworkList } from "@/components/students/StudentHomeworkList";

export default function StudentHomeworkPage() {
  const student = useLoggedInStudent();
  if (!student) return <EmptyState icon="🌱" title="No profile linked" />;

  return (
    <div className="mx-auto max-w-4xl">
      <div className="mb-6">
        <h1 className="font-display text-2xl font-semibold text-ink">Homework</h1>
        <p className="mt-1 text-sm text-ink-soft">Assignments, due dates and your teacher&rsquo;s corrections.</p>
      </div>
      <StudentHomeworkList student={student} />
    </div>
  );
}

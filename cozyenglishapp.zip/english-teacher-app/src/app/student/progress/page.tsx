"use client";

import { useLoggedInStudent } from "@/lib/auth";
import { EmptyState } from "@/components/ui/EmptyState";
import { StudentStatistics } from "@/components/statistics/StudentStatistics";

export default function StudentProgressPage() {
  const student = useLoggedInStudent();
  if (!student) return <EmptyState icon="🌱" title="No profile linked" />;

  return (
    <div className="mx-auto max-w-6xl">
      <div className="mb-6">
        <h1 className="font-display text-2xl font-semibold text-ink">Your Progress</h1>
        <p className="mt-1 text-sm text-ink-soft">Automatically tracked from lessons, homework, attendance and tests.</p>
      </div>
      <StudentStatistics student={student} />
    </div>
  );
}

"use client";

import { useLoggedInStudent } from "@/lib/auth";
import { EmptyState } from "@/components/ui/EmptyState";
import { AchievementsTab } from "@/components/students/tabs/AchievementsTab";

export default function StudentAchievementsPage() {
  const student = useLoggedInStudent();
  if (!student) return <EmptyState icon="🌱" title="No profile linked" />;

  return (
    <div className="mx-auto max-w-6xl">
      <div className="mb-6">
        <h1 className="font-display text-2xl font-semibold text-ink">Achievements</h1>
        <p className="mt-1 text-sm text-ink-soft">Badges you&rsquo;ve earned on your learning journey.</p>
      </div>
      <AchievementsTab student={student} readOnly />
    </div>
  );
}

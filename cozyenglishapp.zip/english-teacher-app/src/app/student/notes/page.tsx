"use client";

import { useLoggedInStudent } from "@/lib/auth";
import { EmptyState } from "@/components/ui/EmptyState";
import { StudentLessonNotesView } from "@/components/students/StudentLessonNotesView";

export default function StudentNotesPage() {
  const student = useLoggedInStudent();
  if (!student) return <EmptyState icon="🌱" title="No profile linked" />;

  return (
    <div className="mx-auto max-w-4xl">
      <div className="mb-6">
        <h1 className="font-display text-2xl font-semibold text-ink">Lesson Notes</h1>
        <p className="mt-1 text-sm text-ink-soft">What you covered, practised and achieved in each lesson.</p>
      </div>
      <StudentLessonNotesView student={student} />
    </div>
  );
}

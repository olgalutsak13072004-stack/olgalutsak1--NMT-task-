"use client";

import { useLoggedInStudent } from "@/lib/auth";
import { EmptyState } from "@/components/ui/EmptyState";
import { GoalsTab } from "@/components/students/tabs/GoalsTab";

export default function StudentGoalsPage() {
  const student = useLoggedInStudent();
  if (!student) return <EmptyState icon="🌱" title="No profile linked" />;

  return (
    <div className="mx-auto max-w-5xl">
      <div className="mb-6">
        <h1 className="font-display text-2xl font-semibold text-ink">Learning Goals</h1>
        <p className="mt-1 text-sm text-ink-soft">Goals your teacher has set for you, with milestones along the way.</p>
      </div>
      <GoalsTab student={student} readOnly />
    </div>
  );
}

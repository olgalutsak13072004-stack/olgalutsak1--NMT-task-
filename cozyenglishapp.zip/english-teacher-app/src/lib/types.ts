export type CEFRLevel = "A1" | "A2" | "B1" | "B2" | "C1" | "C2";

export type Mood = "happy" | "neutral" | "sad";

export type AttendanceStatus =
  | "present"
  | "late"
  | "absent"
  | "cancelled"
  | "rescheduled";

export type HomeworkStatus = "submitted" | "late" | "missing" | "pending";

export interface SkillScores {
  overall: number;
  grammar: number;
  vocabulary: number;
  listening: number;
  speaking: number;
  writing: number;
  reading: number;
  confidence: number;
  homework: number;
  attendance: number;
}

export interface ConfidenceLevels {
  speaking: number;
  grammar: number;
  vocabulary: number;
  pronunciation: number;
}

export interface CurrentCourse {
  name: string;
  unit: string;
  lesson: string;
  teacher: string;
}

export interface VocabularyItem {
  id: string;
  word: string;
  translation: string;
  dateLearned: string;
  revisionDates: string[];
  mastered: boolean;
  needsRevision: boolean;
  quizScore: number | null;
  exampleSentence: string;
  pronunciation: string;
  lessonId?: string;
}

export interface HomeworkItem {
  id: string;
  assignment: string;
  dueDate: string;
  submittedDate: string | null;
  status: HomeworkStatus;
  score: number | null;
  teacherCorrection: string;
  comments: string;
  lessonId?: string;
}

export interface AttendanceRecord {
  id: string;
  date: string;
  status: AttendanceStatus;
  lessonId?: string;
}

export interface LessonAssessment {
  participation: number;
  confidence: number;
  grammar: number;
  vocabulary: number;
  listening: number;
  speaking: number;
  homework: HomeworkStatus;
}

export interface LessonRecord {
  id: string;
  date: string;
  topic: string;
  homework: string;
  vocabularyLearned: string[];
  grammar: string;
  speakingTopic: string;
  listeningTopic: string;
  readingTopic: string;
  writingPractice: string;
  lessonNotes: string;
  teacherObservations: string;
  studentQuestions: string;
  mistakesToRevise: string[];
  homeworkCompletion: number;
  attendance: AttendanceStatus;
  durationMinutes: number;
  mood: Mood;
  assessment: LessonAssessment;
}

export interface LessonPlan {
  id: string;
  studentId: string;
  date: string;
  objectives: string;
  targetVocabulary: string;
  grammar: string;
  activities: string;
  games: string;
  homeworkPlan: string;
  expectedDifficulties: string;
  materials: string;
  homeworkReview: string;
  reflectionAfterLesson: string;
  thingsToRepeat: string;
  thingsMastered: string;
  status: "planned" | "completed";
  linkedLessonId?: string;
}

export type TestType =
  | "mid-course"
  | "unit"
  | "final"
  | "revision"
  | "mock-exam";

export interface TestRecord {
  id: string;
  title: string;
  type: TestType;
  date: string;
  score: number;
  maxScore: number;
  notes: string;
}

export interface LearningGoal {
  id: string;
  title: string;
  progress: number;
  deadline: string;
  milestones: { id: string; label: string; done: boolean }[];
}

export type AchievementKey =
  | "homework-hero"
  | "grammar-master"
  | "vocabulary-wizard"
  | "speaking-star"
  | "listening-expert"
  | "streak-30"
  | "perfect-attendance"
  | "unit-champion";

export interface Achievement {
  key: AchievementKey;
  label: string;
  emoji: string;
  dateEarned: string;
  description: string;
}

export interface FeedbackEntry {
  id: string;
  date: string;
  author: "teacher" | "student";
  text: string;
  lessonId?: string;
}

export interface NoteEntry {
  id: string;
  date: string;
  text: string;
}

export interface StudentNoteBundle {
  todaysAchievement: string;
  whatToPractise: string;
  homework: string;
  vocabulary: string;
  positiveFeedback: string;
  weeklyChallenge: string;
  monthlyGoal: string;
  updatedAt: string;
}

export interface TimelineEvent {
  id: string;
  date: string;
  type:
    | "first-lesson"
    | "achievement"
    | "unit-complete"
    | "test"
    | "certificate"
    | "feedback"
    | "goal"
    | "vocabulary-milestone";
  title: string;
  description?: string;
}

export type StudentStatus = "active" | "archived";

export interface Student {
  id: string;
  name: string;
  email: string;
  avatarEmoji: string;
  avatarColor: string;
  age: number;
  level: CEFRLevel;
  occupation: string;
  goals: string[];
  interests: string[];
  confidence: ConfidenceLevels;
  startDate: string;
  status: StudentStatus;
  birthday: string;
  course: CurrentCourse;
  scores: SkillScores;
  lessons: LessonRecord[];
  vocabulary: VocabularyItem[];
  homework: HomeworkItem[];
  attendance: AttendanceRecord[];
  tests: TestRecord[];
  learningGoals: LearningGoal[];
  achievements: Achievement[];
  feedback: FeedbackEntry[];
  teacherNotes: NoteEntry[];
  studentNotes: StudentNoteBundle;
  timeline: TimelineEvent[];
  lessonPlans: LessonPlan[];
}

export type UserRole = "teacher" | "student";

export interface AppUser {
  id: string;
  role: UserRole;
  name: string;
  email: string;
  studentId?: string;
}

"use client";

import { create } from "zustand";
import { persist } from "zustand/middleware";
import { AppUser } from "./types";
import { useStore } from "./store";

export const TEACHER_USER: AppUser = {
  id: "teacher-1",
  role: "teacher",
  name: "Olga Lutsak",
  email: "olgalutsak13072004@gmail.com",
};

interface AuthState {
  currentUserId: string | null;
  hasHydrated: boolean;
  setHasHydrated: (v: boolean) => void;
  login: (userId: string) => void;
  logout: () => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      currentUserId: null,
      hasHydrated: false,
      setHasHydrated: (v) => set({ hasHydrated: v }),
      login: (userId) => set({ currentUserId: userId }),
      logout: () => set({ currentUserId: null }),
    }),
    {
      name: "cozy-english-auth",
      version: 1,
      onRehydrateStorage: () => (state) => {
        state?.setHasHydrated(true);
      },
    }
  )
);

export function useAllUsers(): AppUser[] {
  const students = useStore((s) => s.students);
  return [
    TEACHER_USER,
    ...students.map(
      (s): AppUser => ({
        id: `student-user-${s.id}`,
        role: "student",
        name: s.name,
        email: s.email,
        studentId: s.id,
      })
    ),
  ];
}

export function useCurrentUser(): AppUser | null {
  const currentUserId = useAuthStore((s) => s.currentUserId);
  const users = useAllUsers();
  return users.find((u) => u.id === currentUserId) ?? null;
}

export function useLoggedInStudent() {
  const user = useCurrentUser();
  const students = useStore((s) => s.students);
  return students.find((st) => st.id === user?.studentId);
}

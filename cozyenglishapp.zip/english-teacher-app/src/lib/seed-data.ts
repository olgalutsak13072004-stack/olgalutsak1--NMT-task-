import {
  Student,
  LessonRecord,
  VocabularyItem,
  HomeworkItem,
  AttendanceRecord,
  TestRecord,
  LearningGoal,
  Achievement,
  FeedbackEntry,
  NoteEntry,
  TimelineEvent,
  LessonPlan,
  Mood,
  AttendanceStatus,
} from "./types";
import { computeScores } from "./scoring";

const DAY = 86400000;
const TODAY = new Date("2026-07-27T09:00:00Z").getTime();

function iso(offsetDays: number) {
  return new Date(TODAY + offsetDays * DAY).toISOString();
}

interface LessonSeed {
  topic: string;
  grammar: string;
  vocab: [string, string][];
  speaking: string;
  listening: string;
  reading: string;
  writing: string;
  notes: string;
  observations: string;
  questions: string;
  mistakes: string[];
  homework: string;
  homeworkCompletion: number;
  attendance: AttendanceStatus;
  duration: number;
  mood: Mood;
  stars: { participation: number; confidence: number; grammar: number; vocabulary: number; listening: number; speaking: number };
  hwStatus: "submitted" | "late" | "missing" | "pending";
}

function buildLessons(id: string, startOffsetWeeks: number, seeds: LessonSeed[]) {
  const lessons: LessonRecord[] = [];
  const vocabulary: VocabularyItem[] = [];
  const homework: HomeworkItem[] = [];
  const attendance: AttendanceRecord[] = [];

  seeds.forEach((s, i) => {
    const offsetDays = -((seeds.length - i) * 7) + startOffsetWeeks * 7;
    const date = iso(offsetDays);
    const lessonId = `${id}-lesson-${i + 1}`;
    lessons.push({
      id: lessonId,
      date,
      topic: s.topic,
      homework: s.homework,
      vocabularyLearned: s.vocab.map((v) => v[0]),
      grammar: s.grammar,
      speakingTopic: s.speaking,
      listeningTopic: s.listening,
      readingTopic: s.reading,
      writingPractice: s.writing,
      lessonNotes: s.notes,
      teacherObservations: s.observations,
      studentQuestions: s.questions,
      mistakesToRevise: s.mistakes,
      homeworkCompletion: s.homeworkCompletion,
      attendance: s.attendance,
      durationMinutes: s.duration,
      mood: s.mood,
      assessment: { ...s.stars, homework: s.hwStatus },
    });

    s.vocab.forEach(([word, translation], vi) => {
      vocabulary.push({
        id: `${lessonId}-vocab-${vi}`,
        word,
        translation,
        dateLearned: date,
        revisionDates: i < seeds.length - 2 ? [iso(offsetDays + 7)] : [],
        mastered: i < seeds.length - 2,
        needsRevision: i >= seeds.length - 2,
        quizScore: i < seeds.length - 2 ? 80 + ((vi * 7) % 20) : null,
        exampleSentence: `Example: "${word}" was used in context during our lesson on ${s.topic.toLowerCase()}.`,
        pronunciation: `/${word.toLowerCase()}/`,
        lessonId,
      });
    });

    if (s.attendance === "present" || s.attendance === "late") {
      homework.push({
        id: `${lessonId}-hw`,
        assignment: s.homework,
        dueDate: iso(offsetDays + 3),
        submittedDate: s.hwStatus === "submitted" ? iso(offsetDays + 2) : s.hwStatus === "late" ? iso(offsetDays + 5) : null,
        status: s.hwStatus,
        score: s.hwStatus === "submitted" ? 85 + ((i * 3) % 15) : s.hwStatus === "late" ? 65 : null,
        teacherCorrection: s.hwStatus !== "missing" ? "Good effort — a few small fixes noted in the margin." : "",
        comments: s.hwStatus === "missing" ? "Not submitted, please prioritise next week." : "Nicely done, keep it up!",
        lessonId,
      });
    }

    attendance.push({ id: `${lessonId}-att`, date, status: s.attendance, lessonId });
  });

  return { lessons, vocabulary, homework, attendance };
}

interface StudentConfig {
  id: string;
  name: string;
  email: string;
  avatarEmoji: string;
  avatarColor: string;
  age: number;
  level: Student["level"];
  occupation: string;
  goals: string[];
  interests: string[];
  confidence: Student["confidence"];
  startWeeksAgo: number;
  birthdayOffsetDays: number;
  course: Student["course"];
  lessonSeeds: LessonSeed[];
  tests: TestRecord[];
  learningGoals: LearningGoal[];
  achievementKeys: Achievement[];
  status?: Student["status"];
}

function buildStudent(cfg: StudentConfig): Student {
  const { lessons, vocabulary, homework, attendance } = buildLessons(cfg.id, 0, cfg.lessonSeeds);

  const feedback: FeedbackEntry[] = lessons.slice(-4).flatMap((l, idx) => [
    {
      id: `${l.id}-fb-t`,
      date: l.date,
      author: "teacher" as const,
      text: `Solid session on "${l.topic}". ${l.teacherObservations}`,
      lessonId: l.id,
    },
    {
      id: `${l.id}-fb-s`,
      date: l.date,
      author: "student" as const,
      text: idx % 2 === 0 ? "That was really helpful, I feel more confident now!" : "The vocabulary was a bit tricky but I'll practise more.",
      lessonId: l.id,
    },
  ]);

  const teacherNotes: NoteEntry[] = [
    { id: `${cfg.id}-tn-1`, date: iso(-3), text: "Responds really well to visual prompts — keep using image-based flashcards." },
    { id: `${cfg.id}-tn-2`, date: iso(-10), text: "Gets nervous with cold-call questions; give a few seconds of think-time." },
    { id: `${cfg.id}-tn-3`, date: iso(-20), text: "Loves talking about travel — great topic to unlock speaking fluency." },
  ];

  const timeline: TimelineEvent[] = [
    { id: `${cfg.id}-tl-1`, date: iso(-cfg.startWeeksAgo * 7), type: "first-lesson" as const, title: "First lesson together", description: `Started at level ${cfg.level}.` },
    ...cfg.tests.map((t) => ({ id: `${cfg.id}-tl-test-${t.id}`, date: t.date, type: "test" as const, title: `${t.title}`, description: `Scored ${t.score}/${t.maxScore}` })),
    ...cfg.achievementKeys.map((a) => ({ id: `${cfg.id}-tl-ach-${a.key}`, date: a.dateEarned, type: "achievement" as const, title: `${a.emoji} ${a.label}`, description: a.description })),
  ].sort((a, b) => a.date.localeCompare(b.date));

  const lessonPlans: LessonPlan[] = [
    {
      id: `${cfg.id}-plan-next`,
      studentId: cfg.id,
      date: iso(7),
      objectives: `Consolidate ${cfg.lessonSeeds[cfg.lessonSeeds.length - 1]?.grammar ?? "recent grammar"} and expand topic vocabulary.`,
      targetVocabulary: "5-8 new words related to upcoming unit",
      grammar: cfg.lessonSeeds[cfg.lessonSeeds.length - 1]?.grammar ?? "Review",
      activities: "Warm-up discussion, guided practice drill, role-play",
      games: "Vocabulary bingo, quick-fire Q&A",
      homeworkPlan: "Write a short paragraph using target grammar",
      expectedDifficulties: "May confuse tense forms under time pressure",
      materials: "Worksheet PDF, flashcard deck, audio clip",
      homeworkReview: "Review previous homework at the start of class",
      reflectionAfterLesson: "",
      thingsToRepeat: "",
      thingsMastered: "",
      status: "planned",
    },
  ];

  const partial: Omit<Student, "scores"> = {
    id: cfg.id,
    name: cfg.name,
    email: cfg.email,
    avatarEmoji: cfg.avatarEmoji,
    avatarColor: cfg.avatarColor,
    age: cfg.age,
    level: cfg.level,
    occupation: cfg.occupation,
    goals: cfg.goals,
    interests: cfg.interests,
    confidence: cfg.confidence,
    startDate: iso(-cfg.startWeeksAgo * 7),
    status: cfg.status ?? "active",
    birthday: iso(cfg.birthdayOffsetDays),
    course: cfg.course,
    lessons,
    vocabulary,
    homework,
    attendance,
    tests: cfg.tests,
    learningGoals: cfg.learningGoals,
    achievements: cfg.achievementKeys,
    feedback,
    teacherNotes,
    studentNotes: {
      todaysAchievement: `Used ${cfg.lessonSeeds[cfg.lessonSeeds.length - 1]?.grammar ?? "new grammar"} correctly in conversation!`,
      whatToPractise: "Listening for weak forms and contractions in natural speech",
      homework: lessons[lessons.length - 1]?.homework ?? "",
      vocabulary: lessons[lessons.length - 1]?.vocabularyLearned.join(", ") ?? "",
      positiveFeedback: "Your confidence in speaking has really grown this month — keep going!",
      weeklyChallenge: "Use 5 new words in a short voice message",
      monthlyGoal: cfg.learningGoals[0]?.title ?? "Keep building fluency",
      updatedAt: iso(-1),
    },
    timeline,
    lessonPlans,
  };

  const scores = computeScores(partial);
  return { ...partial, scores };
}

const students: Student[] = [
  buildStudent({
    id: "s1",
    name: "Elena Marchetti",
    email: "elena.m@example.com",
    avatarEmoji: "🌿",
    avatarColor: "sage",
    age: 27,
    level: "B2",
    occupation: "UX Designer",
    goals: ["Reach C1", "Speak confidently in meetings", "Pass Cambridge Advanced"],
    interests: ["Design", "Travel", "Podcasts"],
    confidence: { speaking: 68, grammar: 74, vocabulary: 80, pronunciation: 65 },
    startWeeksAgo: 20,
    birthdayOffsetDays: 12,
    course: { name: "Business English Fluency", unit: "Unit 6: Negotiations", lesson: "Lesson 24", teacher: "Ms. Olga" },
    lessonSeeds: [
      { topic: "Negotiation language", grammar: "Conditionals (2nd)", vocab: [["leverage", "перевага"], ["concession", "поступка"]], speaking: "Role-play: salary negotiation", listening: "Podcast — business deals", reading: "Article on negotiation tactics", writing: "Email proposing terms", notes: "Great energy today, led the roleplay confidently.", observations: "Still hesitates before complex conditionals.", questions: "When do we use 'would have' vs 'would'?", mistakes: ["Conditionals"], homework: "Write a negotiation email (150 words)", homeworkCompletion: 90, attendance: "present", duration: 60, mood: "happy", stars: { participation: 5, confidence: 4, grammar: 3, vocabulary: 5, listening: 4, speaking: 4 }, hwStatus: "submitted" },
      { topic: "Meetings & agendas", grammar: "Modal verbs of obligation", vocab: [["agenda item", "пункт порядку денного"], ["follow up", "продовжити"]], speaking: "Chairing a mock meeting", listening: "Meeting recording excerpt", reading: "Sample meeting minutes", writing: "Draft meeting minutes", notes: "Handled modal verbs well.", observations: "Vocabulary retention excellent this week.", questions: "Difference between 'must' and 'have to'?", mistakes: [], homework: "Summarize a meeting in 5 bullet points", homeworkCompletion: 100, attendance: "present", duration: 60, mood: "happy", stars: { participation: 5, confidence: 4, grammar: 4, vocabulary: 5, listening: 5, speaking: 4 }, hwStatus: "submitted" },
      { topic: "Conditionals deep dive", grammar: "Mixed conditionals", vocab: [["provided that", "за умови що"], ["unless", "якщо не"]], speaking: "Discuss hypothetical business scenarios", listening: "TED talk clip", reading: "Case study", writing: "Hypothetical scenario paragraph", notes: "Struggled a bit with mixed conditionals but improving.", observations: "Needs more drilling on 3rd conditional.", questions: "How to combine past and present conditionals?", mistakes: ["Conditionals", "Conditionals"], homework: "10 conditional sentences about work", homeworkCompletion: 70, attendance: "late", duration: 55, mood: "neutral", stars: { participation: 4, confidence: 3, grammar: 3, vocabulary: 4, listening: 4, speaking: 3 }, hwStatus: "late" },
      { topic: "Persuasive language", grammar: "Emphatic structures", vocab: [["compelling", "переконливий"], ["to sway", "переконати"]], speaking: "Pitch a business idea", listening: "Shark Tank pitch clip", reading: "Persuasive essay", writing: "Elevator pitch script", notes: "Fantastic pitch — very persuasive!", observations: "Confidence visibly up since last month.", questions: "None today.", mistakes: [], homework: "Record a 1-minute pitch", homeworkCompletion: 95, attendance: "present", duration: 60, mood: "happy", stars: { participation: 5, confidence: 5, grammar: 4, vocabulary: 5, listening: 4, speaking: 5 }, hwStatus: "submitted" },
      { topic: "Cross-cultural communication", grammar: "Reported speech", vocab: [["nuance", "нюанс"], ["rapport", "взаєморозуміння"]], speaking: "Discuss cultural differences at work", listening: "Interview about global teams", reading: "Article on cultural intelligence", writing: "Reflection paragraph", notes: "Insightful discussion, asked great questions.", observations: "Reported speech mostly accurate.", questions: "How formal should reported speech be in emails?", mistakes: ["Reported speech"], homework: "Rewrite 5 quotes as reported speech", homeworkCompletion: 85, attendance: "present", duration: 60, mood: "happy", stars: { participation: 5, confidence: 4, grammar: 4, vocabulary: 5, listening: 5, speaking: 4 }, hwStatus: "submitted" },
      { topic: "Negotiation review & mock exam prep", grammar: "Conditionals + modals review", vocab: [["trade-off", "компроміс"], ["win-win", "взаємовигідний"]], speaking: "Full negotiation simulation", listening: "CAE-style listening practice", reading: "CAE reading passage", writing: "Formal proposal", notes: "Ready for the unit test — strong performance.", observations: "Very few grammar slips this session.", questions: "What's the format of the unit test?", mistakes: [], homework: "Review unit 6 vocabulary list", homeworkCompletion: 100, attendance: "present", duration: 60, mood: "happy", stars: { participation: 5, confidence: 5, grammar: 5, vocabulary: 5, listening: 5, speaking: 5 }, hwStatus: "submitted" },
    ],
    tests: [
      { id: "s1-test-1", title: "Unit 4 Test", type: "unit", date: iso(-70), score: 78, maxScore: 100, notes: "Solid grasp of modals." },
      { id: "s1-test-2", title: "Mid-Course Assessment", type: "mid-course", date: iso(-35), score: 84, maxScore: 100, notes: "Great overall improvement." },
      { id: "s1-test-3", title: "CAE Mock Exam", type: "mock-exam", date: iso(-7), score: 88, maxScore: 100, notes: "Ready for the real exam soon." },
    ],
    learningGoals: [
      { id: "s1-goal-1", title: "Reach C1", progress: 72, deadline: iso(120), milestones: [{ id: "m1", label: "Pass mid-course assessment", done: true }, { id: "m2", label: "Score 85%+ on mock exam", done: true }, { id: "m3", label: "Pass Cambridge Advanced", done: false }] },
      { id: "s1-goal-2", title: "Speak confidently in meetings", progress: 80, deadline: iso(60), milestones: [{ id: "m4", label: "Lead a mock meeting", done: true }, { id: "m5", label: "Deliver a 5-min pitch unscripted", done: false }] },
    ],
    achievementKeys: [
      { key: "vocabulary-wizard", label: "Vocabulary Wizard", emoji: "📚", dateEarned: iso(-40), description: "Mastered 100+ words" },
      { key: "speaking-star", label: "Speaking Star", emoji: "🎤", dateEarned: iso(-14), description: "Outstanding speaking performance" },
      { key: "homework-hero", label: "Homework Hero", emoji: "🏆", dateEarned: iso(-7), description: "10 homeworks in a row on time" },
    ],
  }),

  buildStudent({
    id: "s2",
    name: "Kenji Watanabe",
    email: "kenji.w@example.com",
    avatarEmoji: "🍁",
    avatarColor: "dusty",
    age: 34,
    level: "B1",
    occupation: "Software Engineer",
    goals: ["Improve listening", "Learn 1000 words", "Reach B2"],
    interests: ["Technology", "Gaming", "Hiking"],
    confidence: { speaking: 50, grammar: 60, vocabulary: 62, pronunciation: 48 },
    startWeeksAgo: 14,
    birthdayOffsetDays: -40,
    course: { name: "General English Progress", unit: "Unit 3: Daily Life", lesson: "Lesson 16", teacher: "Ms. Olga" },
    lessonSeeds: [
      { topic: "Daily routines", grammar: "Present simple vs continuous", vocab: [["commute", "їздити на роботу"], ["routine", "рутина"]], speaking: "Describe a typical day", listening: "Podcast about remote work", reading: "Blog post about productivity", writing: "Diary entry", notes: "Good vocabulary use, some tense confusion.", observations: "Mixes up simple/continuous under pressure.", questions: "Why 'I am working' not 'I work' here?", mistakes: ["Present simple vs continuous"], homework: "Write your daily routine (100 words)", homeworkCompletion: 60, attendance: "present", duration: 45, mood: "neutral", stars: { participation: 4, confidence: 3, grammar: 3, vocabulary: 4, listening: 3, speaking: 3 }, hwStatus: "late" },
      { topic: "Free time & hobbies", grammar: "Present simple vs continuous review", vocab: [["leisure", "дозвілля"], ["unwind", "розслаблятися"]], speaking: "Talk about weekend plans", listening: "Short interview clip", reading: "Magazine article", writing: "Short paragraph about hobbies", notes: "More comfortable this week.", observations: "Listening comprehension improving steadily.", questions: "None.", mistakes: [], homework: "Vocabulary quiz — hobbies", homeworkCompletion: 100, attendance: "present", duration: 50, mood: "happy", stars: { participation: 4, confidence: 4, grammar: 4, vocabulary: 4, listening: 4, speaking: 3 }, hwStatus: "submitted" },
      { topic: "Technology at work", grammar: "Present perfect", vocab: [["deploy", "розгортати"], ["troubleshoot", "усувати несправності"]], speaking: "Explain a tech problem you solved", listening: "Tech news clip", reading: "Article about AI tools", writing: "Short explanation of a tool", notes: "Struggled with present perfect vs past simple.", observations: "Needs more present perfect practice.", questions: "'I have finished' vs 'I finished' — when?", mistakes: ["Present perfect"], homework: "10 present perfect sentences", homeworkCompletion: 50, attendance: "absent", duration: 0, mood: "sad", stars: { participation: 2, confidence: 2, grammar: 2, vocabulary: 3, listening: 2, speaking: 2 }, hwStatus: "missing" },
      { topic: "Present perfect catch-up", grammar: "Present perfect", vocab: [["accomplish", "досягати"], ["so far", "поки що"]], speaking: "Talk about accomplishments", listening: "Audio dialogue", reading: "Short story excerpt", writing: "List of accomplishments", notes: "Made up missed content well.", observations: "Grammar clicking now.", questions: "Difference between 'already' and 'yet'?", mistakes: ["Present perfect"], homework: "Rewrite sentences using present perfect", homeworkCompletion: 80, attendance: "present", duration: 45, mood: "neutral", stars: { participation: 4, confidence: 3, grammar: 3, vocabulary: 3, listening: 3, speaking: 3 }, hwStatus: "submitted" },
      { topic: "Listening intensive", grammar: "Review", vocab: [["subtitle", "субтитри"], ["accent", "акцент"]], speaking: "Discuss a podcast episode", listening: "Extended listening practice", reading: "Listening transcript", writing: "Summary of podcast", notes: "Listening skills clearly stronger.", observations: "Big jump in listening confidence.", questions: "How to catch fast speech?", mistakes: [], homework: "Listen & summarize a 5-min podcast", homeworkCompletion: 90, attendance: "present", duration: 50, mood: "happy", stars: { participation: 4, confidence: 4, grammar: 3, vocabulary: 4, listening: 5, speaking: 3 }, hwStatus: "submitted" },
    ],
    tests: [
      { id: "s2-test-1", title: "Unit 2 Test", type: "unit", date: iso(-50), score: 62, maxScore: 100, notes: "Needs grammar reinforcement." },
      { id: "s2-test-2", title: "Revision Test: Tenses", type: "revision", date: iso(-14), score: 71, maxScore: 100, notes: "Improving steadily." },
    ],
    learningGoals: [
      { id: "s2-goal-1", title: "Learn 1000 words", progress: 45, deadline: iso(150), milestones: [{ id: "m1", label: "500 words logged", done: true }, { id: "m2", label: "750 words logged", done: false }] },
      { id: "s2-goal-2", title: "Improve listening", progress: 60, deadline: iso(60), milestones: [{ id: "m3", label: "Complete 10 listening sessions", done: true }, { id: "m4", label: "Understand native-speed podcasts", done: false }] },
    ],
    achievementKeys: [
      { key: "listening-expert", label: "Listening Expert", emoji: "🎧", dateEarned: iso(-3), description: "Big improvement in listening" },
    ],
  }),

  buildStudent({
    id: "s3",
    name: "Sofia Ramirez",
    email: "sofia.r@example.com",
    avatarEmoji: "🌸",
    avatarColor: "coral",
    age: 19,
    level: "A2",
    occupation: "University Student",
    goals: ["Reach B1", "Pass IELTS", "Speak confidently"],
    interests: ["Music", "Movies", "Fashion"],
    confidence: { speaking: 40, grammar: 45, vocabulary: 50, pronunciation: 38 },
    startWeeksAgo: 8,
    birthdayOffsetDays: 25,
    course: { name: "Foundations of English", unit: "Unit 2: People & Places", lesson: "Lesson 9", teacher: "Ms. Olga" },
    lessonSeeds: [
      { topic: "Describing people", grammar: "Adjective order", vocab: [["outgoing", "товариський"], ["curly", "кучерявий"]], speaking: "Describe a family member", listening: "Simple dialogue", reading: "Short bio", writing: "Describe your best friend", notes: "Nervous at first, warmed up quickly.", observations: "Needs confidence-building activities.", questions: "Which adjective comes first?", mistakes: ["Adjective order"], homework: "Describe 3 people (short sentences)", homeworkCompletion: 70, attendance: "present", duration: 40, mood: "neutral", stars: { participation: 3, confidence: 2, grammar: 2, vocabulary: 3, listening: 3, speaking: 2 }, hwStatus: "submitted" },
      { topic: "My city", grammar: "There is / there are", vocab: [["neighbourhood", "район"], ["landmark", "пам'ятка"]], speaking: "Describe your hometown", listening: "Tourist guide audio", reading: "City guide excerpt", writing: "Postcard about your city", notes: "Enjoyed talking about home.", observations: "Good pronunciation improvement.", questions: "None.", mistakes: [], homework: "Write a postcard (80 words)", homeworkCompletion: 100, attendance: "present", duration: 40, mood: "happy", stars: { participation: 4, confidence: 3, grammar: 3, vocabulary: 3, listening: 3, speaking: 3 }, hwStatus: "submitted" },
      { topic: "Basic grammar review", grammar: "Adjective order review", vocab: [["cosy", "затишний"], ["spacious", "просторий"]], speaking: "Describe your room", listening: "Short audio description", reading: "Interior design blurb", writing: "Describe your dream room", notes: "Cancelled due to illness.", observations: "", questions: "", mistakes: [], homework: "", homeworkCompletion: 0, attendance: "cancelled", duration: 0, mood: "neutral", stars: { participation: 0, confidence: 0, grammar: 0, vocabulary: 0, listening: 0, speaking: 0 }, hwStatus: "pending" },
      { topic: "Basic grammar review (rescheduled)", grammar: "Adjective order review", vocab: [["cosy", "затишний"], ["spacious", "просторий"]], speaking: "Describe your room", listening: "Short audio description", reading: "Interior design blurb", writing: "Describe your dream room", notes: "Caught up well after missing a session.", observations: "Adjective order much better now.", questions: "Can I use two adjectives together?", mistakes: [], homework: "Describe your dream room (80 words)", homeworkCompletion: 85, attendance: "present", duration: 45, mood: "happy", stars: { participation: 4, confidence: 3, grammar: 3, vocabulary: 4, listening: 3, speaking: 3 }, hwStatus: "submitted" },
    ],
    tests: [
      { id: "s3-test-1", title: "Unit 1 Test", type: "unit", date: iso(-40), score: 58, maxScore: 100, notes: "Good first attempt, keep practising." },
    ],
    learningGoals: [
      { id: "s3-goal-1", title: "Reach B1", progress: 35, deadline: iso(180), milestones: [{ id: "m1", label: "Complete Unit 2", done: true }, { id: "m2", label: "Complete Unit 3", done: false }] },
    ],
    achievementKeys: [],
  }),

  buildStudent({
    id: "s4",
    name: "Lucas Bergström",
    email: "lucas.b@example.com",
    avatarEmoji: "🧭",
    avatarColor: "sage",
    age: 41,
    level: "C1",
    occupation: "Product Manager",
    goals: ["Reach C2", "Pass IELTS with 8.0+", "Improve writing precision"],
    interests: ["Economics", "Chess", "Sailing"],
    confidence: { speaking: 85, grammar: 88, vocabulary: 90, pronunciation: 80 },
    startWeeksAgo: 30,
    birthdayOffsetDays: 5,
    course: { name: "Advanced Fluency & Exam Prep", unit: "Unit 9: Academic Writing", lesson: "Lesson 34", teacher: "Ms. Olga" },
    lessonSeeds: [
      { topic: "Academic essay structure", grammar: "Cohesive devices", vocab: [["notwithstanding", "незважаючи на"], ["albeit", "хоча"]], speaking: "Debate: technology & society", listening: "Academic lecture excerpt", reading: "Journal article", writing: "Argumentative essay outline", notes: "Exceptional command of complex structures.", observations: "Very few errors, refining nuance now.", questions: "Is 'notwithstanding' too formal for IELTS?", mistakes: [], homework: "Write a 250-word argumentative essay", homeworkCompletion: 100, attendance: "present", duration: 60, mood: "happy", stars: { participation: 5, confidence: 5, grammar: 5, vocabulary: 5, listening: 5, speaking: 5 }, hwStatus: "submitted" },
      { topic: "IELTS Writing Task 2 practice", grammar: "Complex sentence variety", vocab: [["a caveat", "застереження"], ["to underscore", "підкреслити"]], speaking: "Discuss essay topics", listening: "IELTS listening practice", reading: "IELTS reading passage", writing: "Full Task 2 essay under time", notes: "Wrote a band-8 quality essay.", observations: "Time management excellent.", questions: "How strict are examiners on paragraph length?", mistakes: [], homework: "Review essay feedback and redraft conclusion", homeworkCompletion: 95, attendance: "present", duration: 60, mood: "happy", stars: { participation: 5, confidence: 5, grammar: 5, vocabulary: 5, listening: 4, speaking: 5 }, hwStatus: "submitted" },
      { topic: "Nuanced vocabulary & idioms", grammar: "Inversion structures", vocab: [["seldom", "рідко"], ["scarcely", "навряд чи"]], speaking: "Use idioms in debate", listening: "Panel discussion clip", reading: "Opinion piece", writing: "Rewrite sentences with inversion", notes: "Loves idiomatic challenges.", observations: "Inversion structures near-native.", questions: "None today.", mistakes: [], homework: "Write 5 sentences using inversion", homeworkCompletion: 100, attendance: "present", duration: 60, mood: "happy", stars: { participation: 5, confidence: 5, grammar: 5, vocabulary: 5, listening: 5, speaking: 5 }, hwStatus: "submitted" },
      { topic: "Mock IELTS exam", grammar: "Full review", vocab: [["a nuanced take", "нюансований погляд"], ["to concede", "визнати"]], speaking: "Full IELTS speaking mock", listening: "Full IELTS listening mock", reading: "Full IELTS reading mock", writing: "Full IELTS writing mock", notes: "Outstanding mock performance.", observations: "On track for 8.0+.", questions: "When should I book the real exam?", mistakes: [], homework: "Review mock exam results", homeworkCompletion: 100, attendance: "present", duration: 90, mood: "happy", stars: { participation: 5, confidence: 5, grammar: 5, vocabulary: 5, listening: 5, speaking: 5 }, hwStatus: "submitted" },
    ],
    tests: [
      { id: "s4-test-1", title: "IELTS Mock Exam #1", type: "mock-exam", date: iso(-45), score: 91, maxScore: 100, notes: "Equivalent to band 7.5" },
      { id: "s4-test-2", title: "IELTS Mock Exam #2", type: "mock-exam", date: iso(-10), score: 95, maxScore: 100, notes: "Equivalent to band 8.0" },
    ],
    learningGoals: [
      { id: "s4-goal-1", title: "Pass IELTS with 8.0+", progress: 92, deadline: iso(30), milestones: [{ id: "m1", label: "Score 7.5+ on mock", done: true }, { id: "m2", label: "Score 8.0+ on mock", done: true }, { id: "m3", label: "Sit real exam", done: false }] },
    ],
    achievementKeys: [
      { key: "grammar-master", label: "Grammar Master", emoji: "⭐", dateEarned: iso(-60), description: "Near-perfect grammar accuracy" },
      { key: "unit-champion", label: "Unit Champion", emoji: "🥇", dateEarned: iso(-20), description: "Top score in unit test" },
      { key: "perfect-attendance", label: "Perfect Attendance", emoji: "💯", dateEarned: iso(-5), description: "100% attendance streak" },
      { key: "streak-30", label: "30-day Streak", emoji: "🔥", dateEarned: iso(-2), description: "30 consecutive active days" },
    ],
  }),

  buildStudent({
    id: "s5",
    name: "Amara Okafor",
    email: "amara.o@example.com",
    avatarEmoji: "🎨",
    avatarColor: "dusty",
    age: 23,
    level: "B1",
    occupation: "Graphic Designer",
    goals: ["Reach B2", "Improve writing", "Speak confidently"],
    interests: ["Art", "Photography", "Coffee culture"],
    confidence: { speaking: 58, grammar: 55, vocabulary: 66, pronunciation: 60 },
    startWeeksAgo: 10,
    birthdayOffsetDays: -8,
    course: { name: "General English Progress", unit: "Unit 4: Work & Career", lesson: "Lesson 12", teacher: "Ms. Olga" },
    lessonSeeds: [
      { topic: "Talking about your job", grammar: "Present simple + adverbs of frequency", vocab: [["deadline", "дедлайн"], ["freelance", "фріланс"]], speaking: "Describe your job", listening: "Interview with a designer", reading: "Career blog post", writing: "Job description paragraph", notes: "Enthusiastic about the topic.", observations: "Good vocabulary recall.", questions: "How often do we use 'usually' vs 'often'?", mistakes: [], homework: "Write about your ideal job", homeworkCompletion: 90, attendance: "present", duration: 45, mood: "happy", stars: { participation: 4, confidence: 3, grammar: 3, vocabulary: 4, listening: 4, speaking: 3 }, hwStatus: "submitted" },
      { topic: "Job interviews", grammar: "Question formation", vocab: [["strength", "сильна сторона"], ["weakness", "слабка сторона"]], speaking: "Mock job interview", listening: "Interview tips podcast", reading: "Interview Q&A article", writing: "Answers to common interview questions", notes: "A bit shy during roleplay but improved.", observations: "Question formation needs practice.", questions: "How to form indirect questions?", mistakes: ["Question formation"], homework: "Write 5 interview questions", homeworkCompletion: 60, attendance: "late", duration: 40, mood: "neutral", stars: { participation: 3, confidence: 2, grammar: 2, vocabulary: 3, listening: 3, speaking: 2 }, hwStatus: "late" },
      { topic: "Writing focus: emails", grammar: "Formal vs informal register", vocab: [["kindly", "люб'язно"], ["regarding", "щодо"]], speaking: "Discuss email etiquette", listening: "Workplace dialogue", reading: "Sample formal email", writing: "Write a formal email request", notes: "Big improvement in written formality.", observations: "Writing more structured than before.", questions: "When is 'Dear' too formal?", mistakes: [], homework: "Write a formal email (100 words)", homeworkCompletion: 100, attendance: "present", duration: 45, mood: "happy", stars: { participation: 4, confidence: 4, grammar: 4, vocabulary: 4, listening: 3, speaking: 3 }, hwStatus: "submitted" },
    ],
    tests: [
      { id: "s5-test-1", title: "Unit 3 Test", type: "unit", date: iso(-30), score: 69, maxScore: 100, notes: "Writing needs more structure." },
    ],
    learningGoals: [
      { id: "s5-goal-1", title: "Improve writing", progress: 55, deadline: iso(90), milestones: [{ id: "m1", label: "Master formal register", done: true }, { id: "m2", label: "Write a full report", done: false }] },
    ],
    achievementKeys: [],
  }),

  buildStudent({
    id: "s6",
    name: "Noah Fischer",
    email: "noah.f@example.com",
    avatarEmoji: "⚡",
    avatarColor: "coral",
    age: 16,
    level: "A2",
    occupation: "High School Student",
    goals: ["Reach B1", "Improve grammar", "Build vocabulary"],
    interests: ["Football", "Video games", "YouTube"],
    confidence: { speaking: 45, grammar: 40, vocabulary: 52, pronunciation: 44 },
    startWeeksAgo: 6,
    birthdayOffsetDays: 45,
    course: { name: "Foundations of English", unit: "Unit 1: Introductions", lesson: "Lesson 5", teacher: "Ms. Olga" },
    status: "archived",
    lessonSeeds: [
      { topic: "Talking about hobbies", grammar: "Simple present", vocab: [["score a goal", "забити гол"], ["stream", "стрімити"]], speaking: "Talk about favourite game/sport", listening: "Sports commentary clip", reading: "Short article about esports", writing: "Paragraph about a hobby", notes: "Very engaged when talking about football.", observations: "Loves gamified activities.", questions: "How to say 'I'm into...' correctly?", mistakes: [], homework: "Write about your favourite hobby", homeworkCompletion: 80, attendance: "present", duration: 40, mood: "happy", stars: { participation: 4, confidence: 3, grammar: 2, vocabulary: 3, listening: 3, speaking: 3 }, hwStatus: "submitted" },
      { topic: "School life", grammar: "Simple present negative/question", vocab: [["timetable", "розклад"], ["assignment", "завдання"]], speaking: "Describe your school day", listening: "Dialogue about school", reading: "School blog post", writing: "My school day paragraph", notes: "Paused lessons for the summer break.", observations: "Good progress before pause.", questions: "None.", mistakes: ["Question formation"], homework: "Describe your school schedule", homeworkCompletion: 50, attendance: "present", duration: 40, mood: "neutral", stars: { participation: 3, confidence: 2, grammar: 2, vocabulary: 3, listening: 2, speaking: 2 }, hwStatus: "late" },
    ],
    tests: [],
    learningGoals: [
      { id: "s6-goal-1", title: "Reach B1", progress: 20, deadline: iso(200), milestones: [{ id: "m1", label: "Complete Unit 1", done: true }] },
    ],
    achievementKeys: [],
  }),
];

export const seedStudents = students;

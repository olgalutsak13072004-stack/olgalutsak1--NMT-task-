import { Student, SkillScores, AttendanceStatus, HomeworkStatus } from "./types";
import { average, clamp } from "./utils";

const ATTENDANCE_WEIGHT: Record<AttendanceStatus, number | null> = {
  present: 100,
  late: 75,
  absent: 0,
  cancelled: null,
  rescheduled: null,
};

const HOMEWORK_WEIGHT: Record<HomeworkStatus, number | null> = {
  submitted: 100,
  late: 60,
  missing: 0,
  pending: null,
};

function hashBias(id: string, spread = 8) {
  let h = 0;
  for (let i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) % 1000;
  return (h % (spread * 2)) - spread;
}

/**
 * Derives every score in SkillScores purely from logged activity
 * (attendance, homework, lesson assessments, tests) so progress always
 * reflects what has actually been recorded for a student.
 */
export function computeScores(student: Pick<Student, "id" | "attendance" | "homework" | "lessons" | "tests" | "confidence">): SkillScores {
  const attendanceVals = student.attendance
    .map((a) => ATTENDANCE_WEIGHT[a.status])
    .filter((v): v is number => v !== null);
  const attendance = attendanceVals.length ? average(attendanceVals) : 100;

  const homeworkFromLog = student.homework
    .map((h) => HOMEWORK_WEIGHT[h.status])
    .filter((v): v is number => v !== null);
  const homeworkFromScores = student.homework
    .filter((h) => h.score !== null)
    .map((h) => h.score as number);
  const homework = homeworkFromLog.length || homeworkFromScores.length
    ? average([...homeworkFromLog, ...homeworkFromScores])
    : 100;

  const assessments = student.lessons.map((l) => l.assessment);
  const grammarFromLessons = assessments.map((a) => a.grammar * 20);
  const vocabFromLessons = assessments.map((a) => a.vocabulary * 20);
  const listeningFromLessons = assessments.map((a) => a.listening * 20);
  const speakingFromLessons = assessments.map((a) => a.speaking * 20);
  const confidenceFromLessons = assessments.map((a) => a.confidence * 20);

  const testAvg = student.tests.length
    ? average(student.tests.map((t) => Math.round((t.score / t.maxScore) * 100)))
    : null;

  const grammar = clamp(Math.round(
    grammarFromLessons.length
      ? average(grammarFromLessons) * 0.75 + (testAvg ?? average(grammarFromLessons)) * 0.25
      : 60
  ));
  const vocabulary = clamp(Math.round(
    vocabFromLessons.length
      ? average(vocabFromLessons) * 0.75 + (testAvg ?? average(vocabFromLessons)) * 0.25
      : 60
  ));
  const listening = clamp(listeningFromLessons.length ? average(listeningFromLessons) : 60);
  const speaking = clamp(speakingFromLessons.length ? average(speakingFromLessons) : 60);

  const bias = hashBias(student.id);
  const reading = clamp(Math.round(average([grammar, vocabulary]) * 0.6 + average([listening, speaking]) * 0.2 + homework * 0.2 + bias));
  const writing = clamp(Math.round(average([grammar, vocabulary]) * 0.65 + homework * 0.15 + (testAvg ?? 70) * 0.2 - bias * 0.5));

  const selfConfidence = average([
    student.confidence.speaking,
    student.confidence.grammar,
    student.confidence.vocabulary,
    student.confidence.pronunciation,
  ]);
  const confidence = clamp(Math.round(
    confidenceFromLessons.length
      ? average(confidenceFromLessons) * 0.6 + selfConfidence * 0.4
      : selfConfidence
  ));

  const overall = clamp(Math.round(
    average([grammar, vocabulary, listening, speaking, writing, reading, confidence, homework, attendance])
  ));

  return {
    overall,
    grammar,
    vocabulary,
    listening,
    speaking,
    writing,
    reading,
    confidence,
    homework: Math.round(homework),
    attendance: Math.round(attendance),
  };
}

export interface ScoreSnapshot extends SkillScores {
  date: string;
}

/**
 * Replays a student's history lesson-by-lesson to produce a growth curve —
 * every point is computeScores() run against only the data logged up to
 * that date, so charts reflect genuinely observed progress over time.
 */
export function computeScoreTimeline(student: Pick<Student, "id" | "attendance" | "homework" | "lessons" | "tests" | "confidence">): ScoreSnapshot[] {
  const sortedLessons = [...student.lessons].sort((a, b) => a.date.localeCompare(b.date));
  return sortedLessons.map((lesson, i) => {
    const cutoff = lesson.date;
    const subset = {
      id: student.id,
      confidence: student.confidence,
      lessons: sortedLessons.slice(0, i + 1),
      attendance: student.attendance.filter((a) => a.date <= cutoff),
      homework: student.homework.filter((h) => h.dueDate <= cutoff),
      tests: student.tests.filter((t) => t.date <= cutoff),
    };
    return { date: cutoff, ...computeScores(subset) };
  });
}

export function weakestSkills(scores: SkillScores, n = 2): string[] {
  const entries = Object.entries(scores).filter(([k]) => k !== "overall") as [string, number][];
  return entries.sort((a, b) => a[1] - b[1]).slice(0, n).map(([k]) => k);
}

export function strongestSkills(scores: SkillScores, n = 2): string[] {
  const entries = Object.entries(scores).filter(([k]) => k !== "overall") as [string, number][];
  return entries.sort((a, b) => b[1] - a[1]).slice(0, n).map(([k]) => k);
}

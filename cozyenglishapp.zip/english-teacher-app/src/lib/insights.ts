import { Student } from "./types";
import { average, nextCEFR } from "./utils";
import { weakestSkills, strongestSkills } from "./scoring";

const SKILL_LABEL: Record<string, string> = {
  grammar: "Grammar",
  vocabulary: "Vocabulary",
  listening: "Listening",
  speaking: "Speaking",
  writing: "Writing",
  reading: "Reading",
  confidence: "Confidence",
  homework: "Homework",
  attendance: "Attendance",
};

export interface Insight {
  id: string;
  text: string;
  tone: "positive" | "neutral" | "warning";
}

function trendFor(student: Student, key: "grammar" | "vocabulary" | "listening" | "speaking") {
  const sorted = [...student.lessons].sort((a, b) => a.date.localeCompare(b.date));
  if (sorted.length < 4) return null;
  const mid = Math.floor(sorted.length / 2);
  const earlier = average(sorted.slice(0, mid).map((l) => l.assessment[key] * 20));
  const recent = average(sorted.slice(mid).map((l) => l.assessment[key] * 20));
  return { earlier, recent, delta: recent - earlier };
}

function mostCommonMistakeTopic(student: Student): string | null {
  const counts = new Map<string, number>();
  for (const l of student.lessons) {
    for (const m of l.mistakesToRevise) {
      const key = m.trim();
      if (!key) continue;
      counts.set(key, (counts.get(key) ?? 0) + 1);
    }
  }
  let top: string | null = null;
  let topCount = 0;
  for (const [k, c] of counts) {
    if (c > topCount) {
      top = k;
      topCount = c;
    }
  }
  return topCount >= 2 ? top : null;
}

export function generateInsights(student: Student): Insight[] {
  const insights: Insight[] = [];

  (["speaking", "listening", "grammar", "vocabulary"] as const).forEach((key) => {
    const t = trendFor(student, key);
    if (!t) return;
    if (Math.abs(t.delta) < 4) return;
    const pct = Math.abs(Math.round(t.delta));
    if (t.delta > 0) {
      insights.push({
        id: `trend-${key}`,
        text: `${SKILL_LABEL[key]} has improved by ${pct}% over recent lessons.`,
        tone: "positive",
      });
    } else {
      insights.push({
        id: `trend-${key}`,
        text: `${SKILL_LABEL[key]} has decreased slightly (${pct}%) — worth a check-in.`,
        tone: "warning",
      });
    }
  });

  const mastered = student.vocabulary.filter((v) => v.mastered).length;
  const total = student.vocabulary.length;
  if (total > 0) {
    const pct = Math.round((mastered / total) * 100);
    if (pct >= 75) {
      insights.push({ id: "vocab-retention", text: `Vocabulary retention is excellent — ${pct}% of learned words are mastered.`, tone: "positive" });
    } else if (pct < 45) {
      insights.push({ id: "vocab-retention", text: `Vocabulary retention needs attention — only ${pct}% of words are mastered yet.`, tone: "warning" });
    }
  }

  const topMistake = mostCommonMistakeTopic(student);
  if (topMistake) {
    insights.push({ id: "mistake-topic", text: `Grammar errors mostly occur in ${topMistake}. Recommend a focused revision session.`, tone: "warning" });
  }

  const weak = weakestSkills(student.scores, 1)[0];
  const strong = strongestSkills(student.scores, 1)[0];
  if (weak) insights.push({ id: "weakest", text: `Weakest skill right now: ${SKILL_LABEL[weak]} (${student.scores[weak as keyof typeof student.scores]}%). Consider prioritising it next lesson.`, tone: "neutral" });
  if (strong) insights.push({ id: "strongest", text: `Strongest skill: ${SKILL_LABEL[strong]} (${student.scores[strong as keyof typeof student.scores]}%). Great foundation to build on.`, tone: "positive" });

  const next = nextCEFR(student.level);
  if (next && student.scores.overall >= 80) {
    insights.push({ id: "cefr", text: `At the current pace, ${student.name.split(" ")[0]} is on track to reach ${next} within the next few months.`, tone: "positive" });
  }

  if (student.scores.attendance === 100 && student.attendance.length >= 4) {
    insights.push({ id: "attendance", text: `Perfect attendance streak — a strong driver of overall progress.`, tone: "positive" });
  } else if (student.scores.attendance < 70) {
    insights.push({ id: "attendance-low", text: `Attendance has dropped to ${student.scores.attendance}%, which is limiting progress. Consider a check-in about scheduling.`, tone: "warning" });
  }

  return insights.slice(0, 6);
}

export function recommendedRevisionTopics(student: Student): string[] {
  const topics = new Set<string>();
  const topMistake = mostCommonMistakeTopic(student);
  if (topMistake) topics.add(topMistake);
  [...student.lessons]
    .sort((a, b) => b.date.localeCompare(a.date))
    .slice(0, 3)
    .forEach((l) => l.mistakesToRevise.forEach((m) => m && topics.add(m)));
  student.vocabulary.filter((v) => v.needsRevision).slice(0, 3).forEach((v) => topics.add(`Vocabulary: ${v.word}`));
  return Array.from(topics).slice(0, 5);
}

export function estimatedFinalScore(student: Student): number {
  const sorted = [...student.lessons].sort((a, b) => a.date.localeCompare(b.date));
  if (sorted.length < 2) return student.scores.overall;
  const mid = Math.floor(sorted.length / 2);
  const earlier = average(sorted.slice(0, mid).map((l) => (l.assessment.grammar + l.assessment.vocabulary + l.assessment.listening + l.assessment.speaking) * 5));
  const recent = average(sorted.slice(mid).map((l) => (l.assessment.grammar + l.assessment.vocabulary + l.assessment.listening + l.assessment.speaking) * 5));
  const growthPerHalf = recent - earlier;
  return Math.max(0, Math.min(100, Math.round(student.scores.overall + growthPerHalf * 0.6)));
}

export function estimatedCompletionMonths(student: Student): number {
  const remaining = Math.max(0, 100 - student.scores.overall);
  const recentLessons = student.lessons.length || 1;
  const monthsActive = Math.max(1, Math.round(recentLessons / 4));
  const paceScorePerMonth = Math.max(2, student.scores.overall / Math.max(1, monthsActive));
  return Math.max(1, Math.round(remaining / paceScorePerMonth));
}

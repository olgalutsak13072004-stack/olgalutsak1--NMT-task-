import { AchievementKey } from "./types";

export const ACHIEVEMENT_CATALOG: { key: AchievementKey; label: string; emoji: string; description: string }[] = [
  { key: "homework-hero", label: "Homework Hero", emoji: "🏆", description: "10 homeworks in a row on time" },
  { key: "grammar-master", label: "Grammar Master", emoji: "⭐", description: "Near-perfect grammar accuracy" },
  { key: "vocabulary-wizard", label: "Vocabulary Wizard", emoji: "📚", description: "Mastered 100+ words" },
  { key: "speaking-star", label: "Speaking Star", emoji: "🎤", description: "Outstanding speaking performance" },
  { key: "listening-expert", label: "Listening Expert", emoji: "🎧", description: "Big improvement in listening" },
  { key: "streak-30", label: "30-day Streak", emoji: "🔥", description: "30 consecutive active days" },
  { key: "perfect-attendance", label: "Perfect Attendance", emoji: "💯", description: "100% attendance streak" },
  { key: "unit-champion", label: "Unit Champion", emoji: "🥇", description: "Top score in a unit test" },
];

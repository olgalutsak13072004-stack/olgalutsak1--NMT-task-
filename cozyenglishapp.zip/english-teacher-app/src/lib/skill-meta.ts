import { SkillScores } from "./types";

export const SKILL_META: { key: keyof SkillScores; label: string; icon: string; tone: "sage" | "dusty" | "coral" | "beige" }[] = [
  { key: "grammar", label: "Grammar", icon: "📐", tone: "sage" },
  { key: "vocabulary", label: "Vocabulary", icon: "📚", tone: "dusty" },
  { key: "listening", label: "Listening", icon: "🎧", tone: "sage" },
  { key: "speaking", label: "Speaking", icon: "🎤", tone: "coral" },
  { key: "writing", label: "Writing", icon: "✍️", tone: "dusty" },
  { key: "reading", label: "Reading", icon: "📖", tone: "sage" },
  { key: "confidence", label: "Confidence", icon: "💪", tone: "coral" },
  { key: "homework", label: "Homework", icon: "📝", tone: "beige" },
  { key: "attendance", label: "Attendance", icon: "📅", tone: "beige" },
];

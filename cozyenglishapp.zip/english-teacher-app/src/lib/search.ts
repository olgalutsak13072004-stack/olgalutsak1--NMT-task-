import { Student } from "./types";
import { formatDateShort } from "./utils";

export interface SearchResult {
  id: string;
  category: "Student" | "Lesson" | "Vocabulary" | "Grammar" | "Homework" | "Feedback" | "Note" | "Test";
  title: string;
  subtitle: string;
  href: string;
}

export function searchAll(students: Student[], query: string): SearchResult[] {
  const q = query.trim().toLowerCase();
  if (!q) return [];
  const results: SearchResult[] = [];

  for (const s of students) {
    if (s.name.toLowerCase().includes(q) || s.occupation.toLowerCase().includes(q)) {
      results.push({ id: `student-${s.id}`, category: "Student", title: s.name, subtitle: `${s.level} · ${s.occupation}`, href: `/teacher/students/${s.id}` });
    }

    for (const l of s.lessons) {
      if (l.topic.toLowerCase().includes(q) || l.grammar.toLowerCase().includes(q)) {
        results.push({
          id: `lesson-${l.id}`,
          category: l.topic.toLowerCase().includes(q) ? "Lesson" : "Grammar",
          title: l.topic,
          subtitle: `${s.name} · ${formatDateShort(l.date)}`,
          href: `/teacher/students/${s.id}?tab=lessons`,
        });
      }
    }

    for (const v of s.vocabulary) {
      if (v.word.toLowerCase().includes(q) || v.translation.toLowerCase().includes(q)) {
        results.push({
          id: `vocab-${v.id}`,
          category: "Vocabulary",
          title: v.word,
          subtitle: `${s.name} · ${v.translation}`,
          href: `/teacher/students/${s.id}?tab=vocabulary`,
        });
      }
    }

    for (const h of s.homework) {
      if (h.assignment.toLowerCase().includes(q)) {
        results.push({
          id: `hw-${h.id}`,
          category: "Homework",
          title: h.assignment,
          subtitle: `${s.name} · ${h.status}`,
          href: `/teacher/students/${s.id}?tab=homework`,
        });
      }
    }

    for (const f of s.feedback) {
      if (f.text.toLowerCase().includes(q)) {
        results.push({
          id: `fb-${f.id}`,
          category: "Feedback",
          title: f.text.slice(0, 60),
          subtitle: `${s.name} · ${f.author}`,
          href: `/teacher/students/${s.id}?tab=feedback`,
        });
      }
    }

    for (const n of s.teacherNotes) {
      if (n.text.toLowerCase().includes(q)) {
        results.push({
          id: `note-${n.id}`,
          category: "Note",
          title: n.text.slice(0, 60),
          subtitle: `${s.name} · Teacher note`,
          href: `/teacher/students/${s.id}?tab=notes`,
        });
      }
    }

    for (const t of s.tests) {
      if (t.title.toLowerCase().includes(q)) {
        results.push({
          id: `test-${t.id}`,
          category: "Test",
          title: t.title,
          subtitle: `${s.name} · ${t.score}/${t.maxScore}`,
          href: `/teacher/students/${s.id}?tab=tests`,
        });
      }
    }
  }

  return results.slice(0, 30);
}

import { Student } from "./types";

export interface CalendarEvent {
  id: string;
  date: string;
  type: "lesson" | "homework" | "test" | "revision" | "birthday" | "milestone" | "plan";
  title: string;
  studentName: string;
  studentId: string;
  tone: "sage" | "dusty" | "coral" | "beige";
}

const TONE: Record<CalendarEvent["type"], CalendarEvent["tone"]> = {
  lesson: "sage",
  homework: "coral",
  test: "dusty",
  revision: "dusty",
  birthday: "beige",
  milestone: "sage",
  plan: "sage",
};

function thisYearBirthday(birthdayIso: string, referenceYear: number): string {
  const d = new Date(birthdayIso);
  const candidate = new Date(Date.UTC(referenceYear, d.getUTCMonth(), d.getUTCDate()));
  return candidate.toISOString();
}

export function buildCalendarEvents(students: Student[], referenceDate: Date): CalendarEvent[] {
  const events: CalendarEvent[] = [];
  const year = referenceDate.getFullYear();

  for (const s of students) {
    for (const l of s.lessons) {
      events.push({ id: `lesson-${l.id}`, date: l.date, type: "lesson", title: l.topic, studentName: s.name, studentId: s.id, tone: TONE.lesson });
    }
    for (const p of s.lessonPlans.filter((p) => p.status === "planned")) {
      events.push({ id: `plan-${p.id}`, date: p.date, type: "plan", title: `Planned: ${p.objectives || "Lesson"}`, studentName: s.name, studentId: s.id, tone: TONE.plan });
    }
    for (const h of s.homework) {
      events.push({ id: `hw-${h.id}`, date: h.dueDate, type: "homework", title: `Due: ${h.assignment}`, studentName: s.name, studentId: s.id, tone: TONE.homework });
    }
    for (const t of s.tests) {
      events.push({ id: `test-${t.id}`, date: t.date, type: "test", title: t.title, studentName: s.name, studentId: s.id, tone: TONE.test });
    }
    for (const v of s.vocabulary.filter((v) => v.needsRevision)) {
      for (const rd of v.revisionDates) {
        events.push({ id: `rev-${v.id}-${rd}`, date: rd, type: "revision", title: `Revise: ${v.word}`, studentName: s.name, studentId: s.id, tone: TONE.revision });
      }
    }
    events.push({
      id: `bday-${s.id}`,
      date: thisYearBirthday(s.birthday, year),
      type: "birthday",
      title: `${s.name}'s birthday 🎂`,
      studentName: s.name,
      studentId: s.id,
      tone: TONE.birthday,
    });
    for (const tl of s.timeline.filter((e) => e.type === "unit-complete" || e.type === "goal" || e.type === "certificate")) {
      events.push({ id: `ms-${tl.id}`, date: tl.date, type: "milestone", title: tl.title, studentName: s.name, studentId: s.id, tone: TONE.milestone });
    }
  }

  return events;
}

export function groupEventsByDay(events: CalendarEvent[]): Map<string, CalendarEvent[]> {
  const map = new Map<string, CalendarEvent[]>();
  for (const e of events) {
    const key = e.date.slice(0, 10);
    if (!map.has(key)) map.set(key, []);
    map.get(key)!.push(e);
  }
  return map;
}

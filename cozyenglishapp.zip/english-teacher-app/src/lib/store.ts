"use client";

import { create } from "zustand";
import { persist } from "zustand/middleware";
import {
  Student,
  LessonRecord,
  HomeworkItem,
  AttendanceRecord,
  VocabularyItem,
  TestRecord,
  LearningGoal,
  Achievement,
  FeedbackEntry,
  NoteEntry,
  StudentNoteBundle,
  LessonPlan,
  StudentStatus,
} from "./types";
import { seedStudents } from "./seed-data";
import { computeScores } from "./scoring";
import { makeId } from "./utils";

function recompute(s: Student): Student {
  return { ...s, scores: computeScores(s) };
}

interface StoreState {
  students: Student[];
  hasHydrated: boolean;
  setHasHydrated: (v: boolean) => void;

  addStudent: (input: Partial<Student> & { name: string }) => string;
  updateStudent: (id: string, patch: Partial<Student>) => void;
  archiveStudent: (id: string) => void;
  unarchiveStudent: (id: string) => void;
  deleteStudent: (id: string) => void;
  duplicateStudent: (id: string) => void;

  addLesson: (studentId: string, lesson: Omit<LessonRecord, "id">) => void;
  updateLesson: (studentId: string, lessonId: string, patch: Partial<LessonRecord>) => void;
  deleteLesson: (studentId: string, lessonId: string) => void;

  addHomework: (studentId: string, hw: Omit<HomeworkItem, "id">) => void;
  updateHomework: (studentId: string, hwId: string, patch: Partial<HomeworkItem>) => void;

  addAttendance: (studentId: string, record: Omit<AttendanceRecord, "id">) => void;
  updateAttendance: (studentId: string, recId: string, patch: Partial<AttendanceRecord>) => void;

  addVocabulary: (studentId: string, item: Omit<VocabularyItem, "id">) => void;
  updateVocabulary: (studentId: string, itemId: string, patch: Partial<VocabularyItem>) => void;

  addTest: (studentId: string, test: Omit<TestRecord, "id">) => void;

  addLearningGoal: (studentId: string, goal: Omit<LearningGoal, "id">) => void;
  updateLearningGoal: (studentId: string, goalId: string, patch: Partial<LearningGoal>) => void;
  toggleMilestone: (studentId: string, goalId: string, milestoneId: string) => void;

  addAchievement: (studentId: string, achievement: Achievement) => void;

  addFeedback: (studentId: string, entry: Omit<FeedbackEntry, "id">) => void;

  addTeacherNote: (studentId: string, text: string) => void;
  updateStudentNotes: (studentId: string, patch: Partial<StudentNoteBundle>) => void;

  addLessonPlan: (studentId: string, plan: Omit<LessonPlan, "id" | "studentId">) => void;
  updateLessonPlan: (studentId: string, planId: string, patch: Partial<LessonPlan>) => void;
  deleteLessonPlan: (studentId: string, planId: string) => void;
}

export const useStore = create<StoreState>()(
  persist(
    (set, get) => ({
      students: seedStudents,
      hasHydrated: false,
      setHasHydrated: (v) => set({ hasHydrated: v }),

      addStudent: (input) => {
        const id = makeId("student");
        const newStudent: Student = recompute({
          id,
          name: input.name,
          email: input.email ?? `${input.name.toLowerCase().replace(/\s+/g, ".")}@example.com`,
          avatarEmoji: input.avatarEmoji ?? "🌱",
          avatarColor: input.avatarColor ?? "sage",
          age: input.age ?? 20,
          level: input.level ?? "A1",
          occupation: input.occupation ?? "",
          goals: input.goals ?? [],
          interests: input.interests ?? [],
          confidence: input.confidence ?? { speaking: 50, grammar: 50, vocabulary: 50, pronunciation: 50 },
          startDate: input.startDate ?? new Date().toISOString(),
          status: "active",
          birthday: input.birthday ?? new Date().toISOString(),
          course: input.course ?? { name: "General English", unit: "Unit 1", lesson: "Lesson 1", teacher: "Ms. Olga" },
          scores: { overall: 0, grammar: 0, vocabulary: 0, listening: 0, speaking: 0, writing: 0, reading: 0, confidence: 0, homework: 100, attendance: 100 },
          lessons: [],
          vocabulary: [],
          homework: [],
          attendance: [],
          tests: [],
          learningGoals: [],
          achievements: [],
          feedback: [],
          teacherNotes: [],
          studentNotes: {
            todaysAchievement: "",
            whatToPractise: "",
            homework: "",
            vocabulary: "",
            positiveFeedback: "",
            weeklyChallenge: "",
            monthlyGoal: "",
            updatedAt: new Date().toISOString(),
          },
          timeline: [{ id: makeId("tl"), date: new Date().toISOString(), type: "first-lesson", title: "Joined the studio" }],
          lessonPlans: [],
        });
        set({ students: [...get().students, newStudent] });
        return id;
      },

      updateStudent: (id, patch) => {
        set({ students: get().students.map((s) => (s.id === id ? recompute({ ...s, ...patch }) : s)) });
      },

      archiveStudent: (id) => {
        set({ students: get().students.map((s) => (s.id === id ? { ...s, status: "archived" as StudentStatus } : s)) });
      },

      unarchiveStudent: (id) => {
        set({ students: get().students.map((s) => (s.id === id ? { ...s, status: "active" as StudentStatus } : s)) });
      },

      deleteStudent: (id) => {
        set({ students: get().students.filter((s) => s.id !== id) });
      },

      duplicateStudent: (id) => {
        const original = get().students.find((s) => s.id === id);
        if (!original) return;
        const newId = makeId("student");
        const copy: Student = {
          ...original,
          id: newId,
          name: `${original.name} (copy)`,
          email: `copy.${original.email}`,
          status: "active",
        };
        set({ students: [...get().students, copy] });
      },

      addLesson: (studentId, lesson) => {
        set({
          students: get().students.map((s) => {
            if (s.id !== studentId) return s;
            const newLesson: LessonRecord = { ...lesson, id: makeId("lesson") };
            return recompute({ ...s, lessons: [...s.lessons, newLesson] });
          }),
        });
      },

      updateLesson: (studentId, lessonId, patch) => {
        set({
          students: get().students.map((s) =>
            s.id !== studentId
              ? s
              : recompute({ ...s, lessons: s.lessons.map((l) => (l.id === lessonId ? { ...l, ...patch } : l)) })
          ),
        });
      },

      deleteLesson: (studentId, lessonId) => {
        set({
          students: get().students.map((s) =>
            s.id !== studentId ? s : recompute({ ...s, lessons: s.lessons.filter((l) => l.id !== lessonId) })
          ),
        });
      },

      addHomework: (studentId, hw) => {
        set({
          students: get().students.map((s) =>
            s.id !== studentId ? s : recompute({ ...s, homework: [...s.homework, { ...hw, id: makeId("hw") }] })
          ),
        });
      },

      updateHomework: (studentId, hwId, patch) => {
        set({
          students: get().students.map((s) =>
            s.id !== studentId
              ? s
              : recompute({ ...s, homework: s.homework.map((h) => (h.id === hwId ? { ...h, ...patch } : h)) })
          ),
        });
      },

      addAttendance: (studentId, record) => {
        set({
          students: get().students.map((s) =>
            s.id !== studentId ? s : recompute({ ...s, attendance: [...s.attendance, { ...record, id: makeId("att") }] })
          ),
        });
      },

      updateAttendance: (studentId, recId, patch) => {
        set({
          students: get().students.map((s) =>
            s.id !== studentId
              ? s
              : recompute({ ...s, attendance: s.attendance.map((a) => (a.id === recId ? { ...a, ...patch } : a)) })
          ),
        });
      },

      addVocabulary: (studentId, item) => {
        set({
          students: get().students.map((s) =>
            s.id !== studentId ? s : { ...s, vocabulary: [...s.vocabulary, { ...item, id: makeId("vocab") }] }
          ),
        });
      },

      updateVocabulary: (studentId, itemId, patch) => {
        set({
          students: get().students.map((s) =>
            s.id !== studentId
              ? s
              : { ...s, vocabulary: s.vocabulary.map((v) => (v.id === itemId ? { ...v, ...patch } : v)) }
          ),
        });
      },

      addTest: (studentId, test) => {
        set({
          students: get().students.map((s) =>
            s.id !== studentId ? s : recompute({ ...s, tests: [...s.tests, { ...test, id: makeId("test") }] })
          ),
        });
      },

      addLearningGoal: (studentId, goal) => {
        set({
          students: get().students.map((s) =>
            s.id !== studentId ? s : { ...s, learningGoals: [...s.learningGoals, { ...goal, id: makeId("goal") }] }
          ),
        });
      },

      updateLearningGoal: (studentId, goalId, patch) => {
        set({
          students: get().students.map((s) =>
            s.id !== studentId
              ? s
              : { ...s, learningGoals: s.learningGoals.map((g) => (g.id === goalId ? { ...g, ...patch } : g)) }
          ),
        });
      },

      toggleMilestone: (studentId, goalId, milestoneId) => {
        set({
          students: get().students.map((s) => {
            if (s.id !== studentId) return s;
            return {
              ...s,
              learningGoals: s.learningGoals.map((g) => {
                if (g.id !== goalId) return g;
                const milestones = g.milestones.map((m) => (m.id === milestoneId ? { ...m, done: !m.done } : m));
                const progress = Math.round((milestones.filter((m) => m.done).length / Math.max(1, milestones.length)) * 100);
                return { ...g, milestones, progress };
              }),
            };
          }),
        });
      },

      addAchievement: (studentId, achievement) => {
        set({
          students: get().students.map((s) =>
            s.id !== studentId
              ? s
              : s.achievements.some((a) => a.key === achievement.key)
              ? s
              : { ...s, achievements: [...s.achievements, achievement] }
          ),
        });
      },

      addFeedback: (studentId, entry) => {
        set({
          students: get().students.map((s) =>
            s.id !== studentId ? s : { ...s, feedback: [...s.feedback, { ...entry, id: makeId("fb") }] }
          ),
        });
      },

      addTeacherNote: (studentId, text) => {
        const note: NoteEntry = { id: makeId("tn"), date: new Date().toISOString(), text };
        set({
          students: get().students.map((s) => (s.id !== studentId ? s : { ...s, teacherNotes: [note, ...s.teacherNotes] })),
        });
      },

      updateStudentNotes: (studentId, patch) => {
        set({
          students: get().students.map((s) =>
            s.id !== studentId
              ? s
              : { ...s, studentNotes: { ...s.studentNotes, ...patch, updatedAt: new Date().toISOString() } }
          ),
        });
      },

      addLessonPlan: (studentId, plan) => {
        set({
          students: get().students.map((s) =>
            s.id !== studentId
              ? s
              : { ...s, lessonPlans: [...s.lessonPlans, { ...plan, id: makeId("plan"), studentId }] }
          ),
        });
      },

      updateLessonPlan: (studentId, planId, patch) => {
        set({
          students: get().students.map((s) =>
            s.id !== studentId
              ? s
              : { ...s, lessonPlans: s.lessonPlans.map((p) => (p.id === planId ? { ...p, ...patch } : p)) }
          ),
        });
      },

      deleteLessonPlan: (studentId, planId) => {
        set({
          students: get().students.map((s) =>
            s.id !== studentId ? s : { ...s, lessonPlans: s.lessonPlans.filter((p) => p.id !== planId) }
          ),
        });
      },
    }),
    {
      name: "cozy-english-store",
      version: 1,
      onRehydrateStorage: () => (state) => {
        state?.setHasHydrated(true);
      },
    }
  )
);

export function useStudent(id: string | undefined) {
  return useStore((s) => s.students.find((st) => st.id === id));
}

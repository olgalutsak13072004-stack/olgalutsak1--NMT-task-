import { Student } from "./types";
import { daysBetween, daysUntil } from "./utils";

export interface AppNotification {
  id: string;
  text: string;
  tone: "warning" | "neutral" | "positive";
  href: string;
}

const NOW = "2026-07-27T09:00:00Z";

export function generateNotifications(students: Student[]): AppNotification[] {
  const notifications: AppNotification[] = [];

  for (const s of students) {
    if (s.status !== "active") continue;

    const uncheckedHw = s.homework.filter((h) => h.status === "submitted" && !h.teacherCorrection);
    if (uncheckedHw.length) {
      notifications.push({
        id: `hw-${s.id}`,
        text: `${s.name} has ${uncheckedHw.length} homework submission${uncheckedHw.length > 1 ? "s" : ""} awaiting review.`,
        tone: "warning",
        href: `/teacher/students/${s.id}?tab=homework`,
      });
    }

    const lastAttendance = [...s.attendance].sort((a, b) => b.date.localeCompare(a.date))[0];
    if (lastAttendance?.status === "absent") {
      notifications.push({
        id: `absent-${s.id}`,
        text: `${s.name} was absent from the last lesson.`,
        tone: "warning",
        href: `/teacher/students/${s.id}`,
      });
    }

    const upcomingPlan = s.lessonPlans.find((p) => p.status === "planned" && daysUntil(p.date) >= 0 && daysUntil(p.date) <= 3);
    if (upcomingPlan) {
      notifications.push({
        id: `upcoming-${s.id}`,
        text: `Upcoming lesson with ${s.name} in ${Math.max(0, daysUntil(upcomingPlan.date))} day(s).`,
        tone: "neutral",
        href: `/teacher/lesson-plans`,
      });
    }

    const needsRevision = s.vocabulary.filter((v) => v.needsRevision).length;
    if (needsRevision >= 3) {
      notifications.push({
        id: `revision-${s.id}`,
        text: `${s.name} has ${needsRevision} vocabulary words due for revision.`,
        tone: "neutral",
        href: `/teacher/students/${s.id}?tab=vocabulary`,
      });
    }

    const lastTest = [...s.tests].sort((a, b) => b.date.localeCompare(a.date))[0];
    if ((!lastTest || daysBetween(lastTest.date, NOW) > 30) && s.lessons.length >= 5) {
      notifications.push({
        id: `test-${s.id}`,
        text: `${s.name} is due for a unit test — it's been over a month.`,
        tone: "neutral",
        href: `/teacher/students/${s.id}?tab=tests`,
      });
    }

    const lastLesson = [...s.lessons].sort((a, b) => b.date.localeCompare(a.date))[0];
    if (lastLesson && daysBetween(lastLesson.date, NOW) > 14) {
      notifications.push({
        id: `inactive-${s.id}`,
        text: `${s.name} hasn't had a lesson in ${daysBetween(lastLesson.date, NOW)} days.`,
        tone: "warning",
        href: `/teacher/students/${s.id}`,
      });
    }
  }

  return notifications;
}
